#!./venv/bin/python
"""L5 拉通自检 — Batch 189 DataState 三态统一 · 浏览器人因验证。

Lab 页 5 个 tab（上下文/管线/数据/图谱/实验），11 个已迁移 panel
分布在所有 tab 中。脚本逐个 tab 点击 → 等待加载 → 验证三态。

Batch 189 迁移的 11 个 panel 按 tab 分组：
  上下文: OverflowSim / StrategyCompare / IntentTest
  管线:   TokenDashboard / StepLatency / PipelineTrace
  数据:   EmbeddingSpace / CacheStats (MemoryBrowserPanel 未迁移)
  图谱:   KnowledgeGraph / DecayDistribution (HealthDashboard/LogViewer 未迁移)
  实验:   CostWaterfall (ExperimentComparePanel 未迁移)
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path
from typing import Any

from playwright.sync_api import ConsoleMessage, Locator, Page, sync_playwright

PROJECT_ROOT = Path(__file__).resolve().parent.parent

# ── Tab → 迁移 panel 列表（按 h3 文字匹配）──
TAB_PANELS: dict[str, dict[str, str]] = {
    "context": {
        "OverflowSim": "溢出模拟",
        "StrategyCompare": "策略对比",
        "IntentTest": "意图测试",
    },
    "pipeline": {
        "TokenDashboard": "Token 用量仪表盘",
        "StepLatency": "管线步骤延迟分析",
        "PipelineTrace": "Pipeline 追踪浏览器",
    },
    "data": {
        "EmbeddingSpace": "嵌入空间",
        "CacheStats": "缓存命中率",
    },
    "graph": {
        "KnowledgeGraph": "知识图谱",
        "DecayDistribution": "衰减分布",
    },
    "experiment": {
        "CostWaterfall": "Token 消耗瀑布",
    },
}

TAB_LABELS = {
    "context": "上下文",
    "pipeline": "管线",
    "data": "数据",
    "graph": "图谱",
    "experiment": "实验",
}

# ── 噪声过滤 ──
_NOISE_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"Fast\s*Refresh", re.IGNORECASE),
    re.compile(r"webpack(\-hmr)?", re.IGNORECASE),
    re.compile(r"hot\s*module\s*replacement", re.IGNORECASE),
    re.compile(r"\[HMR\]", re.IGNORECASE),
    re.compile(r"__nextjs_devtools__", re.IGNORECASE),
    re.compile(r"^\s*$"),
]


def _is_noise(msg: str) -> bool:
    return any(p.search(msg) for p in _NOISE_PATTERNS)


def find_panel_section(page: Page, h3_text: str) -> Locator | None:
    """通过 h3 文字定位 panel section。"""
    # 找到包含特定文字的 h3 所在的父级 section
    h3 = page.locator("h3", has_text=h3_text).first
    if h3.count() == 0:
        return None
    # 往上找最近的 section 或具有 panel 样式的 div
    # 实际 DOM 结构: section.border.border-border > div > h3
    section = page.locator("section").filter(has=page.locator("h3", has_text=h3_text))
    if section.count() > 0:
        return section.first
    # fallback: 用 h3 的祖父元素
    parent = h3.locator("..")
    if parent.count() > 0:
        grandparent = parent.locator("..")
        if grandparent.count() > 0:
            return grandparent.first
    return None


def check_panel_state(page: Page, name: str, h3_text: str) -> dict[str, Any]:
    """检查单个 panel 的渲染状态。"""
    section = find_panel_section(page, h3_text)
    if section is None:
        return {"status": "NOT_FOUND", "detail": f"h3 '{h3_text}' not in DOM"}

    # 检查内部各态标记
    has_loading = section.locator('[role="status"]').count() > 0
    has_alert = section.locator('[role="alert"]').count() > 0

    # 检查空态关键词
    section_text = section.text_content() or ""
    has_empty_keyword = any(
        kw in section_text for kw in ["暂无数据", "暂无 Token", "暂无缓存", "暂无嵌入"]
    )

    # 判定状态
    if has_loading:
        status = "LOADING"
    elif has_alert:
        status = "ERROR"
    elif has_empty_keyword and not has_loading:
        status = "EMPTY"
    elif section_text.strip():
        # 有内容且非 loading/error/empty
        status = "SUCCESS"
    else:
        status = "UNKNOWN"

    # 收集细节
    detail_parts = []
    if has_loading:
        detail_parts.append("spinner visible")
    if has_alert:
        error_text = section.locator('[role="alert"]').first.text_content() or ""
        detail_parts.append(f"alert: {error_text[:100]}")
    if has_empty_keyword:
        detail_parts.append("empty message visible")

    return {
        "status": status,
        "has_loading_spinner": has_loading,
        "has_alert": has_alert,
        "has_empty_keyword": has_empty_keyword,
        "detail": "; ".join(detail_parts) if detail_parts else "ok",
    }


def verify_tab(page: Page, tab_key: str, wait_ms: int = 4000) -> dict[str, Any]:
    """点击 tab → 等待加载 → 验证所有 panel。"""
    label = TAB_LABELS[tab_key]
    panels = TAB_PANELS[tab_key]

    # 点击 tab
    tab_btn = page.locator('[role="tab"]', has_text=label)
    if tab_btn.count() == 0:
        return {"error": f"Tab '{label}' button not found"}

    tab_btn.first.click()

    # 等待渲染 + fetch
    page.wait_for_timeout(wait_ms)

    # 逐个检查 panel
    results = {}
    for name, h3_text in panels.items():
        results[name] = check_panel_state(page, name, h3_text)

    return results


def main() -> int:
    base_url = "http://localhost:3000"

    # ── 检查 dev server ──
    import urllib.request

    try:
        urllib.request.urlopen(f"{base_url}/lab", timeout=5)
    except Exception:
        print("❌ Dev server 未运行。请先启动 frontend dev server。")
        return 1

    report_dir = PROJECT_ROOT / "screenshots" / "l5-batch189"
    report_dir.mkdir(parents=True, exist_ok=True)

    with sync_playwright() as pw:
        browser = pw.chromium.launch(headless=True)
        context = browser.new_context(
            viewport={"width": 1440, "height": 900},
            locale="zh-CN",
        )
        page = context.new_page()

        # ── Console error 收集 ──
        console_errors: list[str] = []

        def on_console(msg: ConsoleMessage) -> None:
            if msg.type == "error" and not _is_noise(msg.text):
                console_errors.append(f"[{msg.type}] {msg.text}")

        page.on("console", on_console)

        # ── 访问 lab 页 ──
        print("\n🔍 L5 拉通自检 — Batch 189 DataState 三态统一")
        print("   目标: 11 个 panel × 5 个 tab")
        print(f"   URL: {base_url}/lab\n")

        page.goto(f"{base_url}/lab", wait_until="networkidle", timeout=30000)
        page.wait_for_timeout(2000)

        # ── 逐个 tab 验证 ──
        all_results: dict[str, dict[str, Any]] = {}
        total_ok = 0
        total_count = 0

        for tab_key in TAB_PANELS:
            label = TAB_LABELS[tab_key]
            print(f"── {label} tab ──")

            tab_results = verify_tab(page, tab_key, wait_ms=4500)
            all_results[tab_key] = tab_results

            if "error" in tab_results:
                print(f"  ❌ {tab_results['error']}")
                continue

            for name, r in tab_results.items():
                total_count += 1
                status = r["status"]
                if status == "SUCCESS":
                    total_ok += 1
                    print(f"  ✅ {name:<20} {status}")
                elif status == "EMPTY":
                    total_ok += 1
                    print(f"  💤 {name:<20} {status} (预期空态，API 无数据)")
                elif status == "LOADING":
                    print(f"  ⏳ {name:<20} {status} (超时未完成)")
                elif status == "ERROR":
                    print(f"  ❌ {name:<20} {status} — {r['detail']}")
                elif status == "NOT_FOUND":
                    print(f"  🔍 {name:<20} {status} — {r['detail']}")
                else:
                    print(f"  ⚠️  {name:<20} {status} — {r['detail']}")

            # 截图当前 tab
            page.screenshot(path=str(report_dir / f"tab-{tab_key}.png"), full_page=False)

        # ── 追加：loading 态复现验证 ──
        print("\n── loading 态复现验证 ──")
        # 切到 pipeline tab，点刷新触发 loading
        tab_btn = page.locator('[role="tab"]', has_text="管线")
        if tab_btn.count() > 0:
            tab_btn.first.click()
            page.wait_for_timeout(500)

            # 查找 refresh 按钮并点击
            refresh_btns = page.locator('button[title="刷新数据"]')
            if refresh_btns.count() > 0:
                refresh_btns.first.click()
                page.wait_for_timeout(300)

                # 截图 loading 态
                has_spinner = page.locator('[role="status"]').count() > 0
                if has_spinner:
                    print("  ✅ 刷新按钮触发 loading spinner（DataState 加载态正常）")
                    page.screenshot(path=str(report_dir / "loading-state.png"), full_page=False)
                else:
                    print("  ⚠️  刷新后未捕获 loading 态（加载可能太快）")

                # 等待加载完成
                page.wait_for_timeout(4000)

        # ── 汇总 ──
        def _count_status(status_key: str) -> int:
            """统计 all_results 中所有 panel 的指定 status 数量。"""
            n = 0
            for tr in all_results.values():
                if not isinstance(tr, dict):
                    continue
                for r in tr.values():
                    if isinstance(r, dict) and r.get("status") == status_key:
                        n += 1
            return n

        print(f"\n{'=' * 60}")
        print("  L5 拉通总结")
        print(f"{'=' * 60}")
        print(f"  正常 (SUCCESS + EMPTY):  {total_ok}/{total_count}")
        print(f"  LOADING (超时):          {_count_status('LOADING')}")
        print(f"  ERROR:                   {_count_status('ERROR')}")
        print(f"  NOT_FOUND:               {_count_status('NOT_FOUND')}")
        print(f"  console errors:          {len(console_errors)}")
        print(f"{'=' * 60}")

        # ── 判定 ──
        error_count = sum(
            1
            for tr in all_results.values()
            if isinstance(tr, dict)
            for r in tr.values()
            if isinstance(r, dict) and r.get("status") == "ERROR"
        )
        not_found_count = sum(
            1
            for tr in all_results.values()
            if isinstance(tr, dict)
            for r in tr.values()
            if isinstance(r, dict) and r.get("status") == "NOT_FOUND"
        )
        loading_count = sum(
            1
            for tr in all_results.values()
            if isinstance(tr, dict)
            for r in tr.values()
            if isinstance(r, dict) and r.get("status") == "LOADING"
        )

        all_ok = (
            error_count == 0
            and not_found_count == 0
            and loading_count == 0
            and len(console_errors) == 0
        )

        # ── 全页截图 ──
        # 回到第一个 tab 截图
        first_tab = page.locator('[role="tab"]', has_text="上下文")
        if first_tab.count() > 0:
            first_tab.first.click()
            page.wait_for_timeout(3000)
        page.screenshot(path=str(report_dir / "final-state.png"), full_page=True)

        # ── JSON 报告 ──
        report = {
            "batch": "189",
            "tab_count": len(TAB_PANELS),
            "panel_count": total_count,
            "ok_count": total_ok,
            "results": all_results,
            "console_errors": console_errors,
            "passed": all_ok,
        }
        report_json = json.dumps(report, ensure_ascii=False, indent=2)
        (report_dir / "l5-report.json").write_text(report_json, encoding="utf-8")

        print(f"\n📸 截图: {report_dir}/")
        print(f"📄 报告: {report_dir}/l5-report.json")

        if all_ok:
            print("\n✅ L5 拉通自检通过 — 11 个 Batch 189 DataState panel 全部正常")
        else:
            issues = []
            if error_count > 0:
                issues.append(f"{error_count} ERROR")
            if not_found_count > 0:
                issues.append(f"{not_found_count} NOT_FOUND")
            if loading_count > 0:
                issues.append(f"{loading_count} LOADING")
            if console_errors:
                issues.append(f"{len(console_errors)} console errors")
            print(f"\n❌ L5 拉通自检未通过 — {'; '.join(issues)}")

        browser.close()
        return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
