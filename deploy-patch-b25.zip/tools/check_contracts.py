#!/usr/bin/env python3
"""L3 契约完整性检查 — 接口签名变更影响分析。

命令：
  snapshot  从当前源码提取签名，写入 .contract-snapshot.json
  check     比对当前签名与快照，报告变更及受影响的调用方
  extract   打印当前签名为 JSON（调试用）
"""

from __future__ import annotations

import ast
import json
import subprocess
import sys
from pathlib import Path

SNAPSHOT_PATH = Path(".contract-snapshot.json")

TARGETS: list[dict[str, object]] = [
    {"file": "src/bootstrap.py", "functions": ["init_engines"]},
    {
        "file": "src/chat/engine.py",
        "functions": [
            "ChatEngine.generate",
            "ChatEngine.generate_and_store",
        ],
    },
    {"file": "src/memory/store.py", "functions": ["MemoryStore.*"]},
    {"file": "src/memory/recall.py", "functions": ["RecallEngine.recall"]},
    {"file": "src/memory/forget.py", "functions": ["ForgettingEngine.decay_all"]},
    {"file": "src/planner/intent.py", "functions": ["PlannerEngine.classify_intent"]},
    {"file": "src/planner/plan.py", "functions": ["PlanGenerator.generate_plan"]},
    {"file": "src/embed.py", "functions": ["embed"]},
]


def _param_str(node: ast.arguments) -> str:
    """Normalize function parameters to a stable string representation.

    Default values are replaced with '...' so that backward-compatible
    changes (adding a default, changing a default value) don't trigger
    false-positive contract violations.
    """
    parts: list[str] = []

    # Positional-only: def f(a, b, /)
    for i, arg in enumerate(node.posonlyargs):
        prefix = "" if i == 0 else ", "
        parts.append(f"{prefix}{arg.arg}")
    if node.posonlyargs:
        parts.append(", /")

    # Regular positional
    for i, arg in enumerate(node.args):
        if i == 0 and not parts:
            parts.append(arg.arg)
        else:
            comma = "" if parts[-1].endswith("/") else ", "
            parts.append(f"{comma}{arg.arg}")

    # vararg: *args
    if node.vararg:
        parts.append(f", *{node.vararg.arg}")

    # Keyword-only: *, k1, k2
    if node.kwonlyargs:
        if not node.vararg:
            parts.append(", *")
        for arg in node.kwonlyargs:
            parts.append(f", {arg.arg}=...")

    # kwarg: **kwargs
    if node.kwarg:
        parts.append(f", **{node.kwarg.arg}")

    return "".join(parts)


def _return_str(node: ast.FunctionDef | None) -> str:
    """Extract return annotation as source text."""
    if node is None:
        return ""
    if node.returns:
        return ast.unparse(node.returns)
    return ""


def _signature(func: ast.FunctionDef, is_method: bool = False) -> str:
    """Build normalized signature string for a function."""
    params = _param_str(func.args)
    if is_method:
        # Strip 'self' or 'cls' if first param
        if params.startswith("self"):
            params = params.removeprefix("self")
            if params.startswith(", "):
                params = params[2:]
        elif params.startswith("cls"):
            params = params.removeprefix("cls")
            if params.startswith(", "):
                params = params[2:]

    returns = _return_str(func)
    name = func.name

    # Handle special method names
    if name == "__init__":
        name = "__init__"
        if returns:
            returns = " -> None"

    sig = f"({params})"

    # Decorators hint
    decorators = [
        d
        for d in func.decorator_list
        if isinstance(d, ast.Name) and d.id in ("staticmethod", "classmethod")
    ]
    if decorators:
        sig = f"[{decorators[0].id}] {sig}"

    if returns:
        sig += f" -> {returns}"

    return sig


def _expand_targets(targets: list[dict[str, object]]) -> list[tuple[str, str]]:
    """Expand wildcard targets (e.g., MemoryStore.*) into concrete function names.

    Returns list of (file, function_name) tuples.
    """
    result: list[tuple[str, str]] = []
    for t in targets:
        file = str(t["file"])
        functions = t["functions"]
        if not isinstance(functions, list):
            continue
        for fname in functions:
            fname_str = str(fname)
            if ".*" in fname_str:
                class_name = fname_str.replace(".*", "")
                methods = _list_class_methods(file, class_name)
                for m in methods:
                    result.append((file, f"{class_name}.{m}"))
            else:
                result.append((file, fname_str))
    return result


def _list_class_methods(file: str, class_name: str) -> list[str]:
    """List all public (non-underscore) methods of a class."""
    try:
        tree = ast.parse(Path(file).read_text(encoding="utf-8"))
    except (SyntaxError, FileNotFoundError):
        return []

    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.ClassDef) and node.name == class_name:
            return [
                m.name
                for m in node.body
                if isinstance(m, ast.FunctionDef) and not m.name.startswith("_")
            ]
    return []


def extract_signatures(
    targets: list[dict[str, object]],
) -> dict[str, str]:
    """Extract current signatures from source files.

    Returns dict keyed by "file::function_name" → signature_string.
    """
    all_targets = _expand_targets(targets)
    signatures: dict[str, str] = {}

    # Group by file
    by_file: dict[str, list[str]] = {}
    for file, fname in all_targets:
        by_file.setdefault(file, []).append(fname)

    for file, funcs in by_file.items():
        try:
            tree = ast.parse(Path(file).read_text(encoding="utf-8"))
        except (SyntaxError, FileNotFoundError) as exc:
            print(f"  ⚠️  跳过 {file}（解析错误: {exc}）", file=sys.stderr)
            continue

        # Build class → method list lookup
        class_methods: dict[str, list[str]] = {}
        for f in funcs:
            if "." in f:
                cls, method = f.split(".", 1)
                class_methods.setdefault(cls, []).append(method)

        # Top-level functions
        top_funcs = {f for f in funcs if "." not in f}

        for node in ast.iter_child_nodes(tree):
            # Top-level function
            if isinstance(node, ast.FunctionDef) and node.name in top_funcs:
                key = f"{file}::{node.name}"
                signatures[key] = _signature(node)

            # Class methods
            elif isinstance(node, ast.ClassDef) and node.name in class_methods:
                wanted = class_methods[node.name]
                for m in node.body:
                    if isinstance(m, ast.FunctionDef) and m.name in wanted:
                        key = f"{file}::{node.name}.{m.name}"
                        signatures[key] = _signature(m, is_method=True)

    return dict(sorted(signatures.items()))


def _find_callers(function_name: str, exclude_file: str | None = None) -> list[str]:
    """Grep for call sites of a function name across src/ and tests/."""
    try:
        result = subprocess.run(
            ["grep", "-rn", "--include=*.py", function_name, "src/", "tests/"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            timeout=10,
        )
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return []

    lines: list[str] = []
    for line in (result.stdout or "").strip().split("\n"):
        if not line:
            continue
        if exclude_file and line.startswith(f"{exclude_file}:"):
            continue
        # Filter out definition lines (def/class) and comment lines
        file_line = line.split(":", 2)
        if len(file_line) >= 3:
            content = file_line[2].strip()
            if (
                content.startswith("#")
                or content.startswith("def ")
                or content.startswith("class ")
            ):
                continue
        lines.append(line)

    return lines


def cmd_snapshot() -> None:
    """Extract current signatures and write snapshot file."""
    signatures = extract_signatures(TARGETS)
    snapshot = {
        "version": 1,
        "targets": TARGETS,
        "signatures": signatures,
    }
    snapshot_json = json.dumps(snapshot, indent=2, ensure_ascii=False) + "\n"
    SNAPSHOT_PATH.write_text(snapshot_json, encoding="utf-8")
    print(f"✅ 快照已保存: {SNAPSHOT_PATH} ({len(signatures)} 个签名)")


def cmd_extract() -> None:
    """Print current signatures as JSON."""
    signatures = extract_signatures(TARGETS)
    print(json.dumps(signatures, indent=2, ensure_ascii=False))


def cmd_check() -> int:
    """Compare current signatures vs snapshot and report changes.

    Returns 0 if no changes detected, 1 if changes found (warning-only,
    never blocks a commit).
    """
    if not SNAPSHOT_PATH.exists():
        print("  ⚠️  快照文件不存在，运行 `make contract-snapshot` 创建基线")
        return 0

    try:
        snapshot = json.loads(SNAPSHOT_PATH.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        print("  ⚠️  快照文件损坏，运行 `make contract-snapshot` 重建")
        return 0

    stored: dict[str, str] = snapshot.get("signatures", {})
    current = extract_signatures(TARGETS)

    if not stored:
        print("  ⚠️  快照中无签名数据，运行 `make contract-snapshot` 创建基线")
        return 0

    changes_found = 0
    all_keys = sorted(set(stored.keys()) | set(current.keys()))

    for key in all_keys:
        old = stored.get(key)
        new = current.get(key)

        if old is None:
            print(f"  ⚠️  新增函数: {key}")
            changes_found += 1
            # Find callers for the new function
            func_short = key.split("::")[-1]
            file_path = key.split("::")[0]
            callers = _find_callers(func_short, exclude_file=file_path)
            if callers:
                print(f"      已在 {len(callers)} 处发现调用")
            continue

        if new is None:
            print(f"  ⚠️  函数已移除: {key}")
            changes_found += 1
            continue

        if old != new:
            changes_found += 1
            func_short = key.split("::")[-1]
            file_path = key.split("::")[0]

            print(f"  ❌ {key} — 签名已变更")
            print(f"     快照: {func_short}{old}")
            print(f"     当前: {func_short}{new}")

            callers = _find_callers(func_short, exclude_file=file_path)
            if callers:
                print(f"     影响 {len(callers)} 个调用点:")
                for c in callers[:12]:
                    print(f"       - {c}")
                if len(callers) > 12:
                    print(f"       ... 及其他 {len(callers) - 12} 处")
            else:
                print("     未发现外部调用点")

            has_default_in_new = "..." in new
            if has_default_in_new:
                print("     💡 新参数有默认值，调用方兼容（若不改调用语义）")
            else:
                print("     💡 签名变更可能影响调用方，请逐一确认兼容性")

    if changes_found == 0:
        count = len(stored)
        print(f"  ✅ 所有 {count} 个契约签名与快照一致")

    return 0


def main() -> None:
    if len(sys.argv) < 2:
        print("用法: check_contracts.py <snapshot|check|extract>", file=sys.stderr)
        sys.exit(1)

    cmd = sys.argv[1]
    if cmd == "snapshot":
        cmd_snapshot()
    elif cmd == "check":
        sys.exit(cmd_check())
    elif cmd == "extract":
        cmd_extract()
    else:
        print(f"未知命令: {cmd}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
