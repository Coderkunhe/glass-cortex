#!./venv/bin/python
"""安全门禁：文件行数上限 + CSS 变更 UI 验证提醒。

由 pre-commit hook 自动调用（make check-safety）。不替代 make check-docs 的
深度 L2-L5 检查——仅做机械可判的硬约束。

规则来源：CLAUDE.md 工程规则 #7（文件行数上限）、协作纪律 #14（浏览器验证门禁）、
新增 #16（UI 布局诊断铁律）。
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
LINE_LIMIT = 1500
CSS_FILES: set[str] = set()  # M4: Streamlit CSS 令牌文件已随 src/web/ 删除


def _staged_files() -> set[str]:
    """返回本次 git 暂存文件路径集合，路径相对于 PROJECT_ROOT（glassmind/）。

    git 以 repo root 为基准，当 PROJECT_ROOT 是 repo root 子目录时（Monorepo），
    路径带父目录前缀（如 glassmind/frontend/...），需剥离该前缀。
    """
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-prefix"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            cwd=PROJECT_ROOT,
            timeout=5,
        )
        prefix = (result.stdout or "").strip()  # e.g. "glassmind/" or ""
    except Exception:
        prefix = ""

    try:
        result = subprocess.run(
            ["git", "diff", "--cached", "--name-only"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            cwd=PROJECT_ROOT,
            timeout=10,
        )
        files = set()
        for p in (result.stdout or "").strip().split("\n"):
            if not p:
                continue
            # 剥离 repo-root-relative 前缀，使路径相对于 PROJECT_ROOT
            if prefix and p.startswith(prefix):
                p = p[len(prefix) :]
            files.add(p)
        return files
    except (OSError, subprocess.TimeoutExpired):
        return set()


def check_file_line_counts(staged: set[str]) -> int:
    """工程规则 #7：新增或修改的 .py 文件超过 1,500 行 → 拦截。

    未修改的超限文件仅警告（历史遗留），不阻塞提交。
    """
    violations = 0
    for py_file in PROJECT_ROOT.glob("src/**/*.py"):
        if py_file.name.startswith("__"):
            continue
        lines = py_file.read_text(encoding="utf-8").count("\n") + 1
        rel = str(py_file.relative_to(PROJECT_ROOT))
        if lines > LINE_LIMIT:
            changed = rel in staged or any(s.startswith(rel) for s in staged)
            if changed:
                print(f"  ❌ {rel} — {lines} 行（上限 {LINE_LIMIT}），本次提交中修改")
                print("     💡 提拆分计划后才允许继续增大。详见 CLAUDE.md 工程规则 #7")
                violations += 1
            else:
                print(f"  ⚠️  {rel} — {lines} 行（上限 {LINE_LIMIT}），历史遗留（本次未修改）")
                print("     💡 下次修改该文件前必须先提拆分计划")
        elif lines > LINE_LIMIT * 0.85 and rel in staged:
            print(f"  ⚠️  {rel} — {lines} 行（接近上限 {LINE_LIMIT}），本次修改后需关注")
    return violations


def check_css_verification_required(staged: set[str]) -> int:
    """协作纪律 #14 + #16：CSS 令牌文件变更时提醒必须做 UI 验证。

    不阻塞提交。M4 后 CSS 令牌迁移至 Next.js Tailwind，此检查保留为占位。
    """
    css_changed = staged & CSS_FILES
    if not css_changed:
        return 0

    print("  ⚠️  以下 CSS 令牌文件已变更：")
    for f in sorted(css_changed):
        print(f"     - {f}")
    print("  💡 前端 CSS 验证请使用 Next.js 工具链（Tailwind + Playwright）。")
    return 0


# ═══════════════════════════════════════════════════════════════
# CSS 指令前置检查 — Tailwind v4 @theme/@apply 必须在 @import 后
# ═══════════════════════════════════════════════════════════════

# Tailwind v4 特有 at-rule — 需要 Tailwind 引擎才能处理
_TAILWIND_AT_RULES = (
    "@theme",
    "@apply",
    "@layer",
    "@config",
    "@variant",
    "@source",
    "@plugin",
    "@reference",
    "@custom-variant",
)

# 被视为"首行"前应跳过的行（纯空白 / 纯注释）
_SKIP_PATTERNS = ("/*", "*", "//")


def _first_directive_line(content: str) -> str:
    """返回文件的第一个非注释非空行（去空白后）。

    Args:
        content: 文件全文。

    Returns:
        首行内容（去前后空白），全空文件返回空字符串。
    """
    in_block_comment = False
    for line in content.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        # 处理块注释 /* ... */
        if in_block_comment:
            if "*/" in stripped:
                in_block_comment = False
            continue
        if stripped.startswith("/*"):
            if "*/" not in stripped:
                in_block_comment = True
            continue
        # 跳过单行注释 (CSS 中 /* ... */ 或 // 在某些预处理器中)
        if stripped.startswith("//"):
            continue
        return stripped
    return ""


def check_css_tailwind_directives(staged: set[str]) -> int:
    """确保使用 Tailwind 特有 at-rule 的 CSS 文件首行有 @import \"tailwindcss\"。

    只检查本次提交中变更的 CSS 文件。未变更的历史文件仅告警不阻断。

    Args:
        staged: 本次 git 暂存的文件集合。

    Returns:
        违规数（阻断级）。
    """
    violations = 0
    frontend_src = PROJECT_ROOT / "frontend" / "src"
    if not frontend_src.is_dir():
        return 0

    for css_file in sorted(frontend_src.rglob("*.css")):
        rel = str(css_file.relative_to(PROJECT_ROOT))
        try:
            content = css_file.read_text(encoding="utf-8")
        except Exception:
            continue

        # 检查文件是否使用了 Tailwind 特有 at-rule
        uses_tailwind_at_rule = any(rule in content for rule in _TAILWIND_AT_RULES)
        if not uses_tailwind_at_rule:
            continue  # 纯 CSS 文件（如 remixicon），无需 @import tailwindcss

        first_line = _first_directive_line(content)
        has_import = first_line.startswith('@import "tailwindcss"') or first_line.startswith(
            "@import 'tailwindcss'"
        )

        if not has_import:
            changed = rel in staged or any(rel.endswith(s) for s in staged)
            if changed:
                print(f'  ❌ {rel} — 使用了 Tailwind at-rule 但首行缺少 @import "tailwindcss"')
                print(f"     首行实际内容: {first_line[:80]}")
                violations += 1
            else:
                print(
                    f"  ⚠️  {rel} — 历史遗留："
                    '使用了 Tailwind at-rule 但首行缺少 @import "tailwindcss"'
                )
                print(f"     首行实际内容: {first_line[:80]}")
                print("     💡 下次修改该文件前必须先修复")

    return violations


def main() -> int:
    staged = _staged_files()

    print("=== 文件行数上限（工程规则 #7） ===")
    line_violations = check_file_line_counts(staged)
    if line_violations == 0:
        print("  ✅ 无新增超限文件")

    print("")
    print("=== CSS 变更 UI 验证提醒（纪律 #14 + #16） ===")
    css_warning = check_css_verification_required(staged)
    if css_warning == 0:
        print("  ✅ CSS 令牌文件无变更")

    print("")
    print("=== CSS Tailwind 指令前置检查（@theme/@apply/@layer 需 @import） ===")
    css_directive_violations = check_css_tailwind_directives(staged)
    if css_directive_violations == 0:
        print('  ✅ 所有 Tailwind CSS 文件首行均有 @import "tailwindcss"')

    print("")
    total_violations = line_violations + css_directive_violations
    if total_violations > 0:
        parts = []
        if line_violations > 0:
            parts.append(f"{line_violations} 个超限文件")
        if css_directive_violations > 0:
            parts.append(f"{css_directive_violations} 个 CSS 缺少 @import")
        print(f"❌ make check-safety 失败 — {' · '.join(parts)}")
        return 1
    print("✅ make check-safety 完成")
    return 0


if __name__ == "__main__":
    sys.exit(main())
