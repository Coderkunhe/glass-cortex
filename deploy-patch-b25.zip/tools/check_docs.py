#!/usr/bin/env python3
"""check-docs — 文档完整性 + 需求验证覆盖 + L2/L3/L4/L5 检查。

Replaces ~160 lines of inline Makefile bash with a single, testable Python
script. Each check is a focused function; the orchestrator runs them all and
reports a unified pass/fail summary.

Hard blockers (exit 1): roadmap sync, L5 interval > 2 batches.
All other checks are advisory (warnings print but don't block).
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import sys
from datetime import date, timedelta
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DOCS_DIR = PROJECT_ROOT / "docs"

# ── doc files that must exist ──────────────────────────────────────
REQUIRED_DOCS = [
    "docs/architecture.md",
    "docs/methodology.md",
    "docs/requirements-log.md",
    "docs/pitfalls.md",
    "docs/lessons-learned.md",
]

# ── .gitignore patterns that must be present ───────────────────────
GITIGNORE_CHECKS = {
    ".env": ".env 已忽略",
    "data/": "data/ 已忽略",
    "venv/": "venv/ 已忽略",
}

# ── documents checked for freshness against requirements-log ───────
FRESHNESS_TARGETS: list[tuple[str, str]] = [
    ("docs/roadmap.md", "roadmap.md"),
    ("docs/lessons-learned.md", "lessons-learned.md"),
]
FRESHNESS_WARN_ONLY: list[tuple[str, str]] = [
    ("docs/architecture.md", "architecture.md 实现表"),
    ("docs/research-strategy.md", "research-strategy.md"),
]


# ═══════════════════════════════════════════════════════════════════
# helpers
# ═══════════════════════════════════════════════════════════════════


def _rel(path: Path) -> str:
    """Return path relative to PROJECT_ROOT."""
    return str(path.relative_to(PROJECT_ROOT))


def _git_diff_names(path: str) -> list[str]:
    """Return files with unstaged changes under *path*."""
    try:
        result = subprocess.run(
            ["git", "diff", "--name-only", "HEAD", "--", path],
            capture_output=True,
            text=True,
            encoding="utf-8",
            cwd=PROJECT_ROOT,
            timeout=10,
        )
        return [p for p in (result.stdout or "").strip().split("\n") if p]
    except (OSError, subprocess.TimeoutExpired):
        return []


def _git_status_src_changes() -> list[str]:
    """Return unstaged, non-docs changed files (for roadmap sync check)."""
    try:
        result = subprocess.run(
            ["git", "status", "--porcelain"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            cwd=PROJECT_ROOT,
            timeout=10,
        )
        files: list[str] = []
        for line in (result.stdout or "").strip().split("\n"):
            if not line:
                continue
            # git status --porcelain: first two chars are status, then filename
            fpath = line[3:].strip()
            if fpath and not fpath.startswith("docs/") and not fpath.startswith('"'):
                files.append(fpath)
        return files
    except (OSError, subprocess.TimeoutExpired):
        return []


# ── incremental / patch-mode helpers ─────────────────────────────


def _get_changed_files() -> list[str]:
    """Return all changed files (unstaged + staged) for incremental check.

    Combines ``git diff --name-only HEAD`` (unstaged changes vs last commit)
    and ``git diff --name-only --cached`` (staged changes).
    """
    files: set[str] = set()
    for args in (
        ["git", "diff", "--name-only", "HEAD"],
        ["git", "diff", "--name-only", "--cached"],
    ):
        try:
            result = subprocess.run(
                args,
                capture_output=True,
                text=True,
                encoding="utf-8",
                cwd=PROJECT_ROOT,
                timeout=10,
            )
            for p in (result.stdout or "").strip().split("\n"):
                if p:
                    files.add(p)
        except (OSError, subprocess.TimeoutExpired):
            pass
    return sorted(files)


def _any_changed(*patterns: str) -> bool:
    """Return True if any changed file matches at least one glob pattern.

    Each *pattern* is a ``fnmatch``-style glob (e.g. ``docs/*.md``,
    ``src/**/*.py``).  Patterns are matched against repo-relative paths.
    """
    import fnmatch as _fnmatch

    changed = _get_changed_files()
    for fpath in changed:
        for pat in patterns:
            if _fnmatch.fnmatch(fpath, pat):
                return True
    return False


def _grep_first(pattern: str, path: Path) -> str | None:
    """Return first line matching *pattern* in *path*."""
    try:
        text = path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return None
    for line in text.splitlines():
        if re.search(pattern, line):
            return line.strip()
    return None


def _grep_count(pattern: str, path: Path) -> int:
    """Count lines matching *pattern* in *path*."""
    try:
        text = path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return 0
    return sum(1 for line in text.splitlines() if re.search(pattern, line))


def _extract_first_date(path: Path) -> str | None:
    """Extract the first YYYY-MM-DD date string from *path*."""
    try:
        text = path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return None
    m = re.search(r"(\d{4}-\d{2}-\d{2})", text)
    return m.group(1) if m else None


def _extract_dates_sorted(path: Path) -> list[str]:
    """Extract all YYYY-MM-DD dates from *path*, newest first."""
    try:
        text = path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return []
    dates = re.findall(r"(\d{4}-\d{2}-\d{2})", text)
    return sorted(set(dates), reverse=True)


def _run_python_tool(script: str, *args: str) -> tuple[int, str]:
    """Run a Python tool script and return (exit_code, stdout)."""
    tool_path = PROJECT_ROOT / "tools" / script
    cmd = [sys.executable, str(tool_path), *args]
    env = {**os.environ, "PYTHONPATH": str(PROJECT_ROOT)}
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            cwd=PROJECT_ROOT,
            timeout=60,
            env=env,
        )
        return result.returncode, result.stdout or ""
    except subprocess.TimeoutExpired:
        return 1, f"⏱  {script} 超时"
    except OSError as exc:
        return 1, f"❌ {script} 启动失败: {exc}"


def _run_ruff(*select: str, target: str) -> tuple[int, str]:
    """Run ruff with given select codes on a target directory."""
    # Use sys.executable's parent to locate ruff — works cross-platform
    # (venv/bin/ruff on Unix, venv\Scripts\ruff.exe on Windows)
    ruff_dir = Path(sys.executable).parent
    ruff = str(ruff_dir / "ruff")
    if not Path(ruff).exists():
        # Fallback: search PATH
        import shutil as _shutil

        _found = _shutil.which("ruff")
        if _found:
            ruff = _found
    cmd = [ruff, "check", "--select", ",".join(select), target]
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            cwd=PROJECT_ROOT,
            timeout=60,
        )
        return result.returncode, result.stdout or ""
    except subprocess.TimeoutExpired:
        return 1, "⏱  ruff 超时"
    except OSError as exc:
        return 1, f"❌ ruff 不可用: {exc}"


def _today() -> str:
    return date.today().isoformat()


def _yesterday() -> str:
    return (date.today() - timedelta(days=1)).isoformat()


# ═══════════════════════════════════════════════════════════════════
# individual checks — each returns (exit_code, lines)
#   exit_code 0 = pass or advisory warning, 1 = hard block
# ═══════════════════════════════════════════════════════════════════


def check_uncommitted_docs() -> tuple[int, list[str]]:
    """Check for uncommitted changes under docs/."""
    changed = _git_diff_names("docs/")
    if changed:
        return 0, [f"  📝 {f}" for f in changed]
    return 0, ["  (无未提交变更)"]


def check_requirements_last_update() -> tuple[int, list[str]]:
    """Show the most recent dated entry in requirements-log.md."""
    req_log = DOCS_DIR / "requirements-log.md"
    if not req_log.exists():
        return 0, ["⚠️  docs/requirements-log.md 不存在"]
    match = _grep_first(r"^### \d{4}-\d{2}-\d{2}", req_log)
    if match:
        return 0, [f"  {match}"]
    return 0, ["⚠️  未找到带日期的需求条目"]


def check_doc_files_exist() -> tuple[int, list[str]]:
    """Verify required documentation files exist."""
    lines: list[str] = []
    for doc in REQUIRED_DOCS:
        if (PROJECT_ROOT / doc).exists():
            lines.append(f"  ✅ {doc}")
        else:
            lines.append(f"  ❌ {doc} 缺失")
    return 0, lines


def check_requirements_files() -> tuple[int, list[str]]:
    """Verify requirements.in and requirements-lock.txt exist."""
    lines: list[str] = []
    for fname, missing_msg in [
        ("requirements.in", "requirements.in 缺失"),
        ("requirements-lock.txt", "requirements-lock.txt 缺失 — 运行 pip-compile 或 make setup"),
    ]:
        if (PROJECT_ROOT / fname).exists():
            lines.append(f"  ✅ {fname}")
        else:
            lines.append(f"  ❌ {missing_msg}")
    return 0, lines


def check_gitignore() -> tuple[int, list[str]]:
    """Verify .gitignore covers .env, data/, venv/."""
    gitignore = PROJECT_ROOT / ".gitignore"
    lines: list[str] = []
    if not gitignore.exists():
        for pattern in GITIGNORE_CHECKS:
            lines.append(f"  ⚠️  .gitignore 不存在，无法检查 {pattern}")
        return 0, lines

    try:
        content = gitignore.read_text(encoding="utf-8")
    except OSError:
        lines.append("  ⚠️  .gitignore 存在但无法读取")
        return 0, lines
    for pattern, ok_msg in GITIGNORE_CHECKS.items():
        if pattern in content:
            lines.append(f"  ✅ {ok_msg}")
        else:
            lines.append(f"  ⚠️  {pattern} 未在 .gitignore")
    return 0, lines


def check_daily_report() -> tuple[int, list[str]]:
    """Verify yesterday's daily report exists."""
    yesterday = _yesterday()
    daily = DOCS_DIR / "daily" / f"{yesterday}.md"
    if daily.exists():
        return 0, [f"  ✅ 昨日日报 docs/daily/{yesterday}.md"]
    return 0, [f"  ⚠️  昨日日报 docs/daily/{yesterday}.md 缺失 — 请 git log 反推补写"]


def check_requirement_verification_coverage() -> tuple[int, list[str]]:
    """Check that every dated requirement entry has a verification annotation."""
    req_log = DOCS_DIR / "requirements-log.md"
    if not req_log.exists():
        return 0, ["⚠️  docs/requirements-log.md 不存在"]

    entries = _grep_count(r"^### 20\d{2}-\d{2}-\d{2} — ", req_log)
    verifies = _grep_count("验证方式", req_log)

    if entries > verifies:
        return 0, [
            f"  ❌ {entries} 条需求, 仅 {verifies} 条有验证方式 — 补齐后再提交",
            *[f"    {line}" for line in _grep_lines(r"^### 20\d{2}", req_log)],
        ]
    return 0, [f"  ✅ {entries} 条需求, {verifies} 条有验证方式"]


def _grep_lines(pattern: str, path: Path) -> list[str]:
    """Return all lines matching *pattern* in *path*."""
    try:
        text = path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return []
    return [line.strip() for line in text.splitlines() if re.search(pattern, line)]


def check_plan_files() -> tuple[int, list[str]]:
    """Check that ~/.claude/plans/ isn't accumulating stale plan files."""
    plans_dir = Path.home() / ".claude" / "plans"
    if not plans_dir.exists():
        return 0, ["  ✅ ~/.claude/plans/ 不存在，无需清理"]

    plan_files = list(plans_dir.glob("*.md"))
    count = len(plan_files)
    if count > 2:
        return 0, [f"  ⚠️  ~/.claude/plans/ 有 {count} 个 Plan 文件（阈值为 2），建议清理已交付的"]
    return 0, ["  ✅ Plan 文件 ≤2，无需清理"]


def check_doc_freshness() -> tuple[int, list[str]]:
    """Check that key docs are not stale relative to requirements-log."""
    req_log = DOCS_DIR / "requirements-log.md"
    req_date = _extract_first_date(req_log)
    if not req_date:
        return 0, ["⚠️  无法从 requirements-log.md 提取日期，跳过新鲜度检查"]

    lines: list[str] = []

    # Hard-warn targets (roadmap, lessons-learned) — use newest date
    for doc_path, label in FRESHNESS_TARGETS:
        dates = _extract_dates_sorted(PROJECT_ROOT / doc_path)
        doc_date = dates[0] if dates else None
        if doc_date and doc_date < req_date:
            lines.append(f"  ⚠️  {label} 最后更新({doc_date}) 落后于需求日志({req_date})，需刷新")
        elif doc_date:
            lines.append(f"  ✅ {label} 日期新鲜 ({doc_date})")

    # Soft-warn targets (architecture, research-strategy)
    for doc_path, label in FRESHNESS_WARN_ONLY:
        dates = _extract_dates_sorted(PROJECT_ROOT / doc_path)
        if dates and dates[0] < req_date:
            lines.append(f"  ⚠️  {label} 最新日期({dates[0]}) 落后于需求日志({req_date})，需刷新")

    # methodology.md vs CLAUDE.md last modification date
    meth_date = _extract_first_date(DOCS_DIR / "methodology.md")
    try:
        result = subprocess.run(
            ["git", "log", "-1", "--format=%as", "--", "CLAUDE.md"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            cwd=PROJECT_ROOT,
            timeout=10,
        )
        claude_date = (result.stdout or "").strip()
    except (OSError, subprocess.TimeoutExpired):
        claude_date = ""

    if meth_date and claude_date and meth_date < claude_date:
        lines.append(
            f"  ⚠️  methodology.md 最后更新({meth_date}) 落后于 CLAUDE.md 最后修改"
            f"({claude_date}) —— 协作规范有变更但方法论未同步"
        )

    return 0, lines


def check_roadmap_sync() -> tuple[int, list[str]]:
    """Hard-block: if src changes exist, roadmap.md date must be today."""
    src_changes = _git_status_src_changes()
    if not src_changes:
        return 0, ["  ✅ 无源码变更，跳过检查"]

    roadmap = DOCS_DIR / "roadmap.md"
    if not roadmap.exists():
        return 1, ["  ❌ roadmap.md 不存在，无法验证同步"]

    # Extract date from "> 最后更新: YYYY-MM-DD" line
    try:
        roadmap_text = roadmap.read_text(encoding="utf-8")
    except OSError:
        return 1, ["  ❌ roadmap.md 存在但无法读取"]
    m = re.search(r"最后更新:\s*(\d{4}-\d{2}-\d{2})", roadmap_text)
    roadmap_date = m.group(1) if m else ""
    today = _today()

    if roadmap_date != today:
        return 1, [
            f"  ❌ 源码有未提交变更但 roadmap.md 日期({roadmap_date}) ≠ 今天({today})",
            "  💡 源码变更必须在同一天刷新 roadmap.md 的「最后更新」日期",
        ]
    return 0, [f"  ✅ 源码变更已同步 roadmap 日期 ({today})"]


def check_shared_modules() -> tuple[int, list[str]]:
    """Delegate to tools/check_shared_modules.py (advisory)."""
    rc, stdout = _run_python_tool("check_shared_modules.py")
    return 0, [stdout]  # always advisory


def check_l5_interval() -> tuple[int, list[str]]:
    """Hard-block: ≥2 batches since last L5 handshake.

    Data source: .claude/l5-checkpoint.json (same as l5-gate.sh pre-commit hook).
    Unified in B123 to eliminate dual-source drift between l5-gate.sh and check_docs.py.
    """
    checkpoint = PROJECT_ROOT / ".claude" / "l5-checkpoint.json"
    if not checkpoint.exists():
        return 0, ["  ⚠️  .claude/l5-checkpoint.json 不存在 — 假定首个 Batch，门禁放行"]

    try:
        data = json.loads(checkpoint.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return 0, ["  ⚠️  无法解析 l5-checkpoint.json — 跳过 L5 间隔检查"]

    count = data.get("batchesSinceLastL5", 0)
    last = data.get("lastL5Batch", "unknown")
    batches = data.get("completedBatches", [])

    if count >= 2:
        batch_list = ", ".join(batches) if batches else "none"
        return 1, [
            f"  ❌ 最近一次 L5 拉通自检后已累积 {count} 个 Batch — 铁律 10 要求每 2 批拉通一次",
            f"    上次 L5: {last}",
            f"    未拉通 Batch: {batch_list}",
            '  💡 执行 L5 拉通后运行: bash tools/l5-reset.sh "Bx→By 拉通"',
        ]
    return 0, [f"  ✅ L5 拉通自检间隔正常（最近一次后累积 {count} 个 Batch）"]


def check_skeleton_tests() -> tuple[int, list[str]]:
    """Warn about test files with ≤3 test functions."""
    tests_dir = PROJECT_ROOT / "tests"
    if not tests_dir.exists():
        return 0, ["⚠️  tests/ 目录不存在"]

    min_tests = 3
    low_files: list[tuple[str, int]] = []

    for f in sorted(tests_dir.glob("test_*.py")):
        count = _grep_count(r"def test_", f)
        if count <= min_tests:
            low_files.append((_rel(f), count))

    lines: list[str] = []
    for fpath, count in low_files:
        lines.append(
            f"  ⚠️  {fpath} — {count} 条测试（≤{min_tests} 为骨架，可能未覆盖边界/异常路径）"
        )
    if low_files:
        lines.append("  💡 骨架测试只定义契约——请补齐边界/空值/异常路径后再交付")
    else:
        lines.append(f"  ✅ 所有测试文件 >{min_tests} 条测试")
    return 0, lines


def check_contracts() -> tuple[int, list[str]]:
    """Delegate to tools/check_contracts.py."""
    rc, stdout = _run_python_tool("check_contracts.py", "check")
    # contract check is advisory in the check-docs context
    return 0, [stdout.strip()]


def check_comments() -> tuple[int, list[str]]:
    """Run ruff pydocstyle checks (D100/D104/D103/D101) via subprocess.

    This mirrors the standalone `make check-comments` target behavior.
    Returns hard-fail (1) if any ruff check fails — pydocstyle violations
    are blocking per 协作纪律 17.
    """
    lines: list[str] = []
    hard_fail = 0

    # D100/D104: module-level docstrings
    lines.append("=== D100/D104 模块级 docstring ===")
    for target in ["api/", "src/"]:
        rc, stdout = _run_ruff("D100", "D104", target=target)
        if rc != 0:
            lines.append(stdout.strip())
            lines.append(f"  ❌ {target} 模块级 docstring 缺失 — 基线不退，立即修复")
            hard_fail = 1
        else:
            lines.append(f"  ✅ {target} 模块级 docstring 全覆盖")

    lines.append("")
    lines.append("=== D103 公开函数 docstring ===")
    for target in ["api/", "src/"]:
        rc, stdout = _run_ruff("D103", target=target)
        if rc != 0:
            lines.append(stdout.strip())
            lines.append(f"  ❌ {target} 公开函数缺 docstring — 基线不退")
            hard_fail = 1
        else:
            lines.append(f"  ✅ {target} 公开函数 docstring 全覆盖")

    lines.append("")
    lines.append("=== D101 公开类 docstring ===")
    for target in ["api/", "src/"]:
        rc, stdout = _run_ruff("D101", target=target)
        if rc != 0:
            lines.append(stdout.strip())
            lines.append(f"  ❌ {target} 公开类缺 docstring — 基线不退")
            hard_fail = 1
        else:
            lines.append(f"  ✅ {target} 公开类 docstring 全覆盖")

    return hard_fail, lines


def check_violations() -> tuple[int, list[str]]:
    """扫描 docs/violations.md 活跃违纪段。

    统计 ## 🔴 活跃违纪 段中 状态 != 🟢 的 VIO 条目。
    ≥1 🔴 → exit 1 硬阻断。🟡 仅告警不阻断。
    同时统计触发日志条数 + 已闭环数，输出汇总行。
    """
    violations_path = DOCS_DIR / "violations.md"
    if not violations_path.exists():
        return (0, ["⚠️ docs/violations.md 不存在，跳过违纪检查"])

    try:
        content = violations_path.read_text(encoding="utf-8")
    except OSError:
        return (0, ["⚠️ 无法读取 docs/violations.md，跳过违纪检查"])

    in_active_section = False
    in_closed_section = False
    active_red = 0
    active_yellow = 0
    closed_count = 0
    trigger_log_count = 0

    for line in content.splitlines():
        # Section boundary detection
        if line.startswith("## 📋 触发日志"):
            in_active_section = False
            in_closed_section = False
            continue
        elif line.startswith("## 🔴 活跃违纪"):
            in_active_section = True
            in_closed_section = False
            continue
        elif line.startswith("## ✅ 已闭环"):
            in_active_section = False
            in_closed_section = True
            continue
        elif line.startswith("## "):
            in_active_section = False
            in_closed_section = False
            continue

        if in_active_section:
            if "- **状态**: 🔴" in line:
                active_red += 1
            elif "- **状态**: 🟡" in line:
                active_yellow += 1

        # Count closed VIO entries (only in ✅ 已闭环 section)
        if in_closed_section and "- **状态**: 🟢" in line:
            closed_count += 1

        # Count trigger log table rows (date-prefixed)
        if line.startswith("| 202"):
            trigger_log_count += 1

    lines: list[str] = []
    total_active = active_red + active_yellow

    # Stats summary
    lines.append(
        f"📊 违纪统计: 触发日志 {trigger_log_count} 条 · "
        f"VIO 活跃 {total_active} 条 "
        f"(🟡 {active_yellow} / 🔴 {active_red}) · "
        f"已闭环 {closed_count} 条"
    )

    if active_red > 0:
        lines.append(f"❌ {active_red} 条违纪未闭环，拒绝提交")
        return (1, lines)

    if active_yellow > 0:
        lines.append(f"⚠️ {active_yellow} 条违纪处于观察期")

    return (0, lines)


# ═══════════════════════════════════════════════════════════════════
# orchestrator
# ═══════════════════════════════════════════════════════════════════

# Each check: (section_title, check_fn, is_critical)
# is_critical=True → hard block; is_critical=False → advisory

# ── changed-only skip patterns ──────────────────────────────────
# Maps check title → list of fnmatch globs.  None = always run.
# Used by --changed-only / -c flag to skip checks whose files
# haven't changed.
CHECK_SKIP_PATTERNS: dict[str, list[str] | None] = {
    "docs/ 未提交变更": None,  # always — already minimal
    "需求日志最后更新时间": ["docs/requirements-log.md"],
    "文档文件存在性检查": None,  # always — stat only
    "requirements.in 存在性": ["requirements.in", "requirements-lock.txt"],
    ".gitignore 检查": [".gitignore"],
    "日报存在性检查": None,  # always — lightweight
    "需求验证覆盖检查": ["docs/requirements-log.md"],
    "Plan 文件清理检查": None,  # always — lightweight (~/.claude/plans/)
    "文档新鲜度检查": [
        "docs/roadmap.md",
        "docs/lessons-learned.md",
        "docs/architecture.md",
        "docs/research-strategy.md",
        "docs/methodology.md",
        "docs/requirements-log.md",
    ],
    "Roadmap 同步门禁": None,  # always — has own _git_status_src_changes guard
    "L2f Shared Module Governance — 消费者统计 + Risk Assessment 覆盖": [
        "src/**/*.py",
        "api/**/*.py",
        "frontend/src/**/*.ts",
        "frontend/src/**/*.tsx",
    ],
    "L5 拉通自检间隔检查": None,  # always — JSON read only
    "L2e 测试覆盖度 — 骨架测试检测": ["tests/test_*.py"],
    "L3 契约完整性 — 接口签名变更影响分析": ["api/**/*.py", "src/**/*.py"],
    "规范性注释检查": ["api/**/*.py", "src/**/*.py"],
    "违纪闭环检查": ["docs/violations.md"],
}

CHECKS: list[tuple[str, object, bool]] = [
    ("docs/ 未提交变更", check_uncommitted_docs, False),
    ("需求日志最后更新时间", check_requirements_last_update, False),
    ("文档文件存在性检查", check_doc_files_exist, False),
    ("requirements.in 存在性", check_requirements_files, False),
    (".gitignore 检查", check_gitignore, False),
    ("日报存在性检查", check_daily_report, False),
    ("需求验证覆盖检查", check_requirement_verification_coverage, False),
    ("Plan 文件清理检查", check_plan_files, False),
    ("文档新鲜度检查", check_doc_freshness, False),
    ("Roadmap 同步门禁", check_roadmap_sync, True),
    (
        "L2f Shared Module Governance — 消费者统计 + Risk Assessment 覆盖",
        check_shared_modules,
        False,
    ),
    ("L5 拉通自检间隔检查", check_l5_interval, True),
    ("L2e 测试覆盖度 — 骨架测试检测", check_skeleton_tests, False),
    ("L3 契约完整性 — 接口签名变更影响分析", check_contracts, False),
    ("规范性注释检查", check_comments, True),
    ("违纪闭环检查", check_violations, True),
]


def main() -> int:
    """Run all checks and print results. Use --json for machine-readable output."""
    import argparse

    parser = argparse.ArgumentParser(description="check-docs — 文档完整性检查")
    parser.add_argument("--json", action="store_true", help="输出 JSON 格式（供 API 消费）")
    parser.add_argument(
        "--changed-only",
        "-c",
        action="store_true",
        help="增量模式：仅检查有变更文件的 check，跳过无关联的重量级检查",
    )
    args = parser.parse_args()

    if args.json:
        return _main_json(changed_only=args.changed_only)

    hard_failures = 0
    skipped_count = 0

    for title, check_fn, is_critical in CHECKS:
        # ── changed-only skip logic ──
        if args.changed_only:
            patterns = CHECK_SKIP_PATTERNS.get(title)
            if patterns is not None and not _any_changed(*patterns):
                print(f"=== {title} === ⏭ 跳过（无变更文件）")
                print()
                skipped_count += 1
                continue

        print(f"=== {title} ===")
        try:
            rc, output_lines = check_fn()  # type: ignore[operator]
        except Exception as exc:
            rc = 1
            output_lines = [f"❌ 检查异常: {exc}"]
        for line in output_lines:
            print(line)
        print()
        if rc != 0 and is_critical:
            hard_failures += 1

    if args.changed_only and skipped_count:
        print(f"💡 增量模式：跳过 {skipped_count} 项无变更检查。完整检查: make check-docs")

    if hard_failures:
        print(f"❌ check-docs 失败 — {hard_failures} 项硬阻断未通过")
        return 1
    print("✅ check-docs 完成")
    return 0


def _main_json(changed_only: bool = False) -> int:
    """Run all checks and output structured JSON for API consumption."""
    results: dict[str, dict[str, object]] = {}
    hard_failures = 0

    for title, check_fn, is_critical in CHECKS:
        # ── changed-only skip logic ──
        if changed_only:
            patterns = CHECK_SKIP_PATTERNS.get(title)
            if patterns is not None and not _any_changed(*patterns):
                results[title] = {
                    "exit_code": 0,
                    "is_critical": is_critical,
                    "lines": [],
                    "skipped": True,
                }
                continue

        try:
            rc, output_lines = check_fn()  # type: ignore[operator]
        except Exception as exc:
            rc = 1
            output_lines = [f"❌ 检查异常: {exc}"]
        results[title] = {
            "exit_code": rc,
            "is_critical": is_critical,
            "lines": output_lines,
        }
        if rc != 0 and is_critical:
            hard_failures += 1

    # ── Git log summary ──
    try:
        glog = subprocess.run(
            ["git", "log", "--oneline", "-10", "--format=%h %s (%ad)", "--date=short"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            cwd=PROJECT_ROOT,
            timeout=10,
        )
        recent_commits = [line.strip() for line in (glog.stdout or "").strip().split("\n") if line]
    except (OSError, subprocess.TimeoutExpired):
        recent_commits = []

    # ── Current Phase/Batch ──
    latest_msg = recent_commits[0] if recent_commits else ""
    phase_batch_match = re.search(r"Phase\s*(\d+)\s*Batch\s*(\d+)", latest_msg)
    current_phase = phase_batch_match.group(1) if phase_batch_match else None
    current_batch = phase_batch_match.group(2) if phase_batch_match else None

    # ── Daily report status ──
    yesterday = _yesterday()
    today = _today()
    daily_yesterday = DOCS_DIR / "daily" / f"{yesterday}.md"
    daily_today = DOCS_DIR / "daily" / f"{today}.md"

    # ── Doc freshness (simplified for JSON) ──
    req_log = DOCS_DIR / "requirements-log.md"
    req_date = _extract_first_date(req_log)
    doc_dates: dict[str, str | None] = {}
    for doc_path, _label in FRESHNESS_TARGETS + FRESHNESS_WARN_ONLY:
        dates = _extract_dates_sorted(PROJECT_ROOT / doc_path)
        doc_dates[doc_path] = dates[0] if dates else None

    # ── Violations summary ──
    vio_rc, vio_lines = check_violations()
    vio_text = "\n".join(vio_lines)

    # ── L5 interval ──
    checkpoint_file = PROJECT_ROOT / ".claude" / "l5-checkpoint.json"
    l5_count = 0
    l5_last_batch = "unknown"
    try:
        if checkpoint_file.exists():
            cp = json.loads(checkpoint_file.read_text(encoding="utf-8"))
            l5_count = cp.get("batchesSinceLastL5", 0)
            l5_last_batch = cp.get("lastL5Batch", "unknown")
    except (OSError, json.JSONDecodeError):
        pass

    output: dict[str, object] = {
        "timestamp": _today(),
        "hard_failures": hard_failures,
        "current_phase": current_phase,
        "current_batch": current_batch,
        "recent_commits": recent_commits[:5],
        "l5": {
            "batches_since_last": l5_count,
            "last_l5_batch": l5_last_batch,
            "blocked": l5_count >= 2,
        },
        "daily": {
            "yesterday_exists": daily_yesterday.exists(),
            "yesterday_date": yesterday,
            "today_exists": daily_today.exists(),
            "today_date": today,
        },
        "violations": {
            "summary": vio_text,
            "is_blocked": vio_rc != 0,
        },
        "doc_freshness": {
            "requirements_last_date": req_date,
            "doc_dates": doc_dates,
        },
        "checks": results,
    }

    print(json.dumps(output, ensure_ascii=False, indent=2))
    return 1 if hard_failures else 0


if __name__ == "__main__":
    # Reconfigure stdout for UTF-8 to prevent UnicodeEncodeError on
    # Windows consoles with non-UTF-8 code pages (e.g. GBK/CP936).
    # ensure_ascii=False produces readable CJK output in JSON mode.
    try:
        sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[union-attr]  # mypy typeshed lacks reconfigure
    except Exception:
        pass
    sys.exit(main())
