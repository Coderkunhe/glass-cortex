# 开发路线图

> 最后更新: 2026-08-09 (Phase 67 B25 — Windows Python 3.12 兼容性全线加固)
> 执行规则：每批 2-4 个任务，完成即验证，验证不过不进下一批。

---

## 已交付能力地图

> 按用户可感知的维度组织，不按时间/Phase 编号。**新人先读此地图**，再按需纵向深入对应 Phase。

| 能力维度 | 用户看到什么 | 关键交付 | 入口 Phase |
|---------|-------------|---------|:---------:|
| 💬 **AI 对话** | 聊天界面，发送消息，流式响应 | ChatEngine + ChatPanel + useChat | Phase 6-8, 28 |
| 📖 **文档阅读** | `/learn` 95 问答案，章节导航，流程图 | AnswerCard + QuestionList + MermaidDiagram | Phase 29, Dir A |
| 🧪 **可观测实验室** | Token/缓存/嵌入/知识图谱/衰减面板 | 14 lab panels + DataState 三态统一 | Phase 29 (166-177) |
| 🧠 **记忆系统** | 三元组抽取/存储/召回/遗忘 | SQLite + FAISS + Recall + Forget | Phase 1-5 |
| 👤 **用户画像** | Profile 页，记忆纠正/加星，使用统计 | ProfileShell + memory control | Phase 30 |
| 🎨 **视觉系统** | 暗/亮主题，统一色彩/动画/间距 | CSS tokens (82 vars) + z-index 6 层 + duration 体系 | Phase 31, 33 |
| 🏗️ **共享组件库** | 一致的 Drawer/KV/Collapse/Button 体验 | 7 组件提取，净删 ~400 行重复 | Phase 31 |
| 🛡️ **报错体验** | 分类报错文案，重试按钮，不暴露代码 | ErrorDisplay + categorizeError + DataState | Phase 31, 33 |
| 📱 **响应式布局** | 移动端可用（聊天/文档/画像） | CSS Grid + hamburger nav + sidebar slot | Phase 33 |
| 🔬 **上下文工程** | 上下文分区可视化，溢出模拟 | ContextPanel + overflow_sim + partition | Phase 17, 29 |
| 💰 **Token 效率** | 全链路计量，缓存命中率面板 | TokenLedger + cache layer | Phase 17, 29 |
| 🎯 **任务规划** | 意图分类→任务分解→历史检索→反思循环 | Planner L1-L3 全栈 + PlanHistory + ReflectionEngine | Phase 37, 53, 57, 60, 61 |

> **阅读路径**：了解"项目能做什么"→ 读此表。了解"怎么做的"→ 纵向深入对应 Phase。了解"接下来做什么"→ [`docs/master-backlog.md`](master-backlog.md) — 活跃待办看板，单屏可扫。

---

## Phase 1-18 — 已完成（已归档）

> 详细任务表已归档至 `docs/archive/roadmap-phase-1-18.md`。
> 关键指标: 131 commits · 76 Batches · 11,631 源码行 · 519 tests · 11 ADR。
> 核心链路: 记忆引擎 → AI 对话 → Streamlit Web → 10 层透明化模型 → 可观测性基础设施 → 四支柱叙事落地 → 技术债治理。
> 完成总结见下方 Phase 1-18 完成总结段。

---

## Phase 1-18 完成总结

> 2026-06-20，Phase 18 Batch 76 收尾，`_core.py` 删除。

### 关键数字

| 指标 | 数值 |
|------|------|
| 开发跨期 | 2026-06-15 → 06-20（5.5 天） |
| Commits | 131 |
| Batches | 76 |
| 源码行数 | 11,631（40 文件） |
| 测试行数 | 8,376（29 文件） |
| 测试函数 | 519 |
| ADR 决策 | 11 条 |
| 已完成组件 | 66 个 |

### 架构演进

```
Phase 1-5      Phase 6-8      Phase 9-15       Phase 16          Phase 17           Phase 18
核心记忆引擎   AI 对话+Web    UI 现代化        可观测性           四支柱叙事         技术债治理
──────────→   ──────────→   ───────────→    ──────────→       ──────────→        ──────────→
Store/FAISS    ChatEngine    三页导航         结构化日志         项目地图           上帝拆分
Embed/Recall   Streamlit     CSS 令牌+暗色    健康检查           Token 缓存         异常收窄
Forgetting     Fact 层       动画+材质         trace 持久化       上下文分区         cache 接入
CLI+Rich       三元组+Token  Header/Sidebar   仪表盘+日志查看    消息压缩            L4 治理
                               L0-L10 11层                        Planner L1
                                                                 六镜头旅程 V2
```

### 方法论沉淀

- **8 步端到端工作流**: Pre-flight → Plan → 拆分 → TDD → 五层自检 → 文档闭环 → 推送 → 清理 Plan
- **五层自检金字塔**: L1 语法 → L2 引用完整性 → L3 契约兼容性 → L4 运行时状态路径 → L5 人因走查（每 2 Batch）
- **三层沉淀**: 规则 → CLAUDE.md / 模式 → methodology.md / 执行 → settings.json hooks
- **21 个反模式**已记录，含症状和纠正方案

### 研究四支柱进度

| 支柱 | 已交付 | 待交付 |
|------|--------|--------|
| 1. 记忆设计 | 三元组抽取 + 冲突检测 + 双层模型 | 多层存储 (hot/warm/cold)、MMR 召回、记忆固化 |
| 2. 上下文工程 | 分区可视化 + 截断 + 压缩 | 预算机制、按需展开、跨会话连续性 |
| 3. Token 效率 | 全链路计量 + embedding/fact 缓存 + 消息压缩 | 分级响应、模型路由 |
| 4. 任务规划 | L1 意图分类 (5 类) + Plan 生成/存储 + API 查询 | Plan 存储 API 端点 + 前端接入、记忆引导规划、动态重规划、反思循环 |

### 已知局限（不留坑）

- `src/web/components/` 7 模块 5,548 行零测试 — Streamlit widget 渲染输出，单元测试性价比低，已评估接受
- 配置外化不彻底 — 3 个文件名在 5 文件重复 13 次，Phase 20 处理
- CSS 7 个孤儿选择器待清理 — ✅ Phase 20A 已清理
- L2c check-docs 脚本 bug 已修复 — sed 类名提取现在正确剥离文件名前缀

---

## Phase 19 — 项目总结归档 ✅

**目标**：Phase 1-18 全景回顾，项目记忆刷新，研究路线图标注。

| # | 任务 | 状态 |
|---|------|------|
| 19.1 | project_phase.md 记忆刷新 → Phase 18 完成 | ✅ |
| 19.2 | project_governance_phase.md 标记关闭 | ✅ |
| 19.3 | roadmap.md 追加 Phase 1-18 完成总结（本段） | ✅ |
| 19.4 | research-strategy.md 四支柱进度刷新 | ✅ |
| 19.5 | requirements-log.md 追加 Phase 19 条目 | ✅ |

---

## Phase 20 — 治理收尾

### 20A — CSS 孤儿清理 + 内联迁移 ✅

| # | 任务 | 状态 |
|---|------|------|
| 20A.1 | `_tokens.py` 删除 7 个孤儿选择器（26 行） | ✅ |
| 20A.2 | `observability.py` 6 个内联 CSS 类迁移至 `_tokens.py`（17 行） | ✅ |
| 20A.3 | `make check` 519 passed + `make check-docs` 全绿 | ✅ |
| — | Bug fix: header 菜单 drawer 间歇打不开 — 单帧 rAF → 轮询重试 | ✅ |
| — | Bug fix: L2c 检查脚本 sed 类名提取修复 — 文件名前缀剥离 | ✅ |

### 20B — 配置外化 ✅

| # | 任务 | 状态 |
|---|------|------|
| 20B.1 | `config.py` 新增 4 个模块常量（DB_FILENAME / INDEX_FILENAME / LOG_FILENAME / REMIX_ICON_CDN） | ✅ |
| 20B.2 | 替换 7 文件 17 处硬编码引用 | ✅ |
| 20B.3 | `make check` 519 passed + `make check-docs` 全绿 | ✅ |

**决策记录**：
- 常量放在 `config.py` 模块级而非 Settings dataclass 内：这些值不属于"实验可覆盖"配置，修改它们意味着数据文件名变更（需要迁移），放宽访问门槛（import 即用，无需 settings 实例）
- 受影响的 7 个文件：config.py / bootstrap.py / logging.py / web/init.py / web/app.py / web/components/shared.py / web/pages/observability.py
- 总共替换 17 处硬编码引用（"memory.db" 6 → "index.faiss" 9 → "glasscortex.log" 2 → CDN URL 1），部分转换为 Path 串联

---

## Phase 21 — 从用户触点逐层深挖上下文窗口

**战略定位**：Phase 20 治理收尾完成。Phase 21 从用户最先碰到的硬限制——上下文窗口溢出——入手，逐层串联四大支柱（记忆设计/上下文工程/Token效率/任务规划）。

**设计原则**：
- **用户触点驱动** — 每个功能从"用户遇到什么问题"出发，不是从技术模块出发
- **文档即知识层** — 地图术语表 + tooltip 形成双向链接：功能→文档→功能
- **渐进式信息披露** — 分区条（摘要）→ 营养标签（详情）→ 沙箱（深度实验）
- **策略人格化** — 守门员 (FIFO) · 策展人 (相关度优先) · 口述史家 (压缩摘要)

### ✅ Batch 79 — 溢出模拟引擎 + 营养标签 + 策略人格（已完成）

| # | 任务 | 状态 | 说明 |
|---|------|------|------|
| 79.1 | `src/context/overflow_sim.py` — `OverflowSimResult` + `simulate_overflow()` + `compare_strategies()` | ✅ | 从 ChatEngine 提取溢出逻辑为纯函数，三策略独立可测 |
| 79.2 | `tests/test_overflow_sim.py` — 23 tests | ✅ | 7 类：dataclass / 无溢出 / truncate / prioritize / summarize / compare / personas |
| 79.3 | `_NUTRITION_LABEL_CSS` + 策略人格/溢出 badge/时间线/pillar badge/ghost prompt 样式 | ✅ | FDA 营养标签风格，零 JS 依赖 |
| 79.4 | `render_nutrition_label()` / `render_strategy_persona()` / `render_overflow_badge()` / `render_raw_prompt_view()` | ✅ | 4 个新 UI 渲染函数，chat.py 导出 |
| 79.5 | 地图术语表扩充 + Phase 21 条目 | ✅ | 新增 5 条：上下文窗口/Token预算/策略人格/MMR召回/Phase 21 |

**证据**：`make check` 542 passed · lint zero · mypy zero

### 后续批次

| 批次 | 核心改动 | 状态 |
|------|---------|------|
| 80 | 溢出沙箱 Tab (Lab) + 上下文时间线 + Ghost Mode | ✅ |
| 81 | 实时溢出叙事 + 智能预检 + Badge + 地图联动 | ✅ |
| 82 | 记忆去重 + MMR 召回 + "遗憾"分析 | ✅ |
| 83 | 四支柱端到端旅程 + 文档知识层贯通 | ✅ |

详见 `plans/cozy-finding-lightning.md`。

---

## Phase 22 — 技术债治理 + 体验优化

**战略定位**：Phase 21 四支柱端到端交付完成。Phase 22 不扩展新功能域，聚焦补齐测试、清理技术债、打磨体验。三个子目标：

1. **夯实** — 补测试（页面组装层 + 集成测试 + CLI），从 17% 未覆盖压到 <10%
2. **清理** — 清 CSS 孤儿/死 keyframe、合并重复注入、px→token、填 __init__.py 空壳
3. **打磨** — 暗色 config.toml、inline JS→CSS hover、st.cache、XSS 审计

**扫描来源**：2026-06-20 三线扫描（技术债 / 测试覆盖 / UI 体验），全量发现 59 条，入 Phase 22 共 28 条。

### ✅ Batch 84 — P0 缺陷修复（已完成）

| # | 任务 | 状态 | 说明 | 证据 |
|---|------|------|------|------|
| 84.1 | 修复 observability.py 3 个未定义 CSS 变量 | ✅ | `--gm-text-primary`→`--gm-text` / `--gm-font-mono`→`--gm-mono` / `--gm-surface-raised`→`--gm-surface-elevated` | 9 处替换，`make check` 全绿 |
| 84.2 | 修复 `gm-journey-card` 基类未定义 | ✅ | `_tokens.py` 补 `.gm-journey-card` 基础样式，chat.py 删 10 行 inline style 冗余属性 | `_tokens.py` +10 行 CSS，`chat.py` -9 行 inline，573 tests pass |
| 84.3 | 修复 observability 页双重 CSS 注入 | ✅ | `render_observability_page()` 删重复的 `inject_global_css()` 调用 | 删除 import + 调用点，`ensure_engines()` 统一注入 |
| 84.4 | 修复硬编码 `font-size:10px` / `font-size:6px` | ✅ | `_tokens.py` 3 处 + `chat.py` 1 处 + `observability.py` 1 处 → `var(--gm-text-xs)` | 5 处硬编码全部 token 化，L2b 检查通过 |

**验证**：`make check` 573 passed + `make check-docs` L2b 通过

### ✅ Batch 85 — CSS 令牌体系清理（已完成）

| # | 任务 | 说明 |
|---|------|------|
| 85.1 | 删除 3 个孤儿 CSS 类 | `gm-pillar-badge` / `gm-adr-badge` / `gm-strategy-persona__subtitle`（`gm-glossary-tooltip` 经确认在 chat.py 中使用，保留） |
| 85.2 | 删除 4 个未引用 @keyframes | `gmShimmer` / `gmGlowPulse` / `gmSpin` / `gmBounce` |
| 85.3 | 补充 5 个缺失 CSS 定义 | `.gm-health-cards` / `.gm-health-card` / `.gm-log-container` / `.gm-log-row`（HTML 中使用但 CSS 无定义） + `--gm-text-base` 令牌定义 |
| 85.4 | px font-size → token 迁移 | `_tokens.py` 3 处 (`16px`→`--gm-text-base`, `11px`×2→`--gm-text-xs`) + `shared.py` 1 处 (`11px`→`--gm-text-xs`) |

**验证**：`make check` 573 passed · lint zero · mypy zero · `make check-docs` L2/L2b/L2c/L2d/L3/L4 全绿

### Batch 86 — 测试补齐：页面组装层 ✅

| # | 任务 | 说明 |
|---|------|------|
| 86.1 | `tests/test_app.py` — app.py 页面组装逻辑 | ✅ 15 tests: 5 tag-pill + 2 welcome-card + 8 handle_chat_input (实验/标准/错误/无planner/planner异常/召回/截断/episode追踪) |
| 86.2 | `tests/test_lab.py` — lab.py 组装逻辑 | ⏭️ 跳过 — lab.py 模块级执行架构（import 时运行 ensure_engines+tab渲染）无法单元测试，需重构后方可 |
| 86.3 | `tests/test_profile_page.py` — profile.py 组装逻辑 | ⏭️ 跳过 — 与 lab.py 同样模块级执行问题，无入口函数，全部逻辑在 module body |
| 86.4 | `tests/test_panel.py` — visualize/panel.py CLI 渲染 | ✅ 15 tests: 7 strength_bar + 3 recall + 1 new_memory + 1 response + 3 decay（原 0 覆盖 → 全函数覆盖） |

**验证**：`make check` 603 passed (+30) · lint zero · mypy zero · `make check-docs` L2/L2b/L2c/L2d/L3/L4 全绿

### Batch 87 — 测试补齐：集成测试 + 薄弱模块 ✅

| # | 任务 | 说明 |
|---|------|------|
| 87.1 | 集成测试扩展 — memory 全链路 | ✅ `test_integration.py` 1→5 tests: 多轮遗忘衰减、索引持久化、recall top_k 约束、overflow 模拟 |
| 87.2 | 集成测试 — 上下文溢出管线 | ✅ 并入 87.1 — `test_overflow_simulation_with_real_data` 用真实召回数据测试两种策略 |
| 87.3 | CLI 测试补齐 — 全部现有命令 | ✅ `test_cli_commands.py` 3→12 tests: /edit成功、/list空库、/list长内容、/edit不存在、/delete空格容错、exit空格、空输入跳过、未知命令、chat管线触发 |
| 87.4 | `test_embed.py` 扩展 | ✅ 2→9 tests: 空字符串、单单词、emoji特殊字符、纯数字、长文本(2000+)、单元素batch、空列表batch |

**验证**：`make check` 623 passed (+20) · lint zero · mypy zero · integration ≥5 ✓ · CLI ≥12 ✓

### Batch 88 — 组件层级治理 ✅ (2026-06-20)

| # | 任务 | 说明 |
|---|------|------|
| 88.1 ✅ | 填充 5 个空 `__init__.py` | `src/memory/` / `chat/` / `web/` / `visualize/` / `web/pages/` 添加公共 API 重导出 |
| 88.2 ✅ | `_handle_chat_input` 管线方法提取 | 1,089 行 → `_run_experiment_mode`(38L) / `_run_recall_phase`(598L) / `_run_storage_phase`(112L) / `_run_generation_phase`(416L) + 模块级 `_record_pipeline_step` 替代闭包 |
| 88.3 ✅ | `render_app_header` 拆分 | chrome.py 701 行 → nav / glossary_modal / about_modal / tour / help_drawer |
| 88.4 ✅ | `chat.py` 溢出渲染提取 | 上下文/分区/溢出渲染（~200 行）→ `_context.py` 独立模块 |

**验证**：`make check` 全绿（lint/type/623 tests）+ 文件行数分布改善（`_handle_chat_input` 1,089→`_handle_chat_input` 10 行 orchestrator）

### ✅ Batch 89 — UI 体验打磨（已完成）

| # | 任务 | 状态 | 说明 | 证据 |
|---|------|------|------|------|
| 89.1 | 暗色 Streamlit chrome 主题 | ✅ | `.streamlit/config.toml` base→dark，indigo-400 品牌色，深色背景 | `git diff HEAD -- .streamlit/config.toml` |
| 89.2 | inline `onmouseover`/`onmouseout` → CSS `:hover` | ✅ | `_tokens.py` 加 `.gm-journey-card:hover`，`chat.py` 删 4 行 inline JS | hover 效果等价验证通过 |
| 89.3 | 添加 `st.cache_data` (TTL=30s) | ✅ | lab.py 2 缓存函数 + profile.py 3 缓存函数，覆盖 `get_all_episodes`/`get_all_facts`/`get_traces_by_step` | `make check` 623 passed |
| 89.4 | XSS 审计 — 用户输入 html.escape 补漏 | ✅ | `app.py` sidebar `current_profile` + `shared.py` `_render_section_header` title/subtitle → `html.escape()` | 手动审查确认 |
| 89.5 | lab.py 溢出沙箱加 try/except error boundary | ✅ | 溢出沙箱整段 `try/except Exception`，异常时 `st.error` 用户友好提示 | 正常路径不受影响，异常路径有兜底 |

**验证**：`make check` 623 passed · lint zero · mypy zero · `make check-docs` 全绿

---

## Phase 22 完成总结

**目标**：技术债治理 + 体验优化，不扩展新功能域。三线扫描 59 条 → 入 Phase 22 共 28 条，全部闭环。

| 指标 | 起点 | 终点 | 变化 |
|------|:---:|:---:|:---:|
| 测试 | 573 | 623 | +50 (8.7%) |
| CSS 孤儿类 | 7 | 0 | ✅ 消灭 |
| 死 @keyframes | 4 | 0 | ✅ 消灭 |
| 硬编码 font-size px | 5 | 0 | ✅ 消灭 |
| CSS 变量未定义 | 3 | 0 | ✅ 消灭 |
| 双重 CSS 注入 | 1 | 0 | ✅ 消灭 |
| `__init__.py` 空壳 | 5 | 0 | ✅ 消灭 |
| XSS 漏洞 | 3 | 0 | ✅ 消灭 |
| 无错误边界 | 1 | 0 | ✅ 消灭 |

**六批递进链**：84(P0修复)→85(CSS清理)→86(测试30)→87(测试20)→88(组件治理)→89(UI打磨)

---

## Phase 23 — 技术债治理 + 工程规则落地 ✅ (2026-06-21)

> Phase 22 技术债候选 5 条全部治理完成，每条催生一条工程规则。

| 批次 | 核心改动 | 状态 |
|------|---------|------|
| 90A | L2c BEM 递归剥离（while 循环替代单级剥离） | ✅ |
| 91 | `_tokens.py` 数据常量分离（`_data.py` 124 行 + `_icons.py` 64 行） | ✅ |
| 92 | `chat.py` 渲染域拆分（3 新模块 + re-export shims） | ✅ |
| 93 | 页面入口点契约（`lab.py` / `profile.py` → `render_xxx_page()`） | ✅ |
| 94 | Sidebar 独立模块（`sidebar.py` 305 行 + `app.py` 死 import 清理） | ✅ |

**工程规则**：5 条规则落地 CLAUDE.md（规则 7-11）+ methodology.md 同步。

---

### Batch 89A — 暗色模式走查修复 + 流程门禁补丁 (2026-06-21)

**目标**：修复 Batch 89 暗色模式 P0 缺陷（页面白闪、导航丢主题、sidebar 缺暗色覆写、对比度不足）+ 流程防反弹补丁。

**Task 列表**：
- [x] `_tokens.py` — body bg `!important` + `--gm-text-muted` WCAG AA + tab 暗色底衬 + sidebar 暗色背景
- [x] `shared.py` — `_inject_theme_init_script` 两阶段（body 直设 → data-theme）+ `get_theme_colors()` text_muted 同步
- [x] `CLAUDE.md` — 协作纪律 14（浏览器运行时验证门禁）、15（替换前模式溯源）
- [x] `methodology.md` — §4 新增 L4b（浏览器验证门禁）、L2f（替换前模式溯源）
- [x] 文档闭环 — requirements-log / roadmap / pitfalls / lessons-learned

**踩坑** `st.markdown` 的 innerHTML 不执行 `<script>` — 三轮回旋才定位，驱动了 L4b 门禁规则。

---

## Phase 24 — 技术债治理续 (✅ 完成)

> Phase 23 L5 拉通自检 (Batches 91-94) 发现的遗留项。两批全部完成。

| 批次 | 核心改动 | 状态 |
|------|---------|------|
| 95 | `_tokens.py` CSS 字符串拆分（11 常量 / 2142 行 → 按主题拆 4-5 文件：品牌色/排版间距/暗色模式/动画/组件覆写） | ✅ |
| 96 | `requirements-log.md` Phase 22 归档至 `docs/archive/`（保留最近 3 Phase：22/23/24） | ✅ |

**备注**：`_tokens.py` 零函数零类（纯 CSS 字符串数据），2142 行超过 1500 行上限（Rule 7）。拆分后 `_tokens.py` 保留 `__init__.py` 风格的重导出枢纽角色。

---

## Phase 25 — 狗粮体验闭环 (2026-06-21)

> 战略定位：2→1→3 优先级。先让真实用户触点暴露问题，再用痛点指向四支柱攻坚方向。

**进入条件**：Phase 24 完成，全部 roadmap 清零。

**审计来源**：Playwright 结构化审计（4 页 × 双模式），发现 P0 主题默认值矛盾 + P1 空状态体验 + P2 工具链盲区。

### 执行批次

| 批次 | 核心改动 | 预计测试 | 状态 |
|------|---------|---------|------|
| 97 | P0: JS pre-theme fallback `'dark'`→`'light'` + check_theme.py 补默认状态断言 | ~2 | ✅ |
| 98 | P1: 聊天页空状态体验升级（欢迎卡片增强 + 引导路径优化） | ~3 | ✅ |

---

## Phase 26 — 用户透明化体验升级 (2026-06-21 启动)

> 战略定位：从"开发者能看懂"转为"好奇的普通用户能探索"。每个 LLM 交互点全量可解剖，专业术语有分层解释，操作有即时反馈。

**设计原则**：
- **增量交付** — 每 Batch 独立可验、独立上线，不攒大版本
- **数据先行** — 先打通断层（数据已在内存但未到 UI），再建消费端
- **解释三层** — L1 hover tooltip / L2 类比卡片 / L3 深度抽屉，统一注册表驱动
- **用户可以不知道，但不能查不到** — 默认简洁，愿探究者能找到每个 LLM 调用的完整请求/响应/逻辑

**需求来源**：2026-06-21 头脑风暴 — 用户视角全站走查，发现 19 个改进方向（4 修断层 / 9 建体系 / 6 加惊喜）。完整需求登记见 `docs/requirements-log.md`。

### 执行批次与拉通测试点位

| 批次 | 核心改动 | 文件 | 拉通测试点位 | 状态 |
|------|---------|------|-------------|------|
| 99 | **解释引擎骨架** — LLMCallArchive dataclass + 术语模型扩展 + ExplainTooltip + ExplainPopover + CSS | ~4 | L2b CSS令牌 / L2c 孤儿类 / L3 Archive字段↔调用点 / L4b 亮暗双模式 tooltip可见 | ✅ |
| 100 | **意图分类透明化** — 数据断层修复 + ProcessDrawer 首个端到端验证 | ~3 | L4 session_state key / L4b pill点击→drawer弹出 / 亮暗双模式 drawer 可读 | ✅ |
| 101 | **项目地图去内化** — 移除ADR+Phase编号+内部术语，概念速查接入 ExplainTooltip/Popover | ~2 | L1 地图内容无内部术语 / L2 概念速查 tooltip 弹出 / L4b 地图全屏亮暗 | ✅ |
| 102 | **对话生成+压缩透明化** — 两调用点 trace 持久化 + ProcessDrawer 消费 | ~2 | L3 Archive字段完整 / L4 session_state key / L4b drawer 展示请求详情 | ✅ |
| 103 | **事实抽取UI升级+旅程叙事翻译** — trace step→自然语言 + 聊天引导探索链接 | ~3 | L2b/L2c CSS / L4b 叙事文本可读 / 引导链接可点击 | ✅ |
| 104 | **首次使用引导+错误教学化** | ~2 | L4 session_state 引导状态 / L4b 引导按钮→发送→面板展开 | ✅ |
| 105 | **侧边栏参数推演+会话收获摘要** | ~2 | L3 推演数据来源正确 / L4b 推演文本在 sidebar 可见 | ✅ |
| 106 | **选择性遗忘+冲突故事化** | ~3 | L3 删除覆盖 episode+fact+FAISS / L4b 遗忘按钮 hover→确认 | ✅ |
| 107 | **记忆搜索+流程图**（Mermaid：旅程+召回+意图分类） | ~9 | L4b 搜索输入→结果 / Mermaid 渲染在亮暗模式均可读 | ✅ |
| 108 | **知识图谱+记忆里程碑** | ~6 | L4b 图谱渲染 / 时间线数据正确 | ✅ |
| 109 | **审计修复** — 行数治理 + 残留引用清理 + 令牌反向依赖纠正 | 4 | make check 734 + check-docs 零警告 | ✅ |

> 拉通测试点位定义：每 Batch 完成后必须验证的跨层/跨组件连接点。L2b/L2c/L3/L4/L4b 含义见 `docs/methodology.md` §4。

### 横切关注点

| 关注点 | 处理方式 |
|--------|---------|
| 解释引擎 | 统一注册表 `_GLOSSARY_DATA` 扩展，四个 UI 原语全站复用 |
| LLMCallArchive | 一个 dataclass，四调用点共用，session_state 单 key 存储 |
| 向后兼容 | 所有现有测试保留，新组件新增测试，不删旧渲染路径 |
| 主题双模式 | 新增 UI 组件必须通过 `make check-theme`，亮/暗双模式 CSS 变量覆盖 |

### 不改什么

- 四支柱叙事体系保留（记忆/上下文/Token/规划），透明化是增强层
- L0-L10 认知层级编号保留（内部架构），但用户界面不再暴露
- 现有页面结构不变（聊天/画像/实验室/可观测性）
- 侧边栏参数面板保留，增加解释层覆盖而非替换


---

## Phase 27 — UI 架构治理与门禁升级 ✅ (2026-06-22)

> 战略定位：Phase 26 全部 10 批闭环后，主题双模统一、Emotion 残留消除、流程门禁自动化。不扩展功能域，专注 UI 稳定性。
> 最后更新: 2026-06-22

| Batch | 目标 | 核心改动 | 验证 |
|-------|------|---------|------|
| 110 | CSS 令牌迁移 + 回归修复 | `_tokens_*` 5 子模块正向依赖梳理，修复 `_core.py` 残留引用 | `make check` 734 passed |
| 111 | UI 基础治理 | 10 项问题 / 4 批次：config.toml base=dark + 防白闪 + Header/Sidebar 主题同步 + CSS 盲区覆盖 + 间距/截断/按钮态 | `make check-theme` 三态全绿 |
| 112 | Emotion 隐式间距修复 | Playwright `getBoundingClientRect` 定位 Streamlit 运行时注入的 `row-gap:16px` × 8 + `padding-bottom:56px` | 顶部 gap 131→3px, 底部 57→17px |
| 113 | check-safety 预提交门禁 | 文件行数上限拦截 + CSS 令牌变更 UI 验证提醒 + pre-commit hook | `make check-safety` 自动拦截 |
| 114-117 | config.toml 基座翻转 | 亮色基座 → Streamlit 原生组件亮色自动正确，暗色靠 67 条 `[data-theme="dark"]` 规则覆盖；Emotion 白色残留消除（stChatInput/stBottom/stNumberInput） | `make check-theme` 四页 × 双模式全绿 |
| 118 | L4b 全元素深扫描升级 | `check_theme.py` 287→460 行，从 3-container 浅层采样升级为 §1 快速门禁 + §2 四页×双模式全元素深扫描 + §3 CSS 变量完整性 + §4 结构性检查 | 8 页面状态, ~990 元素实例, 零问题 |

**Phase 27 闭环**：6 批全部完成。主题双模统一（亮/暗零残留）、Emotion 对抗模式固化、L4b 深扫描门禁自动化。734 tests 全绿。

---

## Phase 28 — 双轨并行：前端迁移 + 文档产品 ✅

> 战略定位：产品从数据 App 转型为教育产品。技术栈 Streamlit → Next.js App Router + FastAPI + Python 引擎。双轨独立推进、不同速度。
> 最后更新: 2026-06-23 (M4 完成 — Phase 28 Batch 163/164/165)
>
> **命名约定**：M = Migration Wave（迁移波次）。M1-M4 全部完成。项目只剩 FastAPI + Next.js + Python 引擎三条腿。

### 轨 A — 文档产品（93 问答案）

| 批次 | 内容 | 预估工作量 |
|------|------|-----------|
| A.1 | ✅ 内容管线搭建 — AI Writer prompt 模板 + Reviewer 审核清单 + 人工终审 checklist + Q1.1 端到端试跑 | 1 批 |
| A.2 | ✅ P0 首批答案 — Q3.1 意图识别 + Q2.1 事实抽取 + Q4.1 Token 估算 + Q7.6 错误教学化，L0-L3 四层，跨 4 章节 | 1 批 |
| A.3+ | P0 剩余 → P1 → P2 → P3 逐批交付 | 持续 | ⏸️ 暂停 — 等 M4 去 Streamlit 后，在 Next.js 文档页从用户视角反推内容策略再启动

### 轨 B — 代码迁移（Streamlit → Next.js）

| 里程碑 | 内容 | 预估批次 |
|--------|------|---------|
| M1 | ✅ FastAPI 中间层 — 完成（3 批，8 路由器，20+ 模型，69 tests） | 3 |
| 122 | ✅ M1 Part 1 — 基础设施 + 4 核心端点 + 23 tests | 1 批 |
| 123 | ✅ M1 Part 2 — CORS + Profile + Metrics + 错误加固 + 22 tests | 1 批 |
| 124 | ✅ M1 Part 3 — Traces + Context + Planner + Decay + 错误恢复 + 24 tests | 1 批 |
| M2 | ✅ Next.js 聊天页 + 文档页 — 洋葱交互 + 93 问 L0-L3 页面，产品门面 | 5 |
| 125 | ✅ M2 Part 1 — 项目初始化 + 设计令牌迁移 + 聊天页 MVP + 15 前端 tests | 1 批 |
| 126 | ✅ 基础设施 — 协作纪律 17 规范性注释 + 全项目中文化 + `make check-comments` 机械门禁 | 1 批 |
| 127 | ✅ M2 Part 2 — Python schema 类型收紧 + remixicon React 组件切换 | 1 批 |
| 128 | ✅ M2 Part 3 — 洋葱交互：OnionPanel 四层披露 + ContextBar 分区条 + 召回展开 + 展开动画 | 1 批 |
| 129 | ✅ M2 Part 4 — 文档页 `/learn`：QuestionList 章标签页 + AnswerCard L0-L3 渐进披露 + 93 问数据层 + 28 前端 tests + Header 导航激活 | 1 批 |
| **测试体系加固** | **测试债务清零 + 集成/E2E 补全** | **4+2** |
| 130 | ✅ P0 — test_web.py 巨石拆分（5001→7 域文件） + useChat hook 测试（+10） | 1 批 |
| 131 | ✅ P2 — OnionPanel 交互测试（+27） + fact.py 纯函数测试（+32） | 1 批 |
| 132 | ✅ P3 — CLI 命令测试（+20） + 93 问答完整性校验（+15） | 1 批 |
| 133-137 | ✅ 测试体系二次加固 — webs 组件零独立测试 5 Batch 补齐：trace_engine（+33）+ context（+30）+ ContextBar/ThemeToggle/LearnPage 前端（+18）+ bootstrap 扩展（+11）。合计 +92 tests（929 Python + 118 Frontend = 1047） | 5 批 |
| 138 | ✅ 集成测试加厚 — 5 → 12（+7）：冲突检测 + 事实抽取 + 压缩 + 记忆增强 + 多轮 + 错误恢复 + 策略对比。Python 936 tests | 1 批 |
| 139 | ✅ E2E 快乐路径 — Playwright 框架 + 6 场景（发送/存储/非空/主题/暗色/健康）。Python 942 tests。StepFun vs DeepSeek 模型对比信号收集 | 1 批 |
| **M2 终态** | **聊天 MVP + 洋葱交互 + 文档页 + 测试体系 1047 tests** | **全部 ✅** |
| **M2.5 Stage 1 — 打磨** | **✅ 门面精修 — 5 个微批，全部完成** | **5 微批** |
| 140 | ✅ Header 死链接清理 — 删"观察""画像"死文字 span，"Lab"→"文档"导航对齐（仅 `Header.tsx`，-4 行净删） | 1 批 |
| 141 | ✅ Sidebar 基础填充 — 项目身份卡片（logo + v0.1.0）+ 当前 profile 标签卡 + 关于可展开段（仅 `Sidebar.tsx`，+50 行） | 1 批 |
| 142 | ✅ 聊天空状态 → 欢迎卡片 — `ChatPanel.tsx` 空态区域替换为渐变 Hero + 3 功能特色卡片（透明化记忆/上下文可视化/意图识别）+ 快速开始引导步骤（3 步编号圆卡片）；学习页面引导链接 | 1 批 |
| 143 | ✅ 微交互动画 — `globals.css` 3 组 @keyframes（gm-slide-in/gm-fade-in）+ gm-card-lift 工具类；`ChatPanel.tsx` Hero 1.5s 淡入 + 卡片 600ms 交错 150ms 滑入 + `ChatMessage.tsx` 消息滑入 + `Sidebar.tsx` 卡片 hover 升高；踩坑：Turbopack CSS 缓存未刷新需 rm -rf .next；fill-mode: backwards 不够需基础样式 opacity:0 + forwards；1.5s 时长才有明显感知 | 1 批 |
| 144 | ✅ Learn 页视觉精修 — AnswerCard 组件（L0 玻璃态/L1 正文分层/L2-L3 折叠着色/徽章适配）+ 左侧目录（标签指示条/选中态强化/描述卡独立背景）+ 页面布局（内容区背景分离/Welcome 玻璃态）| 2 微批 |
| **M2.5 Stage 1** | **✅ 门面精修 — 5 个微批，全部完成** | **5 微批** |
| **M2.5 Stage 2 — Learn 页阅读平台升级** | **仿微信读书交互 — 侧栏重构 + 阅读导航 + 沉浸模式** | **3 批** |
| 145 | ✅ Learn 侧栏重构 — ① 搜索框（替换章节标签页，支持 / 快捷键聚焦+清除按钮）② 全章节树形目录（每章可折叠/展开+标题+数量+图标+折叠箭头）③ 搜索实时过滤（自动展开匹配章节，清空恢复全树）④ 目录面板收起/展开（250ms 动画+内容区顶栏切换按钮+当前章面包屑）| 1 批 |
| 146 | ✅ 阅读导航 — ⑤ 顶部/底部上一节/下一节按钮（首尾边界：第一节"上一节"禁用/最后一节变"回到顶部"）+ 进度指示 + Learn 页补充 Header 导航（修复无法回到首页的问题）| 1 批 |
| 147 | ✅ 沉浸阅读模式 — ⑦ 全屏沉浸式阅读（隐藏 Header/Sidebar 纯内容视图）⑧ 微信读书风格排版精调（更大行高、优化字体、舒适阅读宽度、阅读进度百分比）| 1 批 |
| **M2.5 Stage 3 — 补聊天页组件** | **原 Stage 2 计划后移 — 3 批移植 Streamlit 已有实现** | **3 批** |
| 148 | ✅ 召回叙事面板 + Intent pill | 1 批 |
| 149 | ✅ 消息旅程六镜头卡片 — JourneyCards 6卡网格 + API 2字段补齐 | 1 批 |
| 150 | ✅ ProcessDrawer 深度抽屉 — slide-in 抽屉 + 4段调用档案（0 API改动） | 1 批 |
| 153 | ✅ ProcessDrawer 全局右侧抽屉改造 — DrawerContext 单例 + 固定定位 + z-index 可靠 + 点击外部关闭 | 1 批 |
| 154 | ✅ ProcessDrawer 折叠块 + 源码展示 + 动画减速 + 入场修复 | 1 批 |
| **M2.5 收尾修复** | **上线前打补丁 -- 流程修复 + 缺陷修复** | **2 批** |
| 151 | ✅ 日报制度修复 -- 路径定义 + check-docs 门禁 + 全量历史反推补写 | 1 批 |
| 152 | ✅ 前端缺陷修复 -- ThemeToggle hydration 匹配 + devIndicators 关闭 N 图标 + ChatInput 多行 | 1 批 |
| M3 | Next.js Lab + Observability — 数据仪表盘组件化 | 4-6 |
| 155 | ✅ API 契约层 — TypeScript 类型 13 个 + API client 函数 11 个 + /logs 端点 + 14 前端 tests | 1 批 |
| 156 | ✅ Observability 页面外壳 + 健康仪表盘 — ObserveShell 4-Tab 导航 + HealthDashboard 5 卡片 + HealthCard 组件 + Header "可观测" 链接 + 15 测试 | 1 批 |
| 157 | ✅ 日志查看器 Tab — LogViewer 组件（文件元信息 + 级别过滤 + 关键字搜索 + 分页 + 折叠长消息）+ 10 tests | 1 批 |
| — | ✅ L5 拉通 (Phase 28 Batch 155-157) — ESLint 修复 + 文档闭环 | 1 批 |
| **M3.5** | **迁移遗漏补齐 — 聊天页产品核心恢复 + Sidebar 参数面板** | **5** |
| 158 | ✅ 品牌恢复 — Header 副标题 + 好奇心引导按钮 + 滚动收折效果 + 系统状态卡片 | 1 批 |
| 159 | ✅ 四支柱全景面板 — Memory/Context/Token/Planning 4 卡片实时指标 | 1 批 |
| 160 | ✅ Sidebar 认知参数 (上) — 会话统计 + L2 记忆召回 + L3 上下文窗口 + ChatParamsContext | 1 批 |
| 161 | ✅ Sidebar 认知参数 (下) — L5 模型推理 + L6 遗忘曲线 + Profile 动态卡片 | 1 批 |
| 162 | ✅ Sidebar 收尾 — 会话收获摘要 + 记忆召回摘要 + 一键重置 + 参数推演 | 1 批 |
| **M4** | **去 Streamlit — 删除 `src/web/`，清理依赖，项目结构归位** | **3** |
| 163 | ✅ 切除 — 删除 src/web/ + 测试 + .streamlit/ + check_theme.py，去掉 streamlit 依赖，重生成 lock | 1 批 |
| 164 | ✅ 接通 — 修复 src/embed.py + src/context/partition.py 去 @st.cache_data，更新 check_safety/check_contracts/Makefile（-4 target, -6 检查段），重生成 contract-snapshot | 1 批 |
| 165 | ✅ 闭环 — 文档更新（CLAUDE.md + 6 docs）+ L5 拉通自检 | 1 批 |
| **M4 终态** | **Streamlit 体系完全切除。564 Python + 320 Frontend tests 全绿。项目 = FastAPI + Next.js + Python 引擎。** | **全部 ✅** |

> **M3.5 范围决策 (2026-06-23)**：M3 原计划 4-6 批仅覆盖 Observability。2026-06-23 全量审计发现 39 项遗漏，
> 其中 🔴 P0（品牌标识/产品核心价值）4 项 + 🟡 P1（Sidebar 参数面板/Profile 卡片）6 项 + 🟡 P2 29 项。
> 决策：M3.5 用 5 批补齐聊天页产品核心 + Sidebar 认知参数面板。Lab 页 11 面板、Profile 页、解释引擎、
> 上下文工程 6 组件、Mermaid 流程图等 P2 项 → 延后至 Phase 29（四支柱研究纵深）在 Next.js 原生体系重建，
> 届时比 Streamlit 版做得更好而非简单搬移。H4 项目地图 Drawer → 暂不搬，Next.js 有更好的实现路径。

<details>
<summary>📋 遗漏审计完整登记（39 项，供后续 Phase 参考）</summary>

#### Header 域（4 项）

| # | 遗漏项 | 源文件 | 去向 |
|---|--------|--------|------|
| H1 | Header 副标题行 | `chrome.py` L104-106 | → Phase 28 Batch 158 |
| H2 | 仿知乎滚动收折 | `chrome.py` L446-457 | → Phase 28 Batch 158 |
| H3 | 健康状态指示灯 | `chrome.py` L25-35 | → Phase 29 (合并到可观测性页) |
| H4 | 项目地图 Drawer | `chrome.py` 4 函数 ~250行 | → Phase 29 (Next.js 原生重建) |

#### Sidebar 域（11 项）

| # | 遗漏项 | 源文件 | 去向 |
|---|--------|--------|------|
| S1 | Profile 动态卡片 | `sidebar.py` L41-85 | → Phase 28 Batch 161 |
| S2 | L2 记忆召回参数 | `sidebar.py` L100-134 | → Phase 28 Batch 160 |
| S3 | L3 上下文窗口参数 | `sidebar.py` L137-158 | → Phase 28 Batch 160 |
| S4 | L5 模型推理参数 | `sidebar.py` L161-188 | → Phase 28 Batch 161 |
| S5 | L6 遗忘曲线面板 | `sidebar.py` L191-229 | → Phase 28 Batch 161 |
| S6 | 会话统计卡片 | `shared.py:render_session_stats` | → Phase 28 Batch 160 |
| S7 | 系统状态卡片 | `sidebar.py` L232-251 | → Phase 28 Batch 158 |
| S8 | 会话收获摘要 | `sidebar.py:_render_session_harvest` | ✅ Phase 28 Batch 162 |
| S9 | 参数推演面板 | `sidebar.py:_render_parameter_replay` | ✅ Phase 28 Batch 162 |
| S10 | 一键重置流程 | `sidebar.py` L259-298 | ✅ Phase 28 Batch 162 |
| S11 | 记忆召回摘要 | `shared.py:render_session_memory_summary` | ✅ Phase 28 Batch 162 (合并到 S8) |

#### 聊天页域（3 项）

| # | 遗漏项 | 源文件 | 去向 |
|---|--------|--------|------|
| C1 | 四支柱全景面板 | `chat.py:render_four_pillar_panorama` | → Phase 28 Batch 159 |
| C2 | 旅程历史浏览器 | `chat.py:render_journey_history` | → Phase 29 |
| C3 | 好奇心引导按钮 | `_welcome.py` L102-120 | → Phase 28 Batch 158 |

#### 推理面板域（2 项）

| # | 遗漏项 | 源文件 | 去向 |
|---|--------|--------|------|
| I1 | 系统提示词面板 (L4) | `_inference_panels.py` | → Phase 29 (OnionPanel 已部分覆盖) |
| I2 | 模型推理面板 (L5) | `_inference_panels.py` | → Phase 29 (Sidebar L5 参数面板已覆盖核心需求) |

#### 上下文工程域（6 项）

| # | 遗漏项 | 源文件 | 去向 |
|---|--------|--------|------|
| X1 | 上下文分区条 | `_context.py:render_context_partition_bar` | → Phase 29 (ContextBar 已部分覆盖) |
| X2 | 上下文窗口面板 (L3) | `_context.py:render_context_window` | → Phase 29 |
| X3 | 策略人格卡片 | `_context.py:render_strategy_persona` | → Phase 29 |
| X4 | FDA 营养标签 | `_context.py:render_nutrition_label` | → Phase 29 |
| X5 | Ghost Prompt 视图 | `_context.py:render_raw_prompt_view` | → Phase 29 |
| X6 | 上下文健康徽章 | `_context.py:render_context_health_badge` | → Phase 29 |

#### 解释引擎（1 体系）

| # | 遗漏项 | 源文件 | 去向 |
|---|--------|--------|------|
| E1 | ExplainTooltip + Popover | `_explain.py` + `_data.py` | → Phase 29 (Next.js 原生 tooltip 更优雅) |

#### 完整页面域（2 页）

| # | 遗漏项 | 源文件 | 去向 |
|---|--------|--------|------|
| P1 | Profile 页 | `pages/profile.py` + `profile.py` | → Phase 29 |
| P2 | Lab 页 11 面板 | `pages/lab.py` | → Phase 29 |

#### 分析/可视化域（7 项，Lab 页子组件）

| # | 遗漏项 | 源文件 | 去向 |
|---|--------|--------|------|
| A1 | A/B 实验对比 | `analytics.py` | → Phase 29 |
| A2 | 成本瀑布图 | `analytics.py` | → Phase 29 |
| A3 | 数据主权面板 | `analytics.py` | → Phase 29 |
| A4 | 衰减直方图 | `memory_viz.py` | → Phase 29 |
| A5 | 艾宾浩斯时间轴 | `memory_viz.py` | → Phase 29 |
| A6 | 知识图谱 | `_kg_viz.py` | → Phase 29 |
| A7 | Mermaid 流程图 ×3 | `_flowchart.py` | → Phase 29 |

</details>

### M3.5 批次详情

**设计原则**：
- 每批 2-4 项，独立可验，零跨批依赖（同域内允许依赖）
- 先静态后动态 — Phase 28 Batch 158 零 API 改动先上线，后续批次逐层加数据
- Sidebar 参数面板共用一套 API config 端点，160/161 同域拆分仅为粒度控制
- 所有新增 UI 组件通过 `make check-theme` 亮/暗双模式验证

#### ✅ Phase 28 Batch 158 — 品牌恢复 + 欢迎体验 (已完成)

| # | 任务 | 涉及文件 | 结果 |
|---|------|---------|------|
| 158.1 | Header 副标题行 | `Header.tsx` | +3 行，新增 `gm-header__subtitle` 段落 |
| 158.2 | 好奇心引导按钮 (聊聊/看旅程/解释Token) | `ChatPanel.tsx` (WelcomeView) | +45 行，CURIOSITY_BUTTONS 常量 + onSend prop 传递 |
| 158.3 | 系统状态卡片 (API Key pulse dot + 版本号) | `Sidebar.tsx` | +15 行，mt-auto 底部固定 + 绿色脉冲指示灯 |
| 158.4 | 滚动收折效果 (CSS + JS) | `Header.tsx` + `globals.css` | +25 行 JS (useEffect scroll listener) + 30 行 CSS (.gm-header/.gm-header--compact/.gm-header__subtitle transition) |

**验证**：`make check` 950 Python + 246 frontend 全绿 · ESLint 零新增 · `make check-docs` 全绿

**拉通点位**：L4b 亮暗双模式 header 可见 / 好奇心按钮点击发送消息 / Sidebar 状态 dot 颜色正确

#### Phase 28 Batch 159 — 四支柱全景面板 ✅

| # | 任务 | 涉及文件 | 状态 |
|---|------|---------|------|
| 159.1 | FourPillar 组件 (4 卡片：记忆/上下文/Token/规划) | `FourPillar.tsx` (新建) | ✅ |
| 159.2 | 接入 ChatPanel — 在聊天区顶部常驻显示 | `ChatPanel.tsx` | ✅ |
| 159.3 | API 类型扩展 — ChatResponse 无需改，已有全部字段 | `api/types.ts` | ✅ (无需变更) |
| 159.4 | 空状态安全 — 无数据/无意图时显示占位符 | `FourPillar.tsx` | ✅ (内置) |

**拉通点位**：发消息后四卡片数值更新 / 空状态→有数据过渡 / 16 新 test + 262 total 零回归

#### Phase 28 Batch 160 — Sidebar 认知参数 (上) ✅

| # | 任务 | 涉及文件 | 状态 |
|---|------|---------|------|
| 160.1 | 会话统计卡片 (消息数/记忆数/时长) | `Sidebar.tsx` | ✅ |
| 160.2 | L2 记忆召回参数 (top_k/recall_threshold/truncation_threshold/compress_threshold) | `ParamSliders.tsx` (新建) | ✅ |
| 160.3 | L3 上下文窗口参数 (window_size/overflow_strategy) | `ParamSliders.tsx` | ✅ |
| 160.4 | API config 端点 — 跳过，参数内联传递无需独立端点 | — | ⏭️ 跳过 |

**拉通点位**：Slider 拖拽 → ChatParamsContext → useChat → api.chat() / L3 即时生效，L2 滑块 UI-only / 287 tests 零回归

#### Phase 28 Batch 161 — Sidebar 认知参数 (下) ✅

| # | 任务 | 涉及文件 | 状态 |
|---|------|---------|------|
| 161.1 | L5 模型推理参数 (model/temperature/max_tokens) | `ParamSliders.tsx` 扩展 | ✅ |
| 161.2 | L6 遗忘曲线面板 (decay_lambda + SVG 预览) | `ParamSliders.tsx` | ✅ |
| 161.3 | Profile 动态卡片 (头像 + 标签云 pills + 链接) | `Sidebar.tsx` → `ProfileCard.tsx` | ✅ (→ Phase 28 Batch 161b) |

**拉通点位**：遗忘曲线 λ 拖拽 → 预览图实时更新 / Profile 卡片标签云从 API 加载 / L4b 亮暗模式图表可读

#### Phase 28 Batch 161b — Profile 动态卡片 ✅

| # | 任务 | 涉及文件 | 状态 |
|---|------|---------|------|
| 161b.1 | `GET /memory/tag-summary` 端点 | `api/routers/memory.py` | ✅ |
| 161b.2 | `TagSummaryItem` 类型 + `getTagSummary()` 客户端 | `api/types.ts` + `api/client.ts` | ✅ |
| 161b.3 | `ProfileCard` 组件（头像+标签云+链接+三态） | `ProfileCard.tsx` | ✅ |
| 161b.4 | Sidebar 集成 + 测试 | `Sidebar.tsx` + test files | ✅ |

**拉通点位**：Sidebar → ProfileCard mount → `GET /memory/tag-summary` + `GET /profiles` → 标签云渲染 → pills 显示 / 950 backend + 305 frontend 全绿

#### Phase 28 Batch 162 — Sidebar 收尾 ✅

| # | 任务 | 涉及文件 | 实际 |
|---|------|---------|------|
| 162.1 | 会话收获摘要 + 记忆召回摘要 | 新建 `SessionHarvest.tsx` | ~130 行 |
| 162.2 | ~~记忆召回摘要~~ | 合并到 SessionHarvest | — |
| 162.3 | 一键重置流程 | `Sidebar.tsx` + `api/routers/session.py` + `api/schemas.py` | 后端 60 行 + 前端 80 行 |
| 162.4 | 参数推演面板 | 新建 `ParamReplay.tsx` | ~70 行 |

**拉通点位**：发消息后收获摘要数据刷新 / 重置确认 → 二次确认 → API 调用 → 清空 / L3 合约完整
**交付日期**：2026-06-23 · 954 backend + 320 frontend 全绿

### M3 完成后的终态

```
聊天页 ─ ✅ ChatPanel + WelcomeView + 洋葱面板 + 六镜头旅程 + ProcessDrawer
       ─ 🆕 四支柱全景 + 好奇心引导 (Phase 28 Batch 158-159)
Header ─ ✅ Logo + 导航 + 主题切换
       ─ 🆕 副标题 + 滚动收折 (Phase 28 Batch 158)
Sidebar ─ ✅ 认知参数六层 + Profile卡片 + 会话摘要 + ParamReplay + 一键重置 (Phase 28 Batch 160-162)
Observe ─ ✅ HealthDashboard + LogViewer + ObserveShell
Learn   ─ ✅ QuestionList + AnswerCard + 搜索 + 沉浸模式
```

### 迁移期间规则

- 每阶段 git tag + backup 快照，确保可回滚
- 942 tests 保持全绿，Python 引擎 `src/` 零逻辑改动
- Streamlit 与 Next.js 共存，URL 路由分流
- M2 聊天页上线前 Streamlit 版保持可用

---

## Phase 29 — M3.5 P2 遗漏补齐：Next.js 原生体系重建 ✅

> 战略定位：M3.5 审计 39 项遗漏中，10 项 P0/P1 已在 Phase 28 Batch 158-162 补齐。剩余 29 项 P2 在本 Phase 在 Next.js 原生体系重建。
> 最后更新: 2026-06-24 (Phase 29 Batch 180 ✅, Phase 29 全部 15 批完成 🎉)
> 详细计划：[docs/plans/phase-29-m3.5-p2-rebuild.md](docs/plans/phase-29-m3.5-p2-rebuild.md)

**目标**：补齐 Lab 页 (11 面板)、Profile 页、上下文工程面板 (6)、推理面板 (2)、旅程历史、解释引擎、项目地图、Mermaid 流程图 (3)、A/B 实验等 29 项 P2。✅ 全部交付。

**批次总览**：

| Batch | 域 | 内容 |
|-------|-----|------|
| 166 | API | Lab 数据端点 (cache/embedding/decay/knowledge-graph) ✅ |
| 167 | API | Experiment + Context 扩展 (presets/run/strategy-personas/system_prompt) ✅ |
| 168 | Frontend | Lab 页外壳 + 路由 `/lab` + 导航 ✅ |
| 169 | Frontend | Lab 面板 R1: 上下文溢出 + 策略对比 + 意图测试 ✅ |
| 170 | Frontend | Lab 面板 R2: Token 仪表盘 + 管线延迟 + Pipeline 追踪 ✅ |
| 171 | Frontend | Lab 面板 R3: 内存浏览器 + 嵌入空间 + 缓存统计 ✅ |
| 172 | Frontend | Lab 面板 R4: 知识图谱 + 衰减直方图 + Health/Log 复用 ✅ |
| 173 | Frontend | Profile 页 `/profile` ✅ |
| 174 | Frontend | 上下文工程面板 (ContextBar增强 + 窗口 + 营养标签 + Ghost + 策略 + 健康) | ✅ |
| 175 | Frontend | 推理面板 L5 (I2) + 旅程历史浏览器 (C2) — I1 已由 B174 GhostPromptView 覆盖 | ✅ |
| 176 | Docs | 文档债务清偿 — 需求验证补齐 + methodology.md 去 Streamlit 残留 + 日报铁律落地 §5 | ✅ |
| 177 | Frontend | 解释引擎 (ExplainTooltip/Popover) + 项目地图 Drawer | ✅ |
| 178 | Frontend | Mermaid 流程图 ×3（纯前端，mermaid.js） | ✅ |
| 179 | Frontend | A/B 实验面板 + 成本瀑布图（含新 API 端点） | ✅ |
| 180 | Docs | 收尾 + 导航对齐 + L5 拉通 ✅ |

---

## Phase 29 完成总结

**目标**：M3.5 审计发现 39 项遗漏，10 项 P0/P1 在 M3.5 补齐，剩余 29 项 P2 在 Phase 29 用 Next.js 原生体系重建。✅ 全部交付。

| 指标 | 起点 | 终点 | 变化 |
|------|:---:|:---:|:---:|
| 前端测试 | 320 | 594 | +274 (85.6%) |
| 后端测试 | 583 (Phase 29 Batch 166) | 600 | +17 |
| 前端文件数 | ~25 | 52 | +27 测试文件 |
| 页面路由 | 3 (/、/learn、/observability) | 5 (+/lab、/profile) | +2 |
| Lab Tab | 0 | 5 (上下文/管线/数据/图谱/实验) | +5 |
| 上下文工程组件 | 1 (ContextBar 基础) | 7 (+NutritionLabel/StrategyPersona/GhostPrompt/Window/HealthBadge) | +6 |
| 解释引擎 | 0 (无 tooltip 体系) | 2 (ExplainTooltip + ExplainPopover + 15 词条注册表) | +2 |
| Mermaid 流程图 | 0 (CDN 方案) | 3 (npm mermaid + 记忆管线/上下文分区/遗忘曲线) | +3 |
| A/B 实验 | 0 (仅 Python 引擎) | 1 (ExperimentComparePanel + 4 预设) | +1 |
| 成本瀑布 | 0 (仅 Python 引擎) | 1 (CostWaterfallPanel + API 端点) | +1 |
| API 新端点 | — | 7 (Lab 4 + Experiment 1 + Context 1 + Cost 1) | +7 |

**15 批递进链**：
```
166(API Lab)→167(API Exp+Ctx)→168(Lab外壳)→169(上下文Tab)→170(管线Tab)
→171(数据Tab)→172(图谱Tab)→173(Profile页)→174(上下文工程6组件)
→175(推理+旅程)→176(文档清偿)→177(解释+地图)→178(Mermaid×3)
→179(AB实验+瀑布)→180(收尾+L5)
```

**Phase 29 交付的 29 项 P2**（按原审计编号）：
- **Lab 页 11 面板** (L1-L11)：全部交付 ✅
- **分析/可视化 7 项** (A1-A7)：A/B 实验/成本瀑布/数据主权/衰减直方图/艾宾浩斯时间轴/知识图谱/Mermaid 流程图 — 全部交付 ✅
- **上下文工程 6 项** (X1-X6)：分区条增强/窗口面板/策略人格/营养标签/Ghost Prompt/健康徽章 — 全部交付 ✅
- **推理面板 2 项** (I1-I2)：系统提示词(GhostPrompt 覆盖) + 模型推理面板 — 全部交付 ✅
- **聊天页 1 项** (C2)：旅程历史浏览器 — 交付 ✅
- **Header 2 项** (H3-H4)：健康指示灯(合并到 ObserveShell) + 项目地图 Drawer — 全部交付 ✅
- **解释引擎 1 项** (E1)：ExplainTooltip + ExplainPopover — 交付 ✅

**导航终态**：Header 五链接（聊天/文档/可观测/实验室/画像）+ 项目地图按钮 → 5 页面全联通。

---

## Phase 30 — Profile 画像页面 ✅

> 战略定位：Profile 页面交互深化 — 标签溯源 + 事实纠正 + 置信度管理。用户画像页从只读展示升级为可交互的记忆管理中心。
> 最后更新: 2026-06-24 (B4 完成，Phase 30 交付)

### Phase 30 批次记录

| Batch | 日期 | 内容 | 状态 |
|-------|------|------|------|
| B1 | 2026-06-24 | Tag Detail API — JOIN facts+episodes+confidence_log 一键追溯标签来源 | ✅ |
| B2 | 2026-06-24 | Profile 模态窗 — 按钮上移至右侧栏顶部 + 居中弹窗交互 | ✅ |
| B3 | 2026-06-24 | Tag 溯源面板 — 点击标签弹出 TagDetailModal，展示事实/来源对话/置信度变更日志 | ✅ |
| B4 | 2026-06-24 | 事实纠正 + 加星 — TagDetailModal 操作按钮 + POST /facts/{id}/confidence API | ✅ |

**设计原则**：
- **痛点为锚** — 优先解决用户实际使用中碰到的问题
- **可见的改进** — 每批交付用户可感知的变化
- **评估先行** — 每批定义 before/after 对比方式

**交付总结**：Pillar 1.5（用户记忆控制）闭环完成 — 纠正标记 + 加星标注 + 溯源面板。

---

## Phase 31 — L0 架构堵点：组件复用提取 + 报错体系统一 ✅

> 战略定位：Master Backlog L0 层全量清零 — 报错基础设施 → 组件复用提取（Drawer/CollapsibleSection/KVRow/DataState/CopyButton/RefreshButton/TabBar）。
> 最后更新: 2026-06-25 (全 11 批完成 ✅ · 原 Phase 31 L0 段缩为独立 Phase 31)

**入口**：`docs/master-backlog.md` — 104 项全量缺口清单，Phase 31 覆盖 L0 架构堵点层。

### L0 排期总览

| Batch | 标签 | 内容 | 文件 | 状态 |
|:--:|------|------|:--:|:--:|
| **Phase 31 Batch 1** | L0-1 | 报错基础设施 + CSS Token 补齐 | 5 | ✅ |
| Phase 31 Batch 2 | L0-2 | 报错替换 · 核心路径 | 6 | ✅ |
| Phase 31 Batch 3 | L0-3 | 报错替换 · Lab + 观察面 | 14 | ✅ |
| Phase 31 Batch 4 | L0-4 | Drawer 统一 (R1) | 5 | ✅ |
| Phase 31 Batch 5 | L0-5 | CollapsibleSection 统一 (R3) | 10 | ✅ |
| Phase 31 Batch 6 | L0-6 | KVRow 提取 (R2) | 4 | ✅ |
| Phase 31 Batch 7 | L0-7 | DataState 三态统一 (R4) — 11 panel | 18 | ✅ |
| **Phase 31 Batch 8** | L0-8 | DataState 收尾 · 简单组件 (JourneyHistoryBrowser/HealthDashboard/LogViewer) | ~6 | ✅ |
| **Phase 31 Batch 9** | L0-9 | DataState 收尾 · 复杂组件 (MemoryBrowserPanel/ExperimentComparePanel) | ~3 | ✅ |
| **Phase 31 Batch 10** | L0-10 | CopyButton (R5) + RefreshButton (R7) 提取 | ~5 | ✅ |
| **Phase 31 Batch 11** | L0-11 | TabBar 提取 | ~5 | ✅ |

> **Phase 31 Batch 7 复盘**：18 文件一锅端，脚本批量替换导致空态/加载消息不匹配 + 异步测试修复反复修正。根因：违反 Batch 上限 8 文件铁律 + 脚本替换无法精确匹配上下文差异。**新规**：剩余 DataState 迁移分两批（简单/复杂），每文件逐一手动 Edit，改完立刻跑该组件 vitest。

### ✅ Phase 31 Batch 1 — L0-1: 报错基础设施 + CSS Token 补齐

| # | 任务 | 状态 | 验证方式 | 证据 |
|---|------|:--:|------|------|
| 183.1 | `categorizeError` 工具 + `CategorizedError` 类型 | ✅ | vitest 25 tests | 5 分类 (network/server/llm/render/unknown) 全中文 userMessage |
| 183.2 | `ErrorDisplay` 统一报错组件 (card/inline/fullscreen) | ✅ | vitest 15 tests | 3 variant 渲染 + retry + null/raw/categorized 输入 |
| 183.3 | CSS Token 补齐 — CROSS-7 6 未定义 token | ✅ | Playwright `getComputedStyle` 运行时非空 | `gm-slate-500`/`emerald-500`/`amber-500`/`leading-relaxed`/`text-2xs`/`brand-hover` |
| 183.4 | CSS Token 补齐 — CROSS-8 9 语义 token | ✅ | Playwright `getComputedStyle` 运行时非空 | `header-h`/`sidebar-w`/`text-on-brand` + 6 层 z-index |
| 183.5 | 全栈门禁 | ✅ | make check + tsc + eslint | Python 600 ✅ · 前端 598/634 ✅ · 零新增 error |

**新增文件**：`errorCategories.ts` / `ErrorDisplay.tsx` + 2 test 文件。**编辑**：`globals.css`（三处插入 15 token 定义 + 2 theme 映射 + 1 spacing 映射）。

---

### ✅ Phase 31 Batch 2 — L0-2: 报错替换 · 核心路径

| # | 任务 | 状态 | 验证方式 | 证据 |
|---|------|:--:|------|------|
| 184.1 | `useChat.ts` — error 类型 `string\|null` → `Error\|string\|null`，原始错误对象保留给 ErrorDisplay 分类 | ✅ | vitest useChat 3 error tests pass | `expect(result.current.error).toBeInstanceOf(Error)` |
| 184.2 | `app/error.tsx` — Next.js Error Boundary → `<ErrorDisplay variant="fullscreen">` | ✅ | 手动 + tsc 零新增 error | raw error.message 不再直出 |
| 184.3 | `ChatPanel.tsx` — inline error div → `<ErrorDisplay variant="card">` | ✅ | vitest ChatPanel "shows error state on API failure" pass | 中文归类消息 + 重试按钮 |
| 184.4 | `MermaidDiagram.tsx` — `<details>` 源码暴露 → `<ErrorDisplay variant="card">` | ✅ | vitest 2 错误测试 pass | `<details>/<pre>` 零残留，用户不再看到原始 Mermaid 代码 |
| 184.5 | `JourneyHistoryBrowser.tsx` — inline error → `<ErrorDisplay variant="card">` | ✅ | vitest 错误测试 pass | role="alert" 断言 |
| 184.6 | `Sidebar.tsx` — decay/reset error string → `<ErrorDisplay variant="inline">` | ✅ | vitest Sidebar tests pass | 三态分离 (success/loading/error) |

**修改文件**：6 源文件 + 4 测试文件。**测试影响**：+1 pass (598/634)，零新增 failure。

---

### ✅ Phase 31 Batch 4 — L0-4: Drawer 统一 (R1) + Body Scroll Lock 修复

| # | 任务 | 状态 | 验证方式 | 证据 |
|---|------|:--:|------|------|
| 186.1 | `Drawer.tsx` 统一外壳 — 动画状态机 + backdrop + panel shell | ✅ | 3 drawer 零重复动画代码 | 净删 ~180 行 |
| 186.2 | `globals.css` — 8 drawer CSS token (light+dark) | ✅ | Playwright `getComputedStyle` | 遮罩/阴影/动效独立 token |
| 186.3 | 3 Drawer 重构为薄壳 — ProcessDrawer/ProjectMapDrawer/TagDetailDrawer | ✅ | tsc + eslint 零 error | 对外 Props 零变更 |
| 186.4 | CROSS 修复 — backdrop 暗模式 / easing token / 宽度 token / Escape 守卫 / aria-hidden | ✅ | check-theme 5 route 0 error | 6 个 CROSS issue 修复 |
| 186.5 | **Body scroll lock** — 引用计数锁 `<html>`+`<body>` overflow + 滚动条宽度补偿 | ✅ | Playwright `mouse.wheel` → `scrollY=0` | 消除双滚动条根因 |
| 186.6 | MermaidDiagram 嵌套滚动修复 — `overflow-x:auto`→`overflow:hidden` + maxHeight 0 | ✅ | 全页面可滚动元素=1 | 消除 CSS overflow 规范副作用 |

**修改文件**：5 文件（Drawer.tsx / MermaidDiagram.tsx / ProcessDrawer.tsx / ProjectMapDrawer.tsx / TagDetailDrawer.tsx）。**净删 ~180 行重复代码**。

---

### ✅ Phase 31 Batch 5 — L0-5: CollapsibleSection 统一 (R3)

| # | 任务 | 状态 | 验证方式 | 证据 |
|---|------|:--:|------|------|
| 187.1 | `CollapsibleSection.tsx` 统一组件 — 3 变体 (ghost/bordered/card) + 受控/非受控 + 动画 + A11 | ✅ | vitest 25 tests | aria-expanded + aria-hidden + rightAccessory click 隔离 |
| 187.2 | ParamSliders 迁移 — 删除本地 CollapsibleSection，4 处使用共享组件 | ✅ | vitest 27 tests pass | 旧 `<details>` → `<CollapsibleSection>` |
| 187.3 | ParamReplay + Sidebar 迁移 — `<details>` → CollapsibleSection | ✅ | vitest + tsc + eslint | 2 文件零 import 残留 |
| 187.4 | ContextWindowPanel + GhostPromptView 迁移 — useState+button → CollapsibleSection + rightAccessory | ✅ | vitest 33 tests pass | 删除手动 toggle 逻辑 |
| 187.5 | ProcessDrawer Section 迁移 — max-height 动画 → CollapsibleSection animated variant | ✅ | vitest 25 tests (24 预存) | 删除 ~65 行 local Section 函数 |
| 187.6 | AnswerCard L2/L3 迁移 — useState → CollapsibleSection + headerClassName | ✅ | vitest 11 tests pass | `getByRole("button", { name: /L2/ })` 兼容 |
| 187.7 | IntentTestPanel 迁移 — 外层 `<details>` → CollapsibleSection，内层保留 | ✅ | vitest + tsc | 调试侧 details 独立不受影响 |
| 187.8 | 全栈门禁 | ✅ | make check + tsc + eslint + vitest | Python 600 ✅ · 前端 tsc 0 error · eslint 0 error · 0 回归 |

**新增文件**：`CollapsibleSection.tsx` + `CollapsibleSection.test.tsx` (25 tests)。**编辑**：8 源文件 + 5 测试文件。**净删 ~120 行重复 toggle 逻辑**。**A11**：A11 (aria-expanded) + A12 (aria-hidden) 一次性解决。

---

### ✅ Phase 31 Batch 6 — L0-6: KVRow 提取 (R2)

| # | 任务 | 状态 | 验证方式 | 证据 |
|---|------|:--:|------|------|
| 188.1 | `KVRow.tsx` 统一组件 — left label + right value + error prop + className/data-testid | ✅ | vitest 8 tests | label/value 渲染 + error 高亮 + className + data-testid + long text + empty |
| 188.2 | ProcessDrawer 迁移 — 删本地 KVRow，8 处调用签名不变 | ✅ | vitest 25 tests (24 预存 + 1 pass) | 零行为回归 |
| 188.3 | ModelInferencePanel 迁移 — 删本地 KVRow，3 处调用签名不变 | ✅ | vitest 21 tests pass | `py-gm-1`→`py-gm-1_5` 微调（视觉无感知） |
| 188.4 | 全栈门禁 | ✅ | make check + tsc + eslint + vitest | Python 600 ✅ · 前端 tsc 0 error · eslint 0 error · 0 回归 |

**新增文件**：`KVRow.tsx` + `KVRow.test.tsx` (8 tests)。**编辑**：ProcessDrawer.tsx / ModelInferencePanel.tsx。**净删 ~20 行重复代码**。

---

### ✅ Phase 31 Batch 8 — L0-8: DataState 收尾 · 简单组件

| # | 任务 | 状态 | 验证方式 | 证据 |
|---|------|:--:|------|------|
| 190.1 | JourneyHistoryBrowser → DataState — 删除本地 FetchState + 三态 JSX，替换为 DataState 包装 | ✅ | vitest 16 tests pass | 删除 RiLoader4Line/ErrorDisplay import + inline type + ~20 行 JSX |
| 190.2 | HealthDashboard → DataState — 删除本地 FetchState + 自定义 Error UI，替换为 DataState→ErrorDisplay | ✅ | vitest 9 tests pass | 删除 RiLoader4Line/RiErrorWarningLine + 自定义 error card ~30 行 |
| 190.3 | LogViewer → DataState — 删除本地 FetchState + 自定义 Error UI，替换为 DataState→ErrorDisplay | ✅ | vitest 10 tests pass | 删除 RiLoader4Line/RiErrorWarningLine + 自定义 error card ~30 行；空态保留内联（有上下文消息） |
| 190.4 | 全栈门禁 | ✅ | tsc + eslint + check-theme + check-docs | tsc 0 error · eslint 0 error · 5 route 0 console error · check-docs ✅ |

**修改文件**：JourneyHistoryBrowser.tsx / HealthDashboard.tsx / LogViewer.tsx + 3 test 文件。**净删 ~100 行重复代码（3 处本地 FetchState + 2 处自定义 error UI + 3 处 loading JSX）**。**FetchState 本地定义清理**：16→14 处（剩余 MemoryBrowserPanel / ExperimentComparePanel 待 Phase 31 Batch 9）。

---

### ✅ Phase 31 Batch 9 — L0-9: DataState 收尾 · 复杂组件

| # | 任务 | 状态 | 验证方式 | 证据 |
|---|------|:--:|------|------|
| 191.1 | MemoryBrowserPanel → DataState — 删除本地 FetchState + 双 tab 各自 DataState 包装 (loading/error/empty) | ✅ | vitest 11 tests pass | 删除 RiLoader4Line/ErrorDisplay import + local FetchState type + ~30 行 loading/error/empty JSX |
| 191.2 | ExperimentComparePanel → DataState — 删除本地 FetchState + preset 加载/错误态替换为 DataState | ✅ | vitest 6 tests pass | 删除 local FetchState type + ~5 行 loading JSX + presetLoading alias |
| 191.3 | 全栈门禁 | ✅ | tsc + eslint + check-theme + check-docs | tsc 0 error · eslint 0 error · 5 route 0 console error · check-docs ✅ |

**修改文件**：MemoryBrowserPanel.tsx / ExperimentComparePanel.tsx（测试零改动 — DataState API 与旧 ErrorDisplay + 文本断言兼容）。**FetchState 本地定义清理**：14→0 处（全部清除）。**净删 ~35 行重复代码（2 处本地 FetchState + 1 处 loading + 1 处 error + 1 处 empty + 1 处 presetLoading alias）**。

---

### ✅ Phase 31 Batch 10 — L0-10: CopyButton (R5) + RefreshButton (R7) 提取

| # | 任务 | 状态 | 验证方式 | 证据 |
|---|------|:--:|------|------|
| 192.1 | `CopyButton.tsx` — 复制到剪贴板按钮（2s "已复制"反馈） | ✅ | vitest 10 tests pass | 提取自 ModelInferencePanel + GhostPromptView 两处相同实现 |
| 192.2 | `RefreshButton.tsx` — 刷新按钮（ghost/bordered 双 variant） | ✅ | vitest 13 tests pass | 提取自 12 处重复实现，覆盖 ghost (JourneyHistoryBrowser) + bordered (10 panel) |
| 192.3 | 消费者迁移 — CopyButton: ModelInferencePanel + GhostPromptView | ✅ | vitest 消费者测试全绿 | 删除 2 处本地 CopyButton 实现 + RiFileCopyLine import |
| 192.4 | 消费者迁移 — RefreshButton: JourneyHistoryBrowser (ghost) + MemoryBrowserPanel (bordered) + PipelineTracePanel (bordered) | ✅ | vitest 消费者测试全绿 | 删除 3 处 inline refresh button + RiRefreshLine import |
| 192.5 | 全栈门禁 | ✅ | tsc + eslint + check-theme + check-docs | tsc 0 error · eslint 0 error · 5 route 0 console error · Python 600 passed |

**新增文件**：`CopyButton.tsx` / `RefreshButton.tsx` + 2 test 文件（23 tests）。**编辑文件**：ModelInferencePanel.tsx / GhostPromptView.tsx / JourneyHistoryBrowser.tsx / MemoryBrowserPanel.tsx / PipelineTracePanel.tsx（5 消费者）。**净删 ~50 行重复代码**（2 处本地 CopyButton + 3 处 inline refresh button CSS/icon/state 逻辑）。

**剩余**：✅ Phase 33 Batch 11-12 已完成 — 9 组件全部迁移。RefreshButton 消费者 13 处（含已迁 JourneyHistoryBrowser/MemoryBrowserPanel/PipelineTracePanel），零残留 inline refresh button。

---

### ✅ Phase 31 Batch 11 — L0-11: TabBar 提取

| # | 任务 | 状态 | 验证方式 | 证据 |
|---|------|:--:|------|------|
| 193.1 | `TabBar.tsx` — 统一 Tab 导航栏（controlled component + brand/info activeColor + sm/xs size + icon 支持 + ARIA tablist/tab/aria-selected） | ✅ | vitest 13 tests pass | tabs 渲染 + aria-selected + ariaLabel + onChange + icon + color/size variants + className |
| 193.2 | MemoryBrowserPanel 迁移 — inline tabs → TabBar (activeColor="info" size="xs") | ✅ | vitest 11 tests pass | getByRole("tab", { name: "记忆流" }) 零回归 |
| 193.3 | ObserveShell 迁移 — inline tabs → TabBar (default brand sm) | ✅ | vitest 通过（无独立 test 文件，check-theme 验证） | tsc 0 error · check-theme 5 route 0 error |
| 193.4 | LabShell 迁移 — inline tabs+icon → TabBar (default brand sm + icon support) | ✅ | vitest 5 tests pass | getByRole("tab", { name: /上下文/ }) + aria-selected + ariaLabel 零回归 |
| 193.5 | 全栈门禁 | ✅ | tsc + eslint + check-theme + check-docs | tsc 0 error · eslint 0 error · 5 route 0 console error · 719 tests pass |

**新增文件**：`TabBar.tsx` + `TabBar.test.tsx` (13 tests)。**编辑文件**：MemoryBrowserPanel.tsx / ObserveShell.tsx / LabShell.tsx（3 消费者）。**净删 ~40 行重复代码**（3 处 inline tab bar JSX）。

---

## Phase 32 — 质量基础建设 ✅

> 承接 Phase 31 L0 架构堵点清零。按用户决策先稳质量债再进用户断点。
> 四线并行规划（文档对齐 + 代码质量 + 测试补齐 + 瘦测试加厚），10 批全闭环，+260 tests。

### ✅ Phase 32 Batch 1 — 文档对齐（已完成）

| # | 任务 | 状态 | 验证方式 |
|---|------|:--:|------|
| C1.1 | architecture.md 补登记 26 组件行 | ✅ | 目视：layout/chat/ui/profile/lab 分组完整 |
| C1.2 | 3 命名修复（DecayHistogramPanel→DecayDistributionPanel 等） | ✅ | grep 零残留 |
| C1.3 | A3/A5 标注（数据主权→SessionHarvest, Ebbinghaus→ParamSliders） | ✅ | architecture.md 对应行注释 |
| C1.4 | ui-ux-patterns.md 追加 7 组件文档 | ✅ | Drawer/DataState/CopyButton/RefreshButton/TabBar/ErrorDisplay/KVRow |

### ✅ Phase 32 Batch 2 — 代码质量速赢（已完成）

| # | 任务 | 状态 | 验证方式 |
|---|------|:--:|------|
| C2.1 | Header DOM→React 状态化 | ✅ | vitest + tsc |
| C2.2 | ChatParamsContext tick 死代码切除 | ✅ | tsc 零回归 |
| C2.3 | AnswerCard DOMPurify + MermaidDiagram strict | ✅ | vitest 零回归 |

### ✅ Phase 32 Batch 3 — 测试基础设施（已完成）

| # | 任务 | 状态 | 验证方式 |
|---|------|:--:|------|
| C3.1 | vitest coverage 配置（v8 provider + 50/50/40/50 阈值） | ✅ | `npx vitest run --coverage` 可运行 |
| C3.2 | package.json `test:coverage` 脚本 | ✅ | `npm run test:coverage` 成功 |

### ✅ Phase 32 Batch 4 — 测试补齐 ①（刚完成）

| # | 任务 | 文件 | 状态 | 验证方式 |
|---|------|------|:--:|------|
| C4.1 | Logo 测试（渲染 icon + text） | 新 `__tests__/components/ui/Logo.test.tsx` (4 tests) | ✅ | vitest pass |
| C4.2 | Footer 测试（branding + GitHub 链接） | 新 `__tests__/components/layout/Footer.test.tsx` (4 tests) | ✅ | vitest pass |
| C4.3 | ConfidenceBadge 测试（label + 阈值颜色） | 新 `__tests__/components/ConfidenceBadge.test.tsx` (8 tests) | ✅ | vitest pass |
| C4.4 | Header 测试（5 nav + compact 态切换） | 新 `__tests__/components/layout/Header.test.tsx` (10 tests) | ✅ | vitest pass |
| C4.5 | DrawerContext 测试（open/close/error） | 新 `__tests__/components/DrawerContext.test.tsx` (6 tests) | ✅ | vitest pass |
| C4.6 | ChatPanel 加厚（loading + Enter + 空消息 + 畸形） | 改 `components/ChatPanel.test.tsx` (3→9 tests) | ✅ | vitest pass |

**Phase 32 Batch 4 成果**：+5 新测试文件 / +42 tests / vitest 全绿 / tsc 0 error / eslint 0 error。
**全栈测试**：65 test files / 758 tests（1 LearnPage 预存 jsdom 失败，与本次无关）。

**后续**：C5（AppShell/ObserveShell/StrategyPersona/ProfileModal/ChatParamsContext 5 组件测试）→ ✅ 已完成。

---

### ✅ Phase 32 Batch 5 — 测试补齐 ②（刚完成）

| # | 任务 | 文件 | 状态 | 验证方式 |
|---|------|------|:--:|------|
| C5.1 | ChatParamsContext 测试（provider + 默认值 + 部分更新 + stats + reset） | 新 `__tests__/components/chat/ChatParamsContext.test.tsx` (15 tests) | ✅ | vitest pass |
| C5.2 | AppShell 测试（布局 + children + drawer 开关） | 新 `__tests__/components/layout/AppShell.test.tsx` (7 tests) | ✅ | vitest pass |
| C5.3 | ObserveShell 测试（4 tabs + 切换 + placeholder） | 新 `__tests__/components/observability/ObserveShell.test.tsx` (8 tests) | ✅ | vitest pass |
| C5.4 | StrategyPersona 测试（loading + error + 排序 + 高亮） | 新 `__tests__/components/chat/StrategyPersona.test.tsx` (11 tests) | ✅ | vitest pass |
| C5.5 | ProfileModal 测试（开关 + 输入 + 创建 + Esc + 遮罩） | 新 `__tests__/components/profile/ProfileModal.test.tsx` (23 tests) | ✅ | vitest pass |

**Phase 32 Batch 5 成果**：+5 新测试文件 / +64 tests / vitest 全绿 / tsc 0 error / eslint 0 error。
**全栈测试**：70 test files / 822 tests（1 MermaidDiagram 预存 `securityLevel` 差异 + 1 LearnPage 预存 jsdom `scrollTo` 未实现，均与本次无关）。

**累计 Phase 32 测试补齐**：Phase 32 Batch 4(42) + Phase 32 Batch 5(64) + Phase 32 Batch 6(38) = +144 tests。

**后续**：23 个瘦测试文件（<8 tests）待分批加厚。

---

### ✅ Phase 32 Batch 6 — 测试补齐 ③（刚完成）

| # | 任务 | 文件 | 状态 | 验证方式 |
|---|------|------|:--:|------|
| C6.1 | Drawer 测试（动画状态机 + body lock + Esc + 遮罩 + 多实例） | 新 `__tests__/components/ui/Drawer.test.tsx` (13 tests) | ✅ | vitest pass |
| C6.2 | ContextWindowPanel 加厚（4→20：展开表格 + 5 分区 + Tools + 压缩/溢出） | 改 `components/ContextWindowPanel.test.tsx` (+16 tests) | ✅ | vitest pass |
| C6.3 | StepLatencyPanel 加厚（4→12：列完整性 + ms/s 格式化 + 单步无 badge + 刷新） | 改 `components/StepLatencyPanel.test.tsx` (+8 tests) | ✅ | vitest pass |

**Phase 32 Batch 6 成果**：+1 新测试文件 / +2 编辑文件 / +38 tests / vitest 全绿 / tsc 0 error / eslint 0 error。
**全栈测试**：71 test files / 860 tests（1 MermaidDiagram 预存 + 1 LearnPage 预存，均与本次无关）。

**累计 Phase 32 测试补齐**：Phase 32 Batch 4(42) + Phase 32 Batch 5(64) + Phase 32 Batch 6(38) = **+144 tests**。

**零测试组件**：✅ 全部清零！所有 `components/**/*.tsx` 均有对应测试文件。

**后续**：23 个瘦测试文件（<8 tests）待分批加厚。

---

### ✅ Phase 32 Batch 7 — 瘦测试加厚 ①（刚完成）

| # | 任务 | 文件 | 状态 | 验证方式 |
|---|------|------|:--:|------|
| C7.1 | Footer 加厚（4→10：分隔符 + CSS 布局 + hover 样式） | 改 `components/layout/Footer.test.tsx` (+6 tests) | ✅ | vitest pass |
| C7.2 | Logo 加厚（4→10：字体/布局/icon class + 装饰性验证） | 改 `components/ui/Logo.test.tsx` (+6 tests) | ✅ | vitest pass |
| C7.3 | HealthCard 加厚（6→11：延迟着色边界值 + 未知状态样式 + detail 截断边界） | 改 `components/HealthCard.test.tsx` (+5 tests) | ✅ | vitest pass |
| C7.4 | ContextHealthBadge 加厚（5→11：50%/80% 边界 + 颜色 dot class + 极端值 0%/100%） | 改 `components/ContextHealthBadge.test.tsx` (+6 tests) | ✅ | vitest pass |
| C7.5 | ExplainTooltip 加厚（7→11：术语规范名 + max-width + 复杂 JSX + badge 格式） | 改 `components/ExplainTooltip.test.tsx` (+4 tests) | ✅ | vitest pass |
| fix | MermaidDiagram `securityLevel: "loose"` → `"strict"` 修复预存失败 | 改 `components/MermaidDiagram.test.tsx` (1 行修复) | ✅ | vitest pass |

**Phase 32 Batch 7 成果**：0 新文件 / 6 编辑文件 / +27 tests + 1 修复 / vitest 全绿 / tsc 0 error / eslint 0 error。
**全栈测试**：71 test files / 887 tests（+27，LearnPage 预存错误 1 个未变）。

**累计 Phase 32 测试补齐**：Phase 32 Batch 4(42) + Phase 32 Batch 5(64) + Phase 32 Batch 6(38) + Phase 32 Batch 7(27) = **+171 tests**。

**后续**：18 个瘦测试文件（<8 tests）待分批加厚。

---

### ✅ Phase 32 Batch 8 — 瘦测试加厚 ②（刚完成）

| # | 任务 | 文件 | 状态 | 验证方式 |
|---|------|------|:--:|------|
| C8.1 | ChatInput 加厚（5→11：Shift+Enter 守卫 + 输入清空 + disabled 边界 + spinner + 按钮禁用逻辑） | 改 `components/ChatInput.test.tsx` (+6 tests) | ✅ | vitest pass |
| C8.2 | GhostPromptView 加厚（5→11：空字符串 + 展开/折叠生命周期 + Token 估算 + pre 样式） | 改 `components/GhostPromptView.test.tsx` (+6 tests) | ✅ | vitest pass |
| C8.3 | LabShell 加厚（5→11：重复点击 no-op + SVG 图标 + 滚动容器 + 快速切换 + 切回保持） | 改 `components/LabShell.test.tsx` (+6 tests) | ✅ | vitest pass |
| C8.4 | ThemeToggle 加厚（5→11：预挂载占位 + data-theme DOM + 无效值接受 + CSS 类） | 改 `components/ThemeToggle.test.tsx` (+6 tests) | ✅ | vitest pass |
| C8.5 | DrawerContext 加厚（6→12：竞态行为文档化 + traceId 更新 + 双 Provider 隔离 + 300ms 精确定时） | 改 `components/DrawerContext.test.tsx` (+6 tests) | ✅ | vitest pass |

**Phase 32 Batch 8 成果**：0 新文件 / 5 编辑文件 / +30 tests / vitest 全绿 / tsc 0 error / eslint 0 error。
**全栈测试**：71 test files / 917 tests（+30，LearnPage 预存错误 1 个未变）。

**累计 Phase 32 测试补齐**：Phase 32 Batch 4(42) + Phase 32 Batch 5(64) + Phase 32 Batch 6(38) + Phase 32 Batch 7(27) + Phase 32 Batch 8(30) = **+201 tests**。

### ✅ Phase 32 Batch 9 — 瘦测试加厚 ③（刚完成）

| # | 任务 | 文件 | 状态 | 验证方式 |
|---|------|------|:--:|------|
| C9.1 | DecayDistributionPanel 加厚（6→11：Y 轴刻度 + X 轴旋转标签 + 统计摘要 + 单 bin + 刷新） | 改 `components/lab/DecayDistributionPanel.test.tsx` (+5 tests) | ✅ | vitest pass |
| C9.2 | TokenDashboardPanel 加厚（6→11：未映射调用点 + 零值 idle + 排序验证 + bar 宽度 + 大数字格式化） | 改 `components/TokenDashboardPanel.test.tsx` (+5 tests) | ✅ | vitest pass |
| C9.3 | CacheStatsPanel 加厚（7→12：0%/100% 命中率 + 容量格式化 + 刷新更新 + 大数字千分位） | 改 `components/CacheStatsPanel.test.tsx` (+5 tests) | ✅ | vitest pass |
| C9.4 | ContextBar 加厚（7→12：压缩节省徽章 + 溢出徽章 + 切断线 + tools 段 + 压缩 tooltip） | 改 `components/ContextBar.test.tsx` (+5 tests) | ✅ | vitest pass |
| C9.5 | CostWaterfallPanel 加厚（7→12：k 后缀格式化 + 负号前缀 + 分隔线 + 汇总 footer + 原始数字） | 改 `components/CostWaterfallPanel.test.tsx` (+5 tests) | ✅ | vitest pass |

**Phase 32 Batch 9 成果**：0 新文件 / 5 编辑文件 / +25 tests / vitest 全绿 / tsc 0 error / eslint 0 error。
**全栈测试**：71 test files / 942 tests（+25，LearnPage + ProjectMapDrawer + scrollTo 3 个预存错误未变）。

**累计 Phase 32 测试补齐**：Phase 32 Batch 4(42) + Phase 32 Batch 5(64) + Phase 32 Batch 6(38) + Phase 32 Batch 7(27) + Phase 32 Batch 8(30) + Phase 32 Batch 9(25) = **+226 tests**。

### ✅ Phase 32 Batch 10 — 瘦测试加厚 ④ 收官（刚完成）

| # | 任务 | 文件 | 状态 | 验证方式 |
|---|------|------|:--:|------|
| C10.1 | SessionHarvest 加厚（6→11：Token k 后缀 + 非 ok 响应 + 大数值 + 时长渲染） | 改 `components/SessionHarvest.test.tsx` (+5 tests) | ✅ | vitest pass |
| C10.2 | EmbeddingSpacePanel 加厚（7→11：刷新按钮 + total_vectors + PC3 方差 + 网络异常） | 改 `components/EmbeddingSpacePanel.test.tsx` (+4 tests) | ✅ | vitest pass |
| C10.3 | IntentTestPanel 加厚（7→11：低置信度 + Ctrl+Enter + 空白禁用 + Token Usage 展示） | 改 `components/IntentTestPanel.test.tsx` (+4 tests) | ✅ | vitest pass |
| C10.4 | AppShell 加厚（7→11：抽屉生命周期 + main 样式 + ProcessDrawer 存在 + null children） | 改 `components/layout/AppShell.test.tsx` (+4 tests) | ✅ | vitest pass |
| C10.5 | NutritionLabel 加厚（7→12：0%/100% 边界 + 未知策略 fallback + 压缩脚注隐藏 + locale 格式化） | 改 `components/NutritionLabel.test.tsx` (+5 tests) | ✅ | vitest pass |
| C10.6 | ParamReplay 加厚（7→12：展开/折叠 + danger 样式 + threshold 边界 + 保留率最小宽） | 改 `components/ParamReplay.test.tsx` (+5 tests) | ✅ | vitest pass |
| C10.7 | PipelineTracePanel 加厚（7→10：折叠展开行 + 未知状态徽章 + 空 metrics） | 改 `components/PipelineTracePanel.test.tsx` (+3 tests) | ✅ | vitest pass |
| C10.8 | ProfileCard 加厚（7→11：标签置信度颜色 + Link href + 错误态无 link） | 改 `components/ProfileCard.test.tsx` (+4 tests) | ✅ | vitest pass |

**Phase 32 Batch 10 成果**：0 新文件 / 8 编辑文件 / +34 tests / vitest 全绿 / tsc 0 error / eslint 0 error。
**全栈测试**：71 test files / 975 tests（+33，2 个预存 scrollTo 错误未变）。

**🏁 Phase 32 测试补齐全部完成**：C4(42) + C5(64) + C6(38) + C7(27) + C8(30) + C9(25) + Phase 32 Batch 10(34) = **+260 tests**。
**终点状态**：0 个瘦测试文件（<8 tests），所有测试文件 ≥8 tests。

---

## Phase 33 — 用户断点修复 + P1 清零 ✅

> 战略定位：Phase 31 L0 清零 + Phase 32 质量基础建成。Master Backlog 用户断点修复 + P1 全量清零，分两阶段交付。
> 第一阶段 (Phase 33 Batch 1-7)：U1/U7/U10/U11/U14/E2/E6 等 7 批用户断点修复。
> 第二阶段 (Phase 33 Batch 8-10)：Master Backlog 30 P1 → 0，3 批闭环。

### ✅ Phase 33 Batch 1 — 移动端响应式布局（已完成）

| # | 任务 | 状态 | 验证方式 |
|---|------|:--:|------|
| 194.1 | Drawer `position` prop（left/right，默认 right） | ✅ | 3 个现有调用方零改动 + vitest 980 passed |
| 194.2 | Sidebar 去硬编码隐藏（`hidden lg:flex w-64` → `flex`） | ✅ | 零测试改动 |
| 194.3 | Header 汉堡按钮 + nav `hidden lg:flex` + `lg:col-span-2` | ✅ | vitest + tsc 零 error |
| 194.4 | Footer `col-span-2` → `lg:col-span-2` + 竖排防挤压 | ✅ | vitest + tsc 零 error |
| 194.5 | AppShell 响应式网格 + 移动端左侧 Drawer（Sidebar 内容） | ✅ | +4 新测试 / vitest 980 passed |

**涉及文件**：Drawer.tsx / Sidebar.tsx / Header.tsx / Footer.tsx / AppShell.tsx（5 文件）+ AppShell.test.tsx（+4 tests）
**证据**：tsc 0 error · eslint 0 error · vitest 980 passed · check-theme 5 route 0 error

**⚠️ 已知限制 — 移动端导航菜单缺失**：Header 的 5 个导航链接（聊天/文档/可观测/实验室/画像）在移动端被 `hidden lg:flex` 隐藏，汉堡按钮打开的左侧 Drawer 包含的是 Sidebar（认知参数/会话统计等），不包含导航链接。移动端用户无法在页面间切换。**决策（2026-06-25）**：移动端全面适配暂缓至远期独立 Phase。理由：① 移动端非最紧急事项；② 当前内容仅聊天页、文档/问题列表、画像页适合移动端，其余页面（可观测/实验室）信息密度和图表复杂度不适合窄屏；③ 移动端适配本质是产品问题而非 CSS 问题，需独立设计交互模型。Phase 33 Batch 1 代码保留，仅解决 U1（Header 溢出）+ U7（零响应式适配）两个阻断性问题。

### ✅ Phase 33 Batch 2 — ErrorDisplay 收尾 (E6 + Pattern C 3 组件)

| # | 任务 | 状态 | 验证方式 |
|---|------|:--:|------|
| 195.1 | ErrorDisplay `technicalDetail` 仅非生产环境渲染（`typeof process` guard 防 jsdom crash） | ✅ | vitest 980 passed |
| 195.2 | SessionHarvest boolean error → `Error \| null` + ErrorDisplay card + retry | ✅ | vitest + check-theme |
| 195.3 | ProfileCard boolean error → `Error \| null` + ErrorDisplay inline + retry | ✅ | vitest |
| 195.4 | ProfileShell fetch error boolean→Error + actionError string→Error + ErrorDisplay | ✅ | vitest + tsc |
| 195.5 | ProfileModal error prop `string\|null` → `Error\|string\|null` + ErrorDisplay inline | ✅ | vitest |

**涉及文件**：SessionHarvest.tsx / ProfileCard.tsx / ProfileShell.tsx / ProfileModal.tsx / ErrorDisplay.tsx（5 源码）+ 4 test 文件
**证据**：tsc 0 error · eslint 0 error · vitest 980 passed · check-theme 5 route 0 error
**Master Backlog**：E6 关闭（SessionHarvest/ProfileCard 无重试），Pattern C 3 组件全量清零

### ✅ Phase 33 Batch 3 — U10 ExplainTooltip 边界检测 + Pattern D err.message 清零

| # | 任务 | 状态 | 验证方式 |
|---|------|:--:|------|
| 196.1 | U10 — ExplainTooltip 视口边界检测：安装 `@floating-ui/react`，`useFloating` + `shift()` + `flip()` 替代纯 CSS `left:50%` 定位 | ✅ | ExplainTooltip 11 tests pass + check-theme |
| 196.2 | Pattern D — 6 处 `err.message` 字符串提取清零：MermaidDiagram / JourneyHistoryBrowser / Sidebar(×2) / LogViewer / HealthDashboard | ✅ | 存储原始 Error → categorizeError 可检测 name/status |
| 196.3 | DataState + ErrorDisplay `error` prop 类型放宽 `unknown`（配合 Pattern D） | ✅ | tsc 0 error · 消费者类型兼容 |
| 196.4 | 全栈门禁 | ✅ | tsc 0 error · eslint 0 error · vitest 979/980 (1 预存 flaky) · check-docs ✅ |

**涉及文件**：ExplainTooltip.tsx / MermaidDiagram.tsx / JourneyHistoryBrowser.tsx / Sidebar.tsx / LogViewer.tsx / HealthDashboard.tsx / DataState.tsx / ErrorDisplay.tsx（8 源码）+ package.json + ExplainTooltip.test.tsx
**证据**：tsc 0 error · eslint 0 error · vitest 979/980 (1 预存 flaky) · check-docs ✅
**Master Backlog**：U10 关闭（ExplainTooltip 视口边界检测），Pattern D 6 点清零（err.message 字符串提取不再破坏类型信息）

### ✅ Phase 33 Batch 4 — U11 ExplainPopover 窄屏 + E2 useChat error 分类

| # | 任务 | 状态 | 验证方式 |
|---|------|:--:|------|
| 197.1 | U11 — ExplainPopover 窄屏溢出：`max-w-[480px]` → `max-w-[min(480px,calc(100vw-2rem))]` | ✅ | vitest + Playwright 窄视口 |
| 197.2 | E2 — useChat error 分类：catch 块 `err.message` 替换为 `categorizeError(err)` | ✅ | vitest useChat tests + tsc |
| 197.3 | 全栈门禁 | ✅ | tsc + eslint + vitest + check-theme + check-docs |

> **粒度评估**：2 文件 / 2 行改动，各自过薄无法独立成批，合并后 2-4 turns 可闭环。U11 是 U10 姐妹 issue，E2 是 Pattern D 自然延伸。

### 🔵 Phase 33 Batch 5 — CSS/layout P1 速赢 (U2 + U3 + U12 + U13)

| # | 任务 | 状态 | 验证方式 |
|---|------|:--:|------|
| 198.1 | U2 — Footer 对齐：Footer `col-span-2` 在 sidebar 展开时未考虑 256px 偏移 | ✅ | `lg:col-start-2` + check-theme |
| 198.2 | U3 — 布局 CSS 变量：定义 `--header-h` / `--sidebar-w` + globals.css + 消费者替换硬编码 | ✅ | `w-[var(--spacing-sidebar-w)]` + tsc + check-theme |
| 198.3 | U12 — ProjectMapDrawer maxHeight cap：`4000px/2000px` → 保守上限 | ✅ | vitest (2000px/800px) |
| 198.4 | U13 — NutritionLabel col-span-2：flex 父容器中的无效 grid class 清理 | ✅ | vitest + eslint |
| 198.5 | 全栈门禁 | ✅ | tsc + eslint + vitest + check-theme + check-docs |

> **粒度评估**：4 个 CSS/layout 域 fix，各 1-2 行，合并后 ~5 文件。同域归并减少上下文切换。U2/U3 共用 Playwright 诊断流程。

### ✅ Phase 33 Batch 6 — U14 图片预览/lightbox

| # | 任务 | 状态 | 验证方式 |
|---|------|:--:|------|
| 199.1 | `ImageViewer` 组件 — click-to-zoom lightbox（backdrop + 缩放 + 关闭） | ✅ | vitest 11 tests pass |
| 199.2 | MermaidDiagram 集成 — SVG 点击 → ImageViewer | ✅ | vitest 20 tests (+5 lightbox) |
| 199.3 | 全栈门禁 | ✅ | tsc 0 · eslint 0 · vitest 996 · check-theme 5 route 0 · check-docs ✅ |

> **粒度评估**：新组件 1 个 + 集成点 1 个，4 文件。比 CSS fix 重，独立成批，不走 TDD 兜底。
> **证据**：ImageViewer.tsx (132 lines) + ImageViewer.test.tsx (11 tests) + MermaidDiagram.tsx (272 lines +lightbox) + MermaidDiagram.test.tsx (20 tests)。996 tests 全绿。

### ✅ Phase 33 Batch 7 — 移动端导航链路修复 (U1 + U7 + CROSS-19)

| # | 任务 | 状态 | 验证方式 |
|---|------|:--:|------|
| 200.1 | `navLinks.ts` 共享数据模块 — PAGE_LINKS + MOBILE_LINKS + 双样式函数 | ✅ | tsc 零 error |
| 200.2 | Header.tsx 机械重构 — 内联 linkClass → 模块消费 | ✅ | vitest Header tests 全绿 |
| 200.3 | AppShell.tsx 移动端导航注入 — Drawer 内 3 nav link + auto-close | ✅ | vitest +3 AppShell tests pass |
| 200.4 | 全栈门禁 | ✅ | tsc 0 · eslint 0 · vitest 999 · check-theme 5 route 0 · check-docs ✅ |

> **粒度评估**：1 新建 + 2 重构 + 1 测试，5 文件。纯前端 Batch，机械重构为主。
> **证据**：navLinks.ts (44 lines) + Header.tsx (净删 5 lines) + AppShell.tsx (+14 lines) + AppShell.test.tsx (+3 tests + rAF infra)。999 tests 全绿。

---

### 第二阶段 — Phase 33 Batch 8-10：Master Backlog P1 清理

> Master Backlog 30 P1 → 0。经全量审计 22 项已解决未标记 + 5 项仍开放 + 1 项降级 P2，3 批闭环。
> 最后更新: 2026-06-25 (全闭环 — P1: 30→0)

### ✅ Phase 33 Batch 8 — Master Backlog 状态刷新

| # | 任务 | 状态 | 验证方式 |
|---|------|:--:|------|
| A1.1 | 22 BACKLOG_OUTDATED P1 → strikethrough + ✅ + Batch ref | ✅ | `grep -c "✅ 已解决"` → 34 |
| A1.2 | Patterns P1-P3 落地状态更新 | ✅ | 目视 |
| A1.3 | 汇总统计表 + 健康仪表盘 + 分批框架刷新 | ✅ | 目视 |
| A1.4 | CROSS-18 P1→P2 降级 (延后至移动端 Phase) | ✅ | roadmap L2203 引用 |

> **成果**：P1 30→4。纯文档 Batch，零代码变更。

### ✅ Phase 33 Batch 9 — CROSS P1 CSS Token 消费者迁移

| # | 任务 | 状态 | 验证方式 |
|---|------|:--:|------|
| A2.1 | CROSS-12 — 6 处 duration 硬编码→`var()` + 新增 `--gm-duration-hero: 1500ms` | ✅ | tsc + eslint + vitest + check-theme |
| A2.2 | CROSS-23 — ExplainPopover pill `"#fff"` → `"var(--gm-text-on-brand)"` | ✅ | tsc + eslint + check-theme |
| A2.3 | CROSS-27 — 7 处硬编码 z-index→`var(--gm-z-*)` token 迁移 (ExplainPopover/ProfileModal/ErrorDisplay/ExplainTooltip/ImageViewer/immersive×3) | ✅ | tsc + eslint + vitest + check-theme |
| A2.4 | 全栈门禁 | ✅ | tsc 0 · eslint 0 · vitest 998/999 (1 预存 flaky) · check-theme 5 route 0 · check-docs ✅ |

> **涉及文件**：`globals.css` (9 edits) + ExplainPopover.tsx (2) + ProfileModal.tsx (1) + ErrorDisplay.tsx (1) + ImageViewer.tsx (2) + ExplainTooltip.tsx (1) = 6 文件。
> **成果**：P1 4→1。动画 100% token 化 · z-index 6 层全部迁移 · pill 主题适配。

### ✅ Phase 33 Batch 10 — CROSS-2 `/learn` 布局统一

| # | 任务 | 状态 | 验证方式 |
|---|------|:--:|------|
| A3.1 | AppShell `sidebar` slot prop (可选自定义侧边栏) | ✅ | tsc + vitest 1004/1004 |
| A3.2 | `/learn` 迁移至 AppShell (消除 `h-screen flex flex-col`) | ✅ | tsc + check-theme 5 route 0 error |
| A3.3 | 全栈门禁 | ✅ | tsc 0 · eslint 0 · vitest 1004/1004 · check-theme 5 route 0 · check-docs ✅ |

> **涉及文件**：`AppShell.tsx` (+sidebar slot prop) + `learn/page.tsx` (迁移到 AppShell) + `globals.css` (gm-immersive 修复) + `AppShell.test.tsx` (+5) + `LearnPage.test.tsx` (+mock) + `master-backlog.md` (CROSS-2 ✅) = 7 文件。
> **成果**：`/learn` 不再独立布局，统一到 AppShell CSS Grid。sidebar slot 模式（ReactNode 替换默认 / false 隐藏）为未来页面侧栏定制提供统一入口。**Phase 33 全闭环**：用户断点修复 + P1 30→0 达成 ✅

---

## Phase 34 — 内容可视化（文档流程图嵌入）✅

> **承接 Phase 33**：用户断点修复 + P1 全部清零后，首个纯产品价值 Phase。给 `/learn` 93 问答案嵌入 Mermaid 流程图，提升复杂概念的图形表达力。
> **范围**：5 个任务，<10 文件，≤5 Batch。技术方法已锁定（折叠区下详）。
> **最后更新**: 2026-06-26

| # | 任务 | 状态 | 完成标准（全部机械化可验证） | 涉及文件 |
|---|------|:--:|------|------|
| Phase 34 Batch 1 | MermaidDiagram 主题一行映射：`"dark"` → `"neutral"` | ✅ | ① `const theme = isDarkTheme ? "dark" : "neutral"` (1 行) ② 测试断言同步 `"default"`→`"neutral"` (2 处) ③ tsc 0 · eslint 0 · vitest 20/20 · check-theme 5 route 0 | `MermaidDiagram.tsx` (1 行) |
| Phase 34 Batch 2 | `renderMarkdown()` 支持 ` ```mermaid ` fenced code → base64 placeholder → useEffect 水合 | ✅ | vitest 15 tests (4 新): ① mermaid block→`.gm-mermaid-block`② 普通代码块不受影响 ③ 混合内容 ④ 空 block 不崩溃 · tsc 0 · eslint 0 · vitest 1012/1012 · check-theme 5 route 0 | `AnswerCard.tsx` |
| Phase 34 Batch 3 | 93 问首批流程图嵌入（`flowcharts.ts` 3 张 + 试点 2-3 张） | 🔧 试点完成 | ✅ 试点: q1.1 L1 嵌入策略决策图 (1/≥5) · tsc 0 · eslint 0 · vitest 1012/1012 · check-theme 5 route 0 · 正式铺量待对齐思路后启动 | `ch1.ts` (q1.1) |
| Phase 34 Batch 4 | 逐轮内容 Review + 流程图嵌入（MVP=14 P0，每轮 2-4 题） | ✅ 5/5 有内容题全量嵌入 | 每轮：读答案→判定是否适合加图→推荐类型→写 Mermaid→嵌入→验证→确认→下轮。不攒批。 | 内容源文件 |
| Phase 34 Batch 5 | L5 拉通自检 | ✅ | vitest 1019/1019 · tsc 0 · eslint 0 · check-docs 全绿 · check-theme 5 route 0 error · requirements-log 追加 6 轮记录 | — |

### 14 P0 进度表 — 流程图嵌入追踪

> **源头**：`docs/core_issues.md` P0 档 14 问（优先值 ≥ 4）。全量答案入驻 `frontend/src/lib/content/answers/ch*.ts`。
> **当前**：14 问 P0 全量完结——答案 ✅（12 已全部嵌入流程图，0 空壳）🎉
> **终态 (2026-06-29 评估决策)**：Phase 46 Batch 3 补齐最后一个 P0 空壳 q3.2。汇总：✅ 已嵌入 12
> **轮3 (typography)**：Blockquote emoji → 粗体标签，5 内容文件装饰性 emoji 全清理，Mermaid 块内保留。详见 `requirements-log.md` Phase 34 轮3。  
> **轮4 (layout)**：全局独立双滚动——AppShell grid `h-dvh` + `min-h-0` + 高度链补全，聊天页和问答页左右两栏各自独立滚动。详见 `requirements-log.md` Phase 34 轮4。  
> **轮5 (q4.1)**：Token 计量三层精度模型流程图——三层计数路径（API精确/tiktoken预计算/字符启发式）汇聚到 TokenLedger，分发至三个消费端。详见 `requirements-log.md` Phase 34 轮5。

| # | 章节 | 问题概要 | 答案 | 流程图 | 适合加图? | 推荐类型 |
|---|------|---------|:--:|:--:|:--:|------|
| 1.1 | Ch1 上下文工程 | 上下文溢出处理策略比较 | ✅ | ✅ | ✅ 是 | flowchart TD（策略决策树） |
| 1.2 | Ch1 上下文工程 | 输出+原文超出窗口的处理 | ✅ | ✅ | ✅ 是 | graph TD（升级：三方案决策 + emoji/配色） |
| 1.3 | Ch1 上下文工程 | 上下文重复信息处理 | ✅ | ✅ | ✅ 是 | graph TD（升级：三层防线漏斗 + emoji/配色） |
| 2.1 | Ch2 记忆系统 | 事实抽取手段对比 | ✅ | ✅ | ✅ 是 | flowchart TD（三路线决策图 + 防幻觉层） |
| 2.4 | Ch2 记忆系统 | 信息压缩手段对比 | ✅ | ✅ | ✅ 是 | flowchart LR（五手段对比，嵌入 L1） |
| 2.6 | Ch2 记忆系统 | 合理遗忘策略对比 | ✅ | ✅ | ✅ 是 | graph TD（遗忘策略对比 + 记忆生命周期） |
| 2.8 | Ch2 记忆系统 | 重复记忆处理 | ✅ | ✅ | ✅ 是 | graph LR（三道防线 + 层级漏斗） |
| 2.17 | Ch2 记忆系统 | 真删 vs 降权决策 | ✅ | ✅ | ✅ 是 | graph TD（软遗忘 vs 真删决策树） |
| 3.1 | Ch3 任务规划 | 意图识别手段对比 | ✅ | ✅ | ✅ 是 | graph TD（三路线决策 + 三层容错） |
| 3.2 | Ch3 任务规划 | LLM 意图识别流程详解 | ✅ | ✅ | ✅ 是 | graph TD（四步流程 + 三层容错，嵌入 L1） |
| 4.1 | Ch4 Token 效率 | Token 估算/计量方法 | ✅ | ✅ | ✅ 是 | graph TD（三层精度模型 + TokenLedger → 消费者） |
| 4.2 | Ch4 Token 效率 | Token 节省手段对比 | ✅ | ✅ | ✅ 是 | graph TD（五层节约金字塔 + 逐层降级决策） |
| 4.5 | Ch4 Token 效率 | Token 消耗归因粒度 | ✅ | ✅ | ✅ 是 | graph TD（三级归因粒度递进 + 消费端映射） |
| 7.6 | Ch7 透明化设计 | 错误教学化 vs 错误隐藏 | ✅ | ✅ | ✅ 是 | graph TD（决策频谱：静默→教学化→严重度容器） |

### 交付原则（2026-06-26 对齐确认）

1. **MVP 先行**：14 P0 全部嵌入 → 再决定是否继续 P1/P2/P3。不憋大招。
2. **逐轮增量**：每轮 2-4 题，Review→判定→写图→嵌入→验证→确认→下轮。不做完不看。
3. **故事驱动 (A+B)**：A — 每轮有叙事 hook（如 Ch1 的"溢出三部曲"串联相关题）；B — 每轮有清晰的 commit/roadmap 叙事（为什么做这些题、它们之间什么关系）。
4. **纯内联嵌入**：流程图嵌在答案里（`renderMarkdown` fenced code → AnswerCard 渲染），不建独立图表浏览页。
5. **机会主义加图**：问答 Review 是主线。操作界面（ChatPanel/Sidebar/Profile 等）看到适合加图的地方，当时就加——不专门排期，也不强行加。
6. **不强行加戏**：Review 判定不适合加图的题，直接标记 ❌，不勉强凑数。

### 执行节奏

```text
Phase 34 — 内容可视化（文档流程图嵌入）🔵
MVP = 14 P0 全部嵌入流程图。当前 5/14 有内容，先做有内容的 4 题（q1.1 已有图）。

新轮1: "系统入口：事实抽取"
    q2.1 事实抽取手段对比
    故事：信息进入记忆系统的第一道工序——从自由文本到结构化事实

   ── 交叉点 A：UI 掠扫 #1 ──

新轮2: "意图识别手段"
    q3.1 意图识别手段对比
    故事：用户说了一句话，系统怎么知道他想干什么

✅ 新轮3: "Token 计量"
    q4.1 Token 估算/计量方法
    故事：AI 的"水表"——怎么算清楚每次对话花了多少钱

✅ 新轮4: "错误哲学"
    q7.6 错误教学化 vs 错误隐藏
    故事：系统出错了——是诚实暴露还是温柔隐藏

   ── 交叉点 B：UI 掠扫 #2 ──

─── 5/14 完成后评估 ───
  决策 (2026-06-26)：Phase 34 正式闭环。
  理由：Phase 34 交付的是"可视化基础设施 + 有内容题的流程图嵌入"。
        基础设施 (Batch 1-2) ✅ / 5/5 有内容题全部嵌入 ✅ / L5 ✅。
        9 题空壳阻塞在内容管线（答案未生产），不是可视化 Phase 的职责范围。
  去向：9 空壳题登记至下方"内容管线延迟项"，内容管线产出答案后作为该 Batch 的必然步骤同步嵌入。
  优先级：内容管线排期驱动，不加急。P0 5 题已有图的锚点已立。
```

### 交叉点 UI/UX 修复分流规则

```text
发现 UI/UX 问题
  │
  ├── ≤ 2 文件 · ≤ 50 行 · 不涉及新组件
  │     → 塞入当前轮，commit message 标注 "Phase 34 轮X: qX.X 流程图 + 顺手修 Y"
  │
  ├── 3-5 文件 · 50-200 行 · 或涉及 1 个新组件
  │     → 当前轮完成后，追加"交叉点 Batch"，做完再进下一轮
  │
  └── >5 文件 · >200 行 · 需要独立设计评审
        → 记入下方发现清单，MVP 后统一评估是否独立成 Phase 35
```

纪律：Phase 34 主体是 14 P0 流程图嵌入。交叉点累积 >3 个独立 UI 修复 → 暂停，给它们独立建 Phase。

### 交叉点发现清单

| 发现时机 | 描述 | 规模 | 处理 |
|---------|------|------|:--:|
| 轮 1 启动前 | 9 个 P0 问题空壳：q1.2/q1.3/q2.4/q3.2/q4.2 答案未写入（q2.6/q2.8/q2.17 已在 Phase 36 补齐；q4.2/q4.5 已在 Phase 38 B3 补齐） | 内容管线 | 🔀 已转移至「内容管线延迟项」（见下方），Phase 34 闭环后不追 |

### 内容管线延迟项 — ✅ 全部补齐（0 空壳）

> **终态**：Phase 46 Batch 3 [[2026-06-29]] 补齐最后一个 P0 空壳 q3.2。14 P0 全量完结。🎉

| # | 问题概要 | 章节 | 推荐图类型 | 状态 |
|---|---------|------|---------|:--:|
| 2.4 | 信息压缩手段对比 | Ch2 记忆系统 | flowchart LR | ✅ 已补齐（Phase 46 B1） |
| 2.6 | 合理遗忘策略对比 | Ch2 记忆系统 | flowchart TD | ✅ Phase 36 B1 已完成 |
| 2.8 | 重复记忆处理 | Ch2 记忆系统 | flowchart TD | ✅ Phase 36 B3 已完成 |
| 2.17 | 真删 vs 降权决策 | Ch2 记忆系统 | flowchart TD | ✅ Phase 36 B4 已完成 |
| 3.2 | LLM 意图识别流程详解 | Ch3 任务规划 | graph TD | ✅ 已补齐（Phase 46 B3） |

<details>

<details>
<summary>技术方法（已锁定，回头参考）</summary>

**Phase 34 Batch 1 — 一行映射**：`MermaidDiagram.tsx:80` → `const theme = isDarkTheme ? "dark" : "neutral";`。Mermaid v11.15 内置 `neutral` 主题，不升级依赖，不改 ThemeToggle。

**Phase 34 Batch 2 — 渲染管线**：`renderMarkdown()` fenced code 检测 `lang === "mermaid"` → 输出 `<div class="gm-mermaid-block" data-chart="<base64>">` 替代 `<pre><code>`。AnswerCard `useEffect` 扫描 `.gm-mermaid-block` 动态挂载 MermaidDiagram。base64 编码规避 HTML 转义和注入风险。

**不涉及**：ThemeToggle.tsx、app 全局主题系统、mermaid 依赖升级。
</details>

---

## Phase 35 — ContextualLens 聊天页微型教学入口 🔵

> 将 Phase 34 的 5 张 mermaid 流程图引入聊天页，做成上下文感知的微型教学入口。
> 用户在产生疑问的瞬间得到洞察，不需要离开聊天去翻 `/learn` 文档。

| Batch | 内容 | 状态 | 关键交付 |
|:------|------|:----:|---------|
| Phase 35 Batch 1 | ContextualLens 组件基础 + extractMermaid 工具 + 测试 | ✅ | `ContextualLens.tsx`（可复用展开组件）+ `extractMermaid.ts`（mermaid 提取工具）+ 6 tests |
| Phase 35 Batch 2 | 三触发点集成 + L5 收尾 | ✅ | ChatMessage token 透镜 (q4.1) + ErrorDisplay 错误透镜 (q7.6) + OnionPanel 溢出透镜 (q1.1) + 5 tests + 文档闭环 |
| Phase 35 Batch 3 | UX 三改：意图气泡→抽屉 + 按钮一行化 + 头部点击收起 | ✅ | IntentPill onClick + 删深度抽屉按钮 + 一键行 toggle + 3 面板 header-click-to-collapse + 11 tests |
| Phase 35 Batch 4 | ProcessDrawer 评审修复：P0-P3 四问题 | ✅ | P0 parsedResult 错位 / P1 planner_parse_error 数据源 / P2 全展开过载 / P3 硬编码定价 + CodePre 提取 + code-format.ts 抽离 + 1 test |

### Phase 35 Batch 1 详情

**ContextualLens** — 纯展示展开/收起组件，封装 trigger button → expanded card 的 toggle 模式。Props: `triggerLabel`, `triggerIcon`, `title`, `children`, `defaultOpen`。展开容器 `rounded-gm-md border bg-surface-elevated`。折叠态按钮样式与 ChatMessage 现有 4 个 toggle 一致。

**extractMermaid** — 从 Answer.l1 提取第一个 ` ```mermaid ` 代码块。复用 AnswerCard `renderMarkdown` 正则，保持提取逻辑一致。导出 `extractMermaidFromString(md)` 和 `extractMermaidFromAnswer(answer)`。

**验证**：tsc 0 · eslint 0 · vitest 6/6 · check-theme 5 route 0 error · Python make check 600/600

### Phase 35 Batch 3 详情 (2026-06-26)

**UX 三改**：
1. **意图气泡→深度抽屉**：IntentPill 新增 `onClick` prop，用户消息上的意图 pill 点击直接打开 ProcessDrawer。删除 AI 回复下方的独立「深度抽屉」按钮。ChatPanel 新增 `userTraceMap`（与 userIntentMap 同模式构建）传递 api_trace 到用户消息。
2. **按钮一行化**：AI 回复下方 4 个 toggle 按钮从垂直 `space-y` 改为 `flex flex-wrap` 一行排列，去除所有 Remixicon 图标，纯文字 `text-gm-xs`，`·` 分隔。展开时按钮保持可见并高亮（`text-brand font-medium`）。
3. **头部点击收起**：ContextualLens 标题可点击收起；OnionPanel 新增 `onCollapse` prop 渲染顶部收起行；JourneyCards/JourneyHistoryBrowser header 可点击收起。长内容无需滚到底部找「收起」按钮。

**验证**：tsc 0 · eslint 0 · vitest 1034/1034 · check-theme 5 route 0 error · Python make check 600/600

### Phase 35 Batch 4 详情 (2026-06-26)

**ProcessDrawer 评审修复 — P0-P3 四问题**：
1. **P0: Section 2 parsedResult 语义错位** — parsedResult 是 Planner 分类产物而非模型返回。从 Section 2「模型响应」移除 JsonBlock（parsedResult），只保留 rawResponse CodeBlock + 响应耗时。Section 3 已有 Parsed Result。
2. **P1: parseError 数据源混乱** — `planner_parse_error`（分类器自身 LLM 调用的解析错误）已由后端注入 api_trace 但前端未读取。改为优先读取 `planner_parse_error`，回退到主引擎 `parse_error`。
3. **P2: 全展开过载** — 4 个 CollapsibleSection 全 `defaultOpen` 导致 520px 抽屉首次打开需滚动。改为仅 Section 1 始终展开，Section 2 仅 rawResponse 非空时展开，其余默认折叠。
4. **P3: 硬编码定价** — `¥{((totalTokens * 0.000002)).toFixed(4)}` 模型绑定且只算主调用。替换为纯 token 数量文案。

**附加改进**：空 Constants 段落删除 + CodePre 子组件提取（CodeBlock/JsonBlock `<pre>` 样式去重）+ 5 个格式化函数抽离到 `lib/code-format.ts`。

**验证**：tsc 0 · eslint 0 · vitest 26/26 · check-theme 5 route 0 error · check-docs 全绿

---

## Phase 1000 — 工程治理 ✅

> 跨切面的编码规范、依赖升级、lint 升级、测试补齐等治理工作归入此 Phase。Batch 在 Phase 1000 内独立计数，与产品 Phase 1-99 隔离。

| Batch | 内容 | 状态 | 关键交付 |
|:------|------|:----:|---------|
| Phase 1000 Batch 1 | P0 高危修复 (3 files) | ✅ | `except Exception: pass` ×3 → logger/console.error |
| Phase 1000 Batch 2 | P1 类型安全 + 无障碍 (4 files) | ✅ | `!` → guarded access / `Record` 窄化 / `aria-expanded` |
| Phase 1000 Batch 3 | P1 ProcessDrawer/ContextualLens/ChatInput (3 files) | ✅ | `as string` runtime validate / CSS token / 常量提取 |
| Phase 1000 Batch 4 | api/types.ts 拆分 (6 files) | ✅ | 584 行 → 6 领域文件 + barrel 透传 · 10 JSDoc |
| Phase 1000 Batch 5 | lib JSDoc 补齐 (4 files) | ✅ | constants/chatParams/code-format/errorCategories 常量 + docstring |
| Phase 1000 Batch 6 | 组件 JSDoc 补齐 (8 files) | ✅ | 8 文件头 JSDoc + 8 组件/接口 docstring + 2 常量 |
| Phase 1000 Batch 7 | Python 编码规范清理 (4 files) | ✅ | PEP 8 except 语法 / 10 魔数提取 / docstring / init_engines 拆分 |
| Phase 1000 Batch 8 | src/ docstring 门禁升级 | ✅ | `make check-comments` 从告警 → 硬拦截 (6b2d088) |
| Phase 1000 Batch 9 | 已合并至 Batch 11 | ✅ | — |
| Phase 1000 Batch 10 | 已合并至 Batch 11 | ✅ | — |
| Phase 1000 Batch 11 | 轨 A GLM-5.2 评估 + 模型对比文档统一 | ✅ | `model-comparison.md` Qwen 追加 + 三文档同步 |
| Phase 1000 Batch 12 | 文档全量同步 — 7 文件刷新至 Phase 52 | ✅ | 7 文件 header 日期 + 过期路径 + 清理 4 Plan 残留 |
| Phase 1000 Batch 13 | 需求验证方式字段标准化 | ✅ | `**验证**：` → `**验证方式**：` ×91 处 · 门禁 64/127 → 127/155 ✅ |
| Phase 1000 Batch 14 | 四支柱代码→93问内容缺口补齐 | ✅ | 新增 q2.27 (记忆固化) + q3.17 (Plan 持久化) · chapters.ts 刷新 · 93→95 问 |
| Phase 1000 Batch 15 | 4 个过期答案刷新至 Phase 53-57 现实 | ⊘ | superseded by B24+B25 — 4 题全覆：q2.13 (B25 重写) · q4.4 (B24 P0 + B25 Phase α/β) · q2.7 (Phase 48-56 ConsolidationCore 自然刷新) · q3.9 (Phase 57 ReplanDetector 自然刷新)。全量审计 8 章 37 处修正远超原 4 题范围 |
| Phase 1000 Batch 16 | research-strategy.md 四支柱状态同步 | ✅ | 9 处过期标记修复 · 1.2/1.3/2.2/2.4 ⏳→✅ · Sprint 计划→交付总览 (f0d38e2) |
| Phase 1000 Batch 17 | glossary.ts 术语补齐 9 概念 | ✅ | 多层存储 · MMR 重排 · 记忆固化 · 按需展开 · 跨会话连续性 · 模型路由 · 动态重规划 · 记忆引导规划 · 反思闭环 — 15→24 术语 |
| Phase 1000 Batch 18 | q7.4 面板叙事文案补齐 (4 files) | ✅ | CacheStatsPanel 健康评估 · DecayDistributionPanel λ 标签化 · TokenDashboardPanel 成本主导者 · StrategyComparePanel 推荐叙事 |
| Phase 1000 Batch 19 | core_issues.md 四缺失话题补齐 | ✅ | 流式上下文组装 (1.18) · 多Profile记忆隔离 (2.27) · 并行计划执行 (3.17) · Token成本预测 (4.11) — 93→97 问 |
| Phase 1000 Batch 20 | q2.18 记忆可解释性 — recall_reason 全栈 | ✅ | RecallEngine 注入召回理由 · RecallItem schema + recall_reason · OnionPanel RecallItemRow 渲染 |
| Phase 1000 Batch 21 | q2.19 冷启动 — ColdStartProfile 全栈 | ✅ | MemoryStore 计数 · ColdStartProfile schema · ChatResponse 注入 · OnionPanel 横幅 |
| Phase 1000 Batch 22 | 四支柱交叉依赖 viz | ✅ | FourPillar 卡片因果连线 (2-3 files) |
| Phase 1000 Batch 23 | 预存测试修复 | ✅ | content-integrity · chapters · ChatParamsContext — 3 文件 14 行 (1cdfc19) |
| Phase 1000 Batch 24 | 答案全量审计 P0 清零 | ✅ | 8 章 19 处事实性错误修正 — 计划中→已交付 · 远期→已实现 · 删除过期文件引用 (6 files) |
| Phase 1000 Batch 25 | 答案全量审计 P1+P2 收尾 | ✅ | 7 章 15 处：q2.13 重写（三层架构已交付）· q8.6 LLM 调用 8→6 · q8.4 开关 4→10 · Batch 189 伪造修复 · Phase 29×5 命名失效 · ColdStartProfile 已交付标注 · Router 行数更新 |
| Phase 1000 Batch 26 | 🟠 Bug 审计清零 | ✅ | 2 项已修复：Flowchart Zoom (0ade50e iframe+transform) · Drawer 双滚动条 (6096238 body lock) — 仅文档过期，无代码变更 |
| Phase 1000 Batch 27 | P1 治理：文档过期路径 + 日期 header | ✅ | ui-ux-patterns.md 加日期 · architecture.md 3 处 Streamlit 旧路径标注迁移方向 · 34 unused vars 审计纠偏（项目 ESLint 0 真实问题） |
| Phase 1000 Batch 42 | CI 底座 — CI/CD 决策文档 + `make ci` 目标 | ✅ | `docs/ci-cd.md` + Makefile + 3 docs |
| Phase 1000 Batch 43 | 骨架测试加厚 (9→25 tests) | ✅ | 3 文件 16 新增 test |
| Phase 1000 Batch 44 | 双平台 CI 配置 — GitHub Actions + Gitee Go | ✅ | 2 配置文件 |
| Phase 1000 Batch 45-48 | 可观测性 F6-F9 全栈 — traces/logs/compression 面板 | ✅ | 4 API + 3 面板 + dashboard 升级 |
| Phase 1000 Batch 50-54 | U20 知识图谱 3D — R3F→ECharts 迁移 + 视觉升级 | ✅ | 3D 力导向图 + 双主题 + 置信度筛选 |
| Phase 1000 Batch 55 | HMR WebSocket 修复 + Roadmap 同步门禁 | ✅ | 2 提交 |
| **Phase 1000 Batch 56-66** | **Shared Module Governance 治理段 (11 批)** | ✅ | ↓ |
| Batch 56 | check_shared_modules.py 工具 + Makefile 集成 | ✅ | 61 共享模块自动扫描, 三级风险分类 |
| Batch 57 | api/schemas.py Risk Assessment | ✅ | 14 consumers · 5 layers · 84 types |
| Batch 58 | src/config.py Risk Assessment | ✅ | 28 consumers · 5 config layers · 6 findings |
| Batch 59 | src/memory/store.py Risk Assessment | ✅ | 22 consumers · 5 storage layers · 10 findings |
| Batch 60 | Governance 复盘闭环 + L5 拉通 | ✅ | LRN-2026-055/056 · methodology.md 同步 |
| Batch 61 | 发现即待办 — 低成本修复 + backlog 注册 | ✅ | CLAUDE.md 规则 19 · 3 项当场修 |
| Batch 62 | Feature Flag 审计 trail — check_shared_modules.py 增强 | ✅ | 13 flags consumer impact matrix |
| Batch 63 | Settings.__post_init__ 验证 | ✅ | 非法值组合静默拦截 |
| Batch 64 | Master Backlog 治理 — 博物馆→决策工具 | ✅ | 366→93 行 · P0/P1/P2/远期四段 |
| Batch 65 | CLAUDE.md 瘦身 + 文件健康诊断方法论 | ✅ | 190→175 行 · 四文件健康阈值 |
| Batch 66 | 治理段编号审计 + 防呆规则 + embed.py RA | ✅ | 四类编号崩盘诊断 · CLAUDE.md 规则 13a/14 · LRN-2026-057 · embed.py 10 consumers 5 层 RA |
| Batch 67-75 | P1 清零 9 项 — bypass 消除/TypedDict/Schema versioning | ✅ | I-108/I-109/I-101/I-110/I-117/I-112/I-113/I-102/I-103 · 读/写路径类型安全 |
| Batch 76 | 文档同步 — 全量 Batch 编号修正 | ✅ | 7 文件 · 47 处过期引用修复 |
| Batch 77-81 | Settings 嵌套化 5 批 — 16 域 100% 嵌套化 | ✅ | 20 nested dataclass · 38 flat → 16 groups · 1328 tests |
| Batch 82 | check-docs bash monolith → tools/check_docs.py | ✅ | ~160 行 bash → Python script |
| Batch 83 | 视觉回归测试 — check_visual.py prototype | ✅ | 5 路由 × 2 主题 · PIL 像素对比 · 0.5% 阈值 |
| Batch 84 | 工具链自愈 — _browser.py 共享模块 + ThemeToggle fix | ✅ | 70 行去重 · data-theme mount 修复 |
| Batch 85 | check-visual CI 接入 — check-all + GitHub Actions 门禁 | ✅ | I-122 ✅ · 视觉回归 CI 化 |
| Batch 86 | Frontend Data Contract Risk Assessment — 5 模块 | ✅ | types.ts 62C · client.ts 37C · content/types.ts 20C · chatParams.ts 7C · questions.ts 5C |
| Batch 87 | UI Component Library Risk Assessment — 6 模块 | ✅ | DataState 21C · ErrorDisplay 13C · RefreshButton 16C · MermaidDiagram 10C · CollapsibleSection 8C · Drawer 5C · 新「UI 组件」品类落地 |
| Batch 88 | Python 记忆+规划核心 RA — 5 模块 | ✅ | store.py 32C · index.py 21C · embed.py 11C · forget.py · fact.py |
| Batch 89 | Infra/存储+计量+上下文 RA — 5 模块 | ✅ | token_ledger 14C · logging 13C · overflow_sim 9C · ChatParamsCtx 13C · semantic_cache |
| Batch 90 | DI+启动+Context+布局 RA — 6 模块 | ✅ | bootstrap 7C · AppShell 6C · DrawerCtx 7C · IntentPill 4C · TokenCostBadge 5C · ScrollLockCtx |
| Batch 91 | Medium 核心引擎 RA — 5 模块 | ✅ | recall.py 4C · triple.py 4C · reflection 4C · replan 4C · session_boundary |
| Batch 92 | Medium 后端模块 RA — 5 模块 | ✅ | main.py 4C · partition.py 3C · budget.py 3C · tier.py 3C · engine.py 3C |
| Batch 93 | Frontend Lib 工具层 RA — 7 模块 | ✅ | useChat 4C · errorCategories 4C · renderMarkdown 3C · glossary 3C 等 |
| Batch 94 | UI/Chat 组件 RA — 6 模块 | ✅ | ImageViewer 4C · CopyButton 4C · TabBar 4C · ConfirmModal 3C · KVRow 3C · ContextualLens 3C |
| Batch 95 | 前端 Medium 模块 RA + L5 全线清零 — 6 模块 | ✅ | ProcessDrawer 3C · SessionTokenGauge 3C · RA 62/62 全覆盖 |
| Batch 96 | 🔴 结构性风险治理 R1 — 4/12 消除 | ✅ | R1 INTENT_COLORS · R2 overflow_sim API · R3 DrawerContext 竞态 · R4 StepRecord→PlanStepRecord |
| Batch 97 | 上下文效率优化 Tier 1+2 | ✅ | requirements-log 95% 压缩 · check-docs 静默模式 |
| Batch 98 | R5 EngineBundle NamedTuple — 7 元组类型安全 | ✅ | bootstrap.py + dependencies.py + session.py · 5/12 消除 |
| Batch 99 | R9+R10 ScrollLockProvider + MobileSidebarDrawer | ✅ | Drawer 模块级状态消除 · AppShell 移动端解耦 · 7/12 消除 |
| Batch 100 | 文档修复 + RA 补齐 (纯文档 Batch) | ✅ | master-backlog 状态修正 · RA 64/64 全覆盖 · 🟡 P2 全线清零 |
| Batch 101 | R6 ChatParamsContext 三路拆分 | ✅ | 22 字段单 Context → 3 独立 Context · 10/12 消除 |
| **Batch 102** | **R7+R8 FAISS 原子性修复 — 🎉 12/12 清零** | ✅ | _vectors 伴随序列化 + add() 写顺序修正 |
| Batch 103 | make commit target | ✅ | 消除 pre-commit stash 冲突提交流程瓶颈 |
| **Batch 104** | **违纪闭环机制落地** | ✅ | violations.md + check_violations() 硬阻断 · 触发→记录→门禁→闭环 |

**🎉 治理段收官 (B86→B104)**：🔴 结构性风险 12/12 清零 · 🟡 P2 全线清零 · RA 覆盖率 64/64 (100%) · 违纪闭环落地 · commit 流程修根

| **Phase 1000 Batch 107-114** | **Profile 页治理段 (8 批)** | ✅ | ↓ |
| Batch 107 | B88/B89/B90 重分类矫正 + RA 看板闭环 | ✅ | Phase 66→1000 编号治理 |
| Batch 108 | setTimeout(0) 残量消除 + formatBytes DRY 提取 | ✅ | 对标 B89 消除模式 |
| Batch 109 | Obs 域内 DRY + 占位符清理 + 魔数常量化 | ✅ | 3 项代码卫生 |
| Batch 110 | StatBadge 统一 — StatChip+StatPill→共享组件 | ✅ | P10 项闭环 |
| Batch 112 | I-124 TagDetailDrawer formatTime→fmtTimestamp DRY | ✅ | B98 扫描 Quick Win |
| Batch 113 | I-125–I-130 Profile 页治理六项全量闭环 | ✅ | DRY/死代码/内存泄漏 · 7 项两批 |
| Batch 114 | Profile 页治理收尾 (TagPill DRY + setTimeout + TAG_COLORS) | ✅ | P1/P2/P9 三项 · 10 项全线闭环 |
| **Phase 1000 Batch 115-120** | **L5 补拉通 + 门禁收官 (6 批)** | ✅ | ↓ |
| Batch 115 | L5 补拉通 Context/Pipeline Tab (B83/B84/B86/B87) | ✅ | 14/14 状态遍历 · l5-gate.sh 路径修复 |
| Batch 116 | L5 补拉通 Tooltip 即时化 (B98-B106 九批) | ✅ | 35 处即时 tooltip 全页面 |
| Batch 117 | L5 补拉通 Lab Tab 增强 (B91-B94 四批) | ✅ | 14/14 状态遍历 |
| Batch 118 | L5 补拉通 Experiment Tab (B95-B97 三批) | ✅ | 32 tests + ContentDashboard 抽取 |
| Batch 119 | L5 补拉通 Data Tab (B88-B90 三批) | ✅ | 7 组件状态遍历 + 共享 lib DRY 5 线 |
| Batch 120 | 极低复杂度清扫 — 门禁全绿收官 | ✅ | 验证方式补全 · eslint 0w · 日报追记 |

**🎉 Phase 1000 全线闭环**：L5 补拉通五批 (B115-B119) 覆盖 ~30 Batch 延迟检查 · 门禁全绿 (B120) · pre-commit 6 hook 全部恢复 · check-docs 146/146 零阻断

---

## Phase 36 — 旅程一「AI 怎么记住我的」🔵

> 第一条用户探索旅程。从聊天页召回记忆触点出发 → 理解事实抽取原理 → 看到记忆衰减状态 → 学到遗忘策略。横跨 Chat / Learn / Lab / Profile 四个页面，覆盖记忆设计支柱。

### ✅ Phase 36 Batch 1 — 召回记忆教学入口

| # | 任务 | 状态 | 验证方式 |
|---|------|:--:|------|
| 36.1 | ChatMessage 按钮栏新增「记忆 N 条 · 怎么记住的？」ContextualLens（展开 q2.1 mermaid） | ✅ | vitest +4 tests |
| 36.2 | OnionPanel 召回段加 ContextualLens + RecallItemRow 衰减数据展示（强度条/置信度/访问次数/λ） | ✅ | vitest +9 tests |
| 36.3 | q2.6 答案（合理遗忘策略对比，L0-L3 + mermaid） | ✅ | content-integrity 6/93 完成 |
| 36.4 | 全栈门禁 | ✅ | tsc 0 · eslint 0 · vitest 1046/1047 · make check 600/600 · check-docs ✅ · check-theme ✅ |

**涉及文件**：ChatMessage.tsx / OnionPanel.tsx / ch2.ts + 2 test 文件 + 2 联动文件（chapters.ts / content-integrity.test.ts）。

---

### ✅ Phase 36 Batch 2 — MMR 召回答案 + 召回竞赛面板

| # | 任务 | 状态 | 验证方式 |
|---|------|:--:|------|
| 36.5 | q2.14 答案（混合检索策略权衡，L0-L3 + mermaid） | ✅ | content-integrity 7/93 完成 |
| 36.6 | RecallRacePanel — Lab 三条检索路线并排对比面板 | ✅ | vitest +8 tests |
| 36.7 | LabShell context Tab 集成 RecallRacePanel | ✅ | tsc 0 + 手动 |
| 36.8 | 全栈门禁 | ✅ | tsc 0 · eslint 0 · vitest 1054/1055 · make check 600/600 · check-docs ✅ · check-theme ✅ |

**涉及文件**：ch2.ts（q2.14）+ RecallRacePanel.tsx（新建）+ LabShell.tsx + RecallRacePanel.test.tsx（新建）+ chapters.ts + content-integrity.test.ts。

---

### ✅ Phase 36 Batch 3 — 记忆去重与一致性

| # | 任务 | 状态 | 验证方式 |
|---|------|:--:|------|
| 36.9 | q2.8 答案（记忆去重三重防线：语义/结构化/用户反馈，L0-L3 + mermaid） | ✅ | content-integrity 9/93 完成 |
| 36.10 | q2.15 答案（记忆冲突仲裁策略：降权+证据积累+自然裁决，L0-L3 + mermaid） | ✅ | content-integrity 9/93 完成 |
| 36.11 | 全栈门禁 | ✅ | tsc 0 · eslint 0 · vitest 1052/1055 · make check 600/600 · check-docs ✅ |

**涉及文件**：ch2.ts（q2.8 + q2.15）+ chapters.ts（answeredCount 3→5）+ content-integrity.test.ts（stubs 86→84）。

---

### ✅ Phase 36 Batch 4 — 真删 vs 软遗忘

| # | 任务 | 状态 | 验证方式 |
|---|------|:--:|------|
| 36.12 | q2.17 答案（真删 vs 软遗忘决策树，L0-L3 + mermaid） | ✅ | content-integrity 10/93 完成 |
| 36.13 | chapters.ts answeredCount 5→6 | ✅ | vitest content-integrity |
| 36.14 | 全栈门禁 | ✅ | tsc 0 · eslint 0 · vitest 全绿 · make check 600/600 · check-docs ✅ |

**涉及文件**：ch2.ts（q2.17）+ chapters.ts + roadmap.md。

**叙事衔接**：B1 讲了「记忆会忘」（衰减机制），B4 纵深到「忘了之后呢」——软遗忘降权隐藏 vs 真删物理清除，闭合了遗忘故事弧中「被遗忘的记忆去哪了」这一关键环节。

---

### ✅ Phase 36 Batch 5 — 溯源可解释性

| # | 任务 | 状态 | 验证方式 |
|---|------|:--:|------|
| 36.15 | q2.18 答案（溯源可解释性三层模型，L0-L3 + mermaid + 代码引用） | ✅ | content-integrity 11/93 完成 |
| 36.16 | chapters.ts answeredCount 6→7 | ✅ | vitest content-integrity |
| 36.17 | 全栈门禁 | ✅ | tsc 0 · eslint 0 · vitest 全绿 · make check 600/600 · check-docs ✅ |

**涉及文件**：ch2.ts（q2.18）+ chapters.ts + content-integrity.test.ts + roadmap.md + requirements-log.md。

**叙事衔接**：B1-B4 分别覆盖了触点（事实抽取）、衰减（遗忘策略）、检索（MMR 三路线）、质量（去重+冲突）、生死（真删vs软遗忘）——五个维度覆盖了记忆系统的「是什么」。B5 收束到「为什么」——系统能不能解释「为什么召回这条而不是那条」？三层可解释性（分数溯源 → 排除分析 → 来源路线）闭合 Phase 36 六拍故事线。

**Phase 36 六拍全部完成** 🎉：
```
第1拍 ✅ B1 — 触点（recall lens + q2.1 事实抽取）
第2拍 ✅ B1 — 衰减（OnionPanel 衰减数据 + q2.6 遗忘策略）
第3拍 ✅ B2 — 检索（q2.14 MMR 三路线 + Lab RecallRacePanel）
第4拍 ✅ B3 — 质量（q2.8 去重三重防线 + q2.15 冲突仲裁）
第5拍 ✅ B4 — 生死（q2.17 真删 vs 软遗忘）
第6拍 ✅ B5 — 闭环（q2.18 溯源可解释性）
```

---

## Phase 37 — 旅程三「AI 刚才在想什么」（Planner 透明化）🔵

> 入口触点：IntentPill → ProcessDrawer 任务 DAG → ContextualLens → /learn 答案 → /lab 重规划对比 → Sidebar 反思卡片
> 覆盖页面：Chat / Learn / Lab（3 页闭环）
> 新增内容：q3.4/q3.5/q3.9/q3.15/q3.16（5 篇新答案）

### ✅ Phase 37 Batch 1 — 后端地基：包重构 + PlanGenerator

| # | 任务 | 状态 | 验证方式 |
|---|------|:--:|---------|
| 37.1 | **`src/planner.py` → `src/planner/` 包重构** — 提取 `intent.py` (L1 分类器) + `plan.py` (L2 PlanGenerator 骨架) + `__init__.py`。删除原文件，更新所有 imports | ✅ | pytest 33/33 + contract snapshot 40 签名一致 |
| 37.2 | **PlanGenerator 引擎** — LLM 驱动的任务分解，三阶回退解析（JSON→块提取→兜底）。沿袭 PlannerEngine 模式：构造注入 + ledger + prompt 设计 | ✅ | pytest 21 new tests (PlanResult + DAG edges + parse + ledger + error recovery) |
| 37.3 | **`POST /planner/generate-plan` 端点** — PlanGenerateRequest/Response schemas + PlanGenerator 通过 PlannerEngine 组合注入 | ✅ | contract snapshot 新增 PlanGenerator.generate_plan |

**门禁**: `make check` 621/621 · `make check-docs` ✅ · contract 40/40 ✅
**涉及文件**: `src/planner/__init__.py`(新) · `src/planner/intent.py`(新) · `src/planner/plan.py`(新) · 删除 `src/planner.py` · `src/bootstrap.py` · `api/routers/planner.py` · `api/schemas.py` · `api/dependencies.py` · `tests/test_plan_generation.py`(新) · `tools/check_contracts.py`

### ✅ Phase 37 Batch 2 — 聊天触点：ProcessDrawer DAG + ContextualLens

| # | 任务 | 状态 | 验证方式 |
|---|------|:--:|---------|
| 37.4 | **Chat router 注入 plan trace** — 在管线步骤 4 调用 PlanGenerator，将 plan_subtasks/dag_edges/rationale/confidence 注入 api_trace extras。失败不阻塞管线 | ✅ | pytest 621/621 |
| 37.5 | **ProcessDrawer Section 5 "任务规划"** — MermaidDiagram 渲染任务 DAG + KVRow (子任务数/置信度/理由) + plan token 统计。空状态安全（无 plan 数据不渲染） | ✅ | vitest +3 tests (规划区渲染/空数据隐藏/token 统计) |
| 37.6 | **ChatMessage ContextualLens: Plan Decomposition** — 触发标签 "分解为 N 个子任务 · 怎么拆的?"，展开显示实际 DAG 图。仅 api_trace 含 plan 数据时渲染 | ✅ | vitest +2 tests (显示/隐藏) |

**门禁**: `make check` 621/621 · `tsc` 0 · `eslint` 0 · `vitest` 1060/1060 · `check-theme` 5 route 0 · `check-docs` ✅
**涉及文件**: `src/config.py` (+plan_generation_enabled 开关) · `src/planner/plan.py` (修复 disabled 文案) · `api/routers/chat.py` (+步骤 4) · `ProcessDrawer.tsx` (+Section 5 + buildPlanDAGChart) · `ChatMessage.tsx` (+plan ContextualLens) · 测试 2 文件 +5 tests · `tests/test_plan_generation.py` (修正 mock)

### ✅ Phase 37 Batch 3 — q3.4 任务规划手段对比 + q3.5 LLM 任务规划流程

| # | 任务 | 状态 | 验证方式 |
|---|------|:--:|---------|
| 37.7 | **q3.4 答案** — L0-L3 四层：三种路线对比（规则模板/HTN/LLM）+ PlanGenerator 调用链 + 关键设计决策 + 行业实践 | ✅ | tsc 0 · eslint 0 · vitest pass |
| 37.8 | **q3.5 答案** — L0-L3 四层：四步流程（意图理解→分层分解→依赖编排→输出校验）+ prompt 设计 + 三阶回退代码路径 | ✅ | tsc 0 · eslint 0 · vitest pass |

**门禁**: `tsc` 0 · `eslint` 0 · `vitest` pass · `check-theme` 5 route 0
**涉及文件**: `frontend/src/lib/content/answers/ch3.ts` (+~330 行)

### ✅ Phase 37 Batch 4 — ReplanDetector 重规划检测引擎

| # | 任务 | 状态 | 验证方式 |
|---|------|:--:|---------|
| 37.9 | **ReplanDetector 引擎** — `detect_drift()` 意图漂移检测（余弦相似度 + LLM 二次确认）+ `generate_replan()` 修正计划生成 + 三阶回退解析 | ✅ | pytest 638/638 |
| 37.10 | **API 端点** — `POST /planner/detect-replan` + ReplanRequest/ReplanResult Pydantic 模型 | ✅ | pytest 638/638 |

**门禁**: `make check` 638/638 · `ruff` 0 · `mypy` strict · `contract` 40/40 ✅
**涉及文件**: `src/planner/replan.py`(新) · `api/routers/planner.py` · `api/schemas.py` · `tests/test_replan.py`(新)

---

### ✅ Phase 37 Batch 5 — 前端：ReplanComparePanel + q3.9 重规划对比

**目标**：Batch 4 后端 ReplanDetector 已就绪，Batch 5 交付前端 Lab 展示触点——并排对比原始计划 vs 修正计划 + q3.9 理论解释。

| 编号 | 交付 | 状态 | 验证 |
|------|------|:--:|------|
| 37.11 | **ReplanComparePanel 组件** — 自包含 mock 数据，三列布局（原始计划 | 差异摘要 | 修正计划），每列含 mini Mermaid DAG 任务依赖图。模式参照 RecallRacePanel | ✅ | vitest 1083/1083 |
| 37.12 | **ReplanComparePanel 测试** — 23 tests：基础渲染 + 三列布局 + mock 数据完整性 + 差异摘要 + 漂移原因 + 置信度 + 可访问性 | ✅ | vitest 全绿 |
| 37.13 | **LabShell 集成** — +import + JSX，插入 StrategyComparePanel 与 IntentTestPanel 之间（context tab） | ✅ | check-theme 5 route 0 |
| 37.14 | **q3.9 答案** — L0-L3 四层（~3,800 字符）：漂移检测机制 + 三种漂移类型 + ReplanDetector 工程实现 + 三阶回退 + 行业实践 + 开放问题 | ✅ | tsc 0 · eslint 0 · vitest pass |

**门禁**: vitest 1083/1083 (75 files) · tsc 0 · eslint 0 · check-theme 5 route 0 · check-docs ✅
**涉及文件**: `ReplanComparePanel.tsx`(新) · `ReplanComparePanel.test.tsx`(新) · `LabShell.tsx` · `ch3.ts` · `chapters.ts` · `content-integrity.test.ts`

---

### 🔵 Phase 37 Batch 6 — ReflectionEngine 后端引擎

**目标**：交付第 5 个透明化触点的后端地基——规划反思引擎。对标 Batch 4→5 拆分模式，本批纯后端，前端 SidebarReflectionCard + q3.15/q3.16 留给 Batch 7。

| 编号 | 交付 | 状态 | 验证 |
|------|------|:--:|------|
| 37.15 | **ReflectionEngine** — 规划反思引擎，LLM 调用 + 三阶回退解析，沿袭 ReplanDetector 模式 | ✅ | pytest 10/10 |
| 37.16 | **Planner 包接入** — `__init__.py` + `intent.py` setter/委托 + `bootstrap.py` 注入 | ✅ | mypy strict 0 |
| 37.17 | **API 端点** — `POST /planner/reflect` + `ReflectionRequest`/`ReflectionResponse` Pydantic 模型 | ✅ | mypy strict 0 |
| 37.18 | **测试** — `test_reflection.py` 10 tests：dataclass 默认/构造 + JSON/block/garbage/clamp/filter 解析 + 错误恢复 + 禁用标志 | ✅ | pytest 10/10 |

**门禁**: pytest 648/648 · ruff 0 · mypy strict 0 · check-docs ✅
**涉及文件**: `src/planner/reflection.py`(新) · `src/planner/__init__.py` · `src/planner/intent.py` · `src/bootstrap.py` · `api/schemas.py` · `api/routers/planner.py` · `tests/test_reflection.py`(新)

**Batch 7 预告**: ~~前端 SidebarReflectionCard + API client/types + Sidebar 集成 + q3.15/q3.16 内容答案~~ ✅ 已交付

---

### ✅ Phase 37 Batch 7 — 前端：SidebarReflectionCard + q3.15/q3.16

**目标**：交付第 6 个透明化触点——Sidebar 反思卡片 + 两篇深层规划理论答案。对标 Batch 4→5 模式，本批纯前端 + 内容。

| 编号 | 交付 | 状态 | 验证 |
|------|------|:--:|------|
| 37.19 | **SidebarReflectionCard 组件** — 自包含 mock 数据，三状态（idle→reflecting→done），反思文本 + 改进建议列表 + 质量评分进度条 + 置信度 badge | ✅ | vitest 1097/1097 |
| 37.20 | **API client + types** — `ReflectionRequest`/`ReflectionResponse` TypeScript 类型 + `api.reflect()` 方法 | ✅ | tsc 0 |
| 37.21 | **Sidebar 集成** — `<SidebarReflectionCard />` 插入 SessionHarvest 与 L1 统计之间 | ✅ | Sidebar.test.tsx 24/24 |
| 37.22 | **测试** — `SidebarReflectionCard.test.tsx` 15 tests：渲染/状态切换/反思内容/改进建议/评分/重置/可访问性 | ✅ | vitest 15/15 |
| 37.23 | **q3.15 作者模型答案** — L0-L3 四层（~3,200 字符）：四种偏差类型 + 置信度校准 + 保形预测前沿 | ✅ | tsc 0 · content-integrity pass |
| 37.24 | **q3.16 元规划答案** — L0-L3 四层（~3,000 字符）：复杂度阈值函数 + 意图→粒度映射 + 学习型元规划 | ✅ | tsc 0 · content-integrity pass |

**门禁**: vitest 1097/1097 (76 files) · tsc 0 · eslint 0 · check-theme 5 route 0 · check-docs ✅
**涉及文件**: `SidebarReflectionCard.tsx`(新) · `SidebarReflectionCard.test.tsx`(新) · `types-chat.ts` · `types.ts` · `client.ts` · `Sidebar.tsx` · `ch3.ts` · `chapters.ts` · `content-integrity.test.ts`

### ✅ Phase 37 Batch 8 — 收官：L5 拉通自检 + 文档审计 + 方向讨论

| # | 任务 | 状态 | 验证方式 |
|---|------|:--:|---------|
| 37.25 | **L5 拉通自检** — Phase 37 全 Phase 六触点终检（Batch 7 L5 + 全触点状态矩阵）+ 20 项 L1-L5 检查 | ✅ | check-all 全绿 |
| 37.26 | **文档全量审计** — architecture/research-strategy/roadmap/requirements-log/pitfalls/lessons-learned 六文档审计 + stale plan 文件清理 | ✅ | check-docs ✅ |
| 37.27 | **日报闭环** — docs/daily/2026-06-27.md 追加 Batch 8 | ✅ | make check-docs ✅ |

**门禁**: `make check-all` 全绿 · `make check-docs` ✅ · `check-theme` 5 route 0
**涉及文件**: `docs/requirements-log.md` · `docs/roadmap.md` · `docs/daily/2026-06-27.md` · stale plan 清理 ×3

**Phase 37 全 Phase 完成 🎉**：8 Batches · 6 触点 · 3 新 API 端点 · 4 新 Python 引擎 · 3 新前端组件 · 5 篇新答案 · 648 Python + 1097 Frontend tests 全绿

---

## Phase 38 — 旅程三「AI 的每一分钱花在哪」（Token 效率透明化）🔵

> 设计原则：① 遵循 Phase 37 注入模式（chat router → api_trace extras → 前端透传）
> ② 先关缺口再展示（压缩节省、嵌入缓存命中先接入 ledger）
> ③ 实际 > 估计（展示 API 实际 token，不重复 context_meta 估算）
> ④ 答案 + 触点并行，每 2 Batch L5 拉通

### ✅ Phase 38 Batch 1 — 后端地基：Instrumentation Gap Closure + Per-Turn Cost

| # | 子任务 | 状态 | 验证 |
|---|--------|------|------|
| 38.01 | **定价配置化** — `src/config.py` Settings 新增 `llm_input_price_per_1m: 1.0` + `llm_output_price_per_1m: 2.0`（DeepSeek 默认定价） | ✅ | mypy 0 |
| 38.02 | **修复 record_cache_hit** — call_point 参数不再被硬编码覆盖，保留来源组件名（embedding/fact_extraction）便于归因 | ✅ | 6 存量测试更新 + 4 新测试 |
| 38.03 | **压缩节省接入 ledger** — `ChatEngine.compress_message()` 记录压缩 LLM 调用（call_point="compression"）+ 原文 vs 压缩后 token 差量 savings | ✅ | 2 新测试 |
| 38.04 | **嵌入缓存接入 ledger** — `EmbeddingCache.set_ledger()` + `get()` 命中时调用 `ledger.record_cache_hit("embedding", tokens)` | ✅ | test_cache.py 全部通过 |
| 38.05 | **Per-turn token breakdown 注入 api_trace** — `api/routers/chat.py` 组装 `token_breakdown` dict（chat/intent/fact_extraction + pricing），注入 `api_trace["token_breakdown"]` | ✅ | 手动（L3 契约快照 + L5 终检验证） |
| 38.06 | **TokenLedger 新增 record_count + get_range** — 支持按轮次快照/差分，为后续 per-turn 归因前端展示提供数据基础 | ✅ | 4 新测试 |

**门禁**: `make check` 全绿（ruff 0 · mypy strict 0 · pytest 657/657）
**涉及文件**: `src/config.py` · `src/token_ledger.py` · `src/cache.py` · `src/chat/engine.py` · `api/routers/chat.py` · `tests/test_token_ledger.py` · `tests/test_engine.py` · `tests/test_fact_extraction.py`

### ✅ Phase 38 Batch 2 — 聊天触点：ChatMessage Token Cost Badge

| # | 子任务 | 状态 | 验证 |
|---|--------|------|------|
| 38.07 | **TokenCostBadge 组件** — 从 `api_trace.token_breakdown` 聚合 chat/intent/fact_extraction 三调用点 token，按定价折算成本，以内联 pill 展示（≈¥{cost} · {tokens} token） | ✅ | vitest 15 tests |
| 38.08 | **ChatMessage 集成** — 助理消息按钮栏注入 TokenCostBadge（token 透镜左侧），无 breakdown 时静默不渲染 | ✅ | vitest 4 integration tests |

**门禁**: tsc 0 · eslint 0 · vitest 1116/1116 (+19)
**涉及文件**: `TokenCostBadge.tsx` (new) · `TokenCostBadge.test.tsx` (new) · `ChatMessage.tsx` (edit) · `ChatMessage.test.tsx` (edit)

### ✅ Phase 38 Batch 3 — 内容：q4.2 + q4.5（P0 答案）

| # | 子任务 | 状态 | 验证 |
|---|--------|------|------|
| 38.09 | **q4.2 答案** —「如何高效而不失质量节省 token 使用」五层金字塔 (L0-L3)，含缓存复用/消息压缩/溢出策略/Prompt 精简/模型路由 + mermaid 决策流程图 | ✅ | tsc 0 · eslint 0 |
| 38.10 | **q4.5 答案** —「Token 消耗归因粒度」三级跳 (L0-L3)，含 TokenLedger call_point 体系/per-turn breakdown/TokenCostBadge 落地 + mermaid 粒度流程图 | ✅ | tsc 0 · eslint 0 |
| 38.11 | **章节元数据更新** — ch4 answeredCount: 1→3 | ✅ | vitest content-integrity 全绿 |
| 38.12 | **测试断言同步** — placeholder 计数 76→75 | ✅ | vitest 1116/1116 |

**门禁**: tsc 0 · eslint 0 · vitest 1116/1116
**涉及文件**: `ch4.ts` (edit, +~500 行 L0-L3 内容) · `chapters.ts` (edit, 1 行) · `content-integrity.test.ts` (edit, 1 行)

### ✅ Phase 38 Batch 4 — L5 拉通（Batch 1-3）

**交付物**：三层端到端全链路走查（后端注入→前端触点→内容答案），零新代码。

**L5 拉通验证矩阵**：

| 验证层 | 检查点 | 结果 |
|-------|--------|:--:|
| 后端注入 (B1) | `api/routers/chat.py` L93-116 — token_breakdown 组装 chat/intent/fact_extraction + pricing → api_trace | ✅ |
| 前端类型 (B2) | `TokenBreakdown` interface 与后端 dict 字段 1:1 对齐（chat/intent/fact_extraction/pricing + 子字段） | ✅ |
| 前端集成 (B2) | `ChatMessage.tsx` L57 解包 `traceExtras["token_breakdown"]` → L137-140 注入按钮栏，有 guard 空时不渲染 | ✅ |
| 内容答案 (B3) | `ch4.ts` 682 行 q4.2（五层金字塔）+ q4.5（三级跳归因）+ mermaid 决策流程图 | ✅ |
| 定价配置 (B1) | `src/config.py` llm_input_price=1.0 / llm_output_price=2.0（DeepSeek 默认） | ✅ |
| 测试 TokenCostBadge | 15/15 vitest 全绿 | ✅ |
| 测试 ChatMessage 集成 | 35/35 vitest 全绿 | ✅ |
| 全栈门禁 | Python 657/657 · tsc 0 · eslint 0 · check-docs ✅ · contracts 40/40 | ✅ |

**门禁**: tsc 0 · eslint 0 · vitest 1115/1116 (1 预存失败 ProjectMapDrawer mermaid 计数标签，Phase 38 零接触) · `make check` 657/657 · `make check-docs` ✅ · `make check-contracts` 40/40

**涉及文件**: 零代码变更 · `docs/roadmap.md` (edit) · `docs/requirements-log.md` (edit) · memory (edit)

**L5 结论**：三层打通，零断层。`token_breakdown` 从 Python dict → JSON → TypeScript interface 全链路字段一致，ChatMessage 正确解包并渲染 TokenCostBadge，内容答案覆盖归因原理和节省策略。

### ✅ Phase 38 Batch 5 — 内容：q4.3 + q4.6（P1 答案 · GLM-5.2 评估实物）

| # | 子任务 | 状态 | 验证 |
|---|--------|------|------|
| 38.13 | **q4.3 答案** —「Token 预算四区动态分配」L0-L3 + 四区 pyramid mermaid，对标 `partition.py` 真实四区（system/recalled/history/tools）+ `compute_partitions()` 减法推导 | ✅ | content-integrity + 手动对标 partition.py |
| 38.14 | **q4.6 答案** —「缓存命中率 vs 节省量化」L0-L3 + 命中率×节省幅度 mermaid，揭露 `record_cache_hit` 把节省存进 `prompt_tokens`、`summary()` 不分离节省、未命中无计数三大真相 | ✅ | 手动对标 token_ledger.py |
| 38.15 | **章节元数据** — ch4 answeredCount: 3→5 · stub 阈值 75→73 · 置信度 q4.3 0.9→0.85 / q4.6 0.89→0.84（= min(l0-l3)） | ✅ | content-integrity 15/15 |

**门禁**: `make check` 657/657 · tsc 0 · eslint 0 · vitest 1116/1116 · content-integrity 15/15
**涉及文件**: `ch4.ts` (edit) · `chapters.ts` (edit) · `content-integrity.test.ts` (edit)

### ✅ Phase 38 Batch 6 — Sidebar 触点：SessionTokenGauge（会话级 Token 油表）

| # | 子任务 | 状态 | 验证 |
|---|--------|------|------|
| 38.16 | **SessionTokenGauge 组件** — 油表隐喻圆环 gauge（session 总 token / 100k 预算，绿<60%→黄60-85%→红>85%），KV 行：输入/输出/估算金额/avg per turn；空态静默占位 | ✅ | vitest 18 tests |
| 38.17 | **aggregateBreakdowns 纯函数** — 跨多轮 `token_breakdown` 聚合会话累计（chat/intent/fact_extraction 累加，pricing 取最新，turns 仅计非零轮） | ✅ | vitest 8 函数测试 |
| 38.18 | **数据通路** — ChatPanel `useMemo` reduce assistant 消息 token_breakdown → `useEffect` `setSessionTokens` 推入 `ChatParamsContext`（镜像 `setMemoryCount` 范式，无累加器，清空聊天自然归零） | ✅ | live-chat E2E |
| 38.19 | **Sidebar 挂载** — SessionHarvest 下方独立卡片；`SessionStats` 加 `sessionTokens{input,output,turns,cost}` 字段 | ✅ | check-theme 5 路由 0 error |

**关键勘误**：原 plan 指定数据源 `api.getTokens()`（GET /metrics/tokens）经源码核对为**进程级累计**（非会话级），改用前端聚合各轮 `token_breakdown`（Batch 1 已注入的真实逐轮数据），零后端改动，符合 Phase 38 原则 ③（实际 > 估计）。

**门禁**: tsc 0 · eslint 0 · vitest 1133/1134（+18；1 预存失败 ProjectMapDrawer mermaid 计数标签，Phase 38 零接触）· `make check-theme` 5 路由 0 console error · live-chat E2E（发消息→仪表空→success，total 465 token / turns 1 / ≈¥0.0006）
**涉及文件**: `SessionTokenGauge.tsx` (new) · `SessionTokenGauge.test.tsx` (new) · `chatParams.ts` (edit) · `ChatParamsContext.tsx` (edit) · `ChatPanel.tsx` (edit) · `Sidebar.tsx` (edit) · `TokenCostBadge.tsx` (edit, export formatCost)

### ✅ Phase 38 Batch 7 — 内容：q4.7 + q4.8（模型 tokenizer 差异 + Token 浪费自动检测）

| # | 子任务 | 状态 | 验证 |
|---|--------|------|------|
| 38.20 | **q4.7 答案** —「Token 估算的模型差异」L0-L3 + mermaid 差异决策图，对标 `_estimate_tokens()`（无 model 参数，单一真相源）+ 调用前/后/跨模型三场景 + 跨预算挪用坑 | ✅ | content-integrity + 手动对标 overflow_sim.py |
| 38.21 | **q4.8 答案** —「Token 浪费模式自动检测」L0-L3 + mermaid 两类三层图，揭露 `wasted_tokens` 量的是结构性浪费（丢+空）非语义浪费（塞了没用）+ 检测三层模型 + 价值 proxy 难题 | ✅ | content-integrity + 手动对标 overflow_sim.py/partition.py |
| 38.22 | **章节元数据** — ch4 answeredCount 5→7 · stub 阈值 73→71 | ✅ | content-integrity 15/15 |

**门禁**: `make check` 657/657 · tsc 0 · eslint 0 · vitest 1134/1134 · content-integrity 15/15 · check-docs ✅
**涉及文件**: `ch4.ts` (edit) · `chapters.ts` (edit) · `content-integrity.test.ts` (edit)

### ✅ Phase 38 Batch 8 — 内容：q4.4（跨模型成本优化）

| # | 子任务 | 状态 | 验证 |
|---|--------|:----:|------|
| 38.23 | **q4.4 答案** —「跨模型成本优化」L0-L3 + mermaid 路由决策图，对标 `available_models` 配置双模型无路由实现的现状 + Cost-per-Quality-Unit 量化框架 + Model Router 四组件（分类器/策略/分发器/记录器）+ FrugalGPT/RouterBench 前沿 | ✅ | content-integrity + 手动对标 config.py |
| 38.24 | **章节元数据** — ch4 answeredCount 7→8 · stub 阈值 71→70 | ✅ | content-integrity 15/15 |

**门禁**: tsc 0 · eslint 0 · vitest content-integrity 15/15 · check-docs ✅
**涉及文件**: `ch4.ts` (edit) · `chapters.ts` (edit) · `content-integrity.test.ts` (edit)

### ✅ Phase 38 Batch 9 — 内容：q4.9（Token 与延迟的权衡）

| # | 子任务 | 状态 | 验证 |
|---|--------|:----:|------|
| 38.25 | **q4.9 答案** —「Token 与延迟的权衡」L0-L3，对标 `compress_message()` 的隐式阈值和 token savings 记账 + 完整成本公式 net_savings = gross_savings - compression_cost + 三场景试算 + 动态压缩决策 + 压缩后悔困境 | ✅ | content-integrity + 手动对标 engine.py |
| 38.26 | **章节元数据** — ch4 answeredCount 8→9 · stub 阈值 70→69 | ✅ | content-integrity 15/15 |

**门禁**: tsc 0 · eslint 0 · vitest content-integrity 15/15 · check-docs ✅
**涉及文件**: `ch4.ts` (edit) · `chapters.ts` (edit) · `content-integrity.test.ts` (edit)

### ✅ Phase 38 Batch 10 — 内容：q4.10（输出 Token 后悔成本与早期检测）

| # | 子任务 | 状态 | 验证 |
|---|--------|:----:|------|
| 38.27 | **q4.10 答案** —「输出 token 的后悔成本」L0-L3，跑题 token 的沉没成本分析 + 五种早期检测路线（级联生成/流分类器/Logit 监测/自一致性/压缩验证）+ 闭源 API 的固有限制 + GlassCortex 远期路径（事后量化→级联→可逆生成） | ✅ | content-integrity 16/16 |
| 38.28 | **章节元数据** — ch4 answeredCount 9→10 · stub 阈值 69→68 | ✅ | content-integrity 16/16 |

**门禁**: tsc 0 · eslint 0 · vitest content-integrity 16/16 · check-docs ✅
**涉及文件**: `ch4.ts` (edit) · `chapters.ts` (edit) · `content-integrity.test.ts` (edit)

---

## Phase 39 — 旅程五「四层怎么配合」（层间交互透明化）🟣

> **叙事**：ch1-4 四大支柱全部讲完，读者自然追问——四层住在同一个大脑里怎么配合？ch5 是过渡章，把四根柱子绑在一起。

### ✅ Phase 39 Batch 1 — 内容：q5.5 + q5.1（层间数据结构 + 召回质量感知）

**叙事**：先说"传什么"，再说"传错了能发现吗"。

| # | 子任务 | 状态 | 验证 |
|---|--------|:----:|------|
| 39.1 | **q5.5 答案** —「层间通信的数据结构」L0-L3，三种结构类别（内部 dict / 层间元数据 / 边界 Pydantic）+ dict 运输的利弊 + 三数据结构的规格对比 + TokenLedger 的跨层审计角色 + Google Pathways / LangChain Runnable 对标 | ✅ | content-integrity + 手动对标 schemas.py / overflow_sim.py / recall.py / partition.py / token_ledger.py |
| 39.2 | **q5.1 答案** —「召回错了上下文层能感知吗」L0-L3，容量感知（溢出）vs 质量感知（缺失/噪音/事实错误）的区分 + OverflowSimResult / RegretAnalysis 的信号覆盖对比 + 三个感知层次 + 静默失败场景 + 层间反馈通路的缺失 | ✅ | content-integrity + 手动对标 recall.py / engine.py / overflow_sim.py / chat.py |
| 39.3 | **章节元数据** — ch5 answeredCount 0→2 · stub 阈值 68→66 | ✅ | content-integrity 15/15 |

**门禁**: tsc 0 · eslint 0 · vitest content-integrity 15/15 · check-docs ✅
**涉及文件**: `ch5.ts` (写) · `chapters.ts` (edit) · `content-integrity.test.ts` (edit)

### ✅ Phase 39 Batch 2 — 内容：q5.3 + q5.4（Token 预算分配 + 错误传播与熔断）

**叙事**：定了通信协议后，问"资源谁决策"和"坏了怎么办"。

| # | 子任务 | 状态 | 验证 |
|---|--------|:----:|------|
| 39.4 | **q5.3 答案** —「Token 预算谁决策」L0-L3，无集中分配器的现状（先到先得+溢出清理）+ 四层隐式竞争 + TokenLedger 只记账不决策 + 三个组件（预申报/优先级协商/利用率反馈）改进路径 + 配置级各层独立配额方案 | ✅ | content-integrity + 手动对标 config.py / partition.py / token_ledger.py / overflow_sim.py |
| 39.5 | **q5.4 答案** —「错误传播与熔断」L0-L3，层级弹性模式（非阻塞 vs 硬阻断 vs 静默回退）+ 四场景逐层分析 + 无熔断器的深度缺失 + 三个缺口（跨层计数/熔断阈值/级联降级）+ 错误/异常/退化的三分 | ✅ | content-integrity + 手动对标 chat.py / engine.py / main.py / schemas.py |
| 39.6 | **章节元数据** — ch5 answeredCount 2→4 · stub 阈值 66→64 | ✅ | content-integrity 15/15 |

**门禁**: tsc 0 · eslint 0 · vitest content-integrity 15/15 · check-docs ✅
**涉及文件**: `ch5.ts` (edit) · `chapters.ts` (edit) · `content-integrity.test.ts` (edit)

### ✅ Phase 39 Batch 3 — 内容：q5.2 + q5.6（子对话记忆管理 + 全链路追踪统一视图）

**叙事**：解决了谁决策/谁负责后，问记忆归属问题（子任务的记忆属于谁），最后问如何统一看到所有层的事件轨迹。

| # | 子任务 | 状态 | 验证 |
|---|--------|:----:|------|
| 39.7 | **q5.2 答案** —「子对话的记忆怎么管理」L0-L3，episode 平坦存储无 parent_id + Planner subtask 记忆不跟踪 + 三层归属（无归属/隐式session_id/显式parent_id）+ 分层召回策略 + 三步演进路径 | ✅ | content-integrity + 手动对标 store.py / schemas.py / planner.py |
| 39.8 | **q5.6 答案** —「全链路追踪统一视图」L0-L3，四个独立记录系统的对比 + 统一 TraceEvent 格式设计 + trace_id 串联 + 时间线渲染概念 + 短期/中期/长期演进路径 + OTel 对标 | ✅ | content-integrity + 手动对标 pipeline_trace / ApiTrace / TokenLedger / ContextPartitions |
| 39.9 | **章节元数据** — ch5 answeredCount 4→6 · stub 阈值 64→62 | ✅ | content-integrity 15/15 |

**门禁**: tsc 0 · eslint 0 · vitest content-integrity 15/15 · check-docs ✅
**涉及文件**: `ch5.ts` (edit) · `chapters.ts` (edit) · `content-integrity.test.ts` (edit)

---

## Phase 40 — 孵化器与内容管线优化 🟢

> **范围**：Lab 实验台增量面板 + 内容加载管线并行化 + 预加载。
> **当前 Batch：2**（全部完成 ✅）

### ✅ Phase 40 Batch 1 — 溢出策略沙箱 + 内容管线并行

| # | 子任务 | 状态 | 验证 |
|---|--------|:----:|------|
| 40.1 | **OverflowSandboxPanel** — 溢出策略对比沙箱，4 组预设 + 3 策略逐条对比矩阵 + 窗口大小/用户输入调节 | ✅ | vitest 12/12 (OverflowSandboxPanel.test.tsx) |
| 40.2 | **内容管线并行** — `questions.ts` 添加 `loadChapter()` / `loadAllChaptersParallel()` 异步 API，`learn/page.tsx` 改为 async server component 通过 Promise.all 并行加载全部 8 章答案 | ✅ | vitest 1146/1146 · tsc 0 · eslint 0 |
| 40.3 | **文档闭环** — roadmap + requirements-log 更新 | ✅ | check-docs ✅ |

**门禁**: vitest 1146/1146 · tsc 0 · eslint 0 · check-docs ✅
**涉及文件**: `OverflowSandboxPanel.tsx` (new) · `OverflowSandboxPanel.test.tsx` (new) · `LabShell.tsx` (edit) · `questions.ts` (edit) · `learn/page.tsx` (rewrite) · `_components/LearnClientShell.tsx` (new) · `LearnPage.test.tsx` (edit)

### ✅ Phase 40 Batch 2 — 内容预加载

> **目标**：利用聊天页空闲时间预加载章节内容，让 `/learn` 导航秒开。

| # | 子任务 | 状态 | 验证 |
|---|--------|:----:|------|
| 40.4 | **模块级缓存** — `loadAllChaptersParallel()` 新增 `_chapterCache` Map，只加载未缓存章节，后续调用瞬时返回 | ✅ | vitest cache 命中行为 |
| 40.5 | **ContentPreloader** — 无视觉 client component：`requestIdleCallback` / `setTimeout 200ms` fallback 空闲时调用 `loadAllChaptersParallel()`，失败静默 | ✅ | vitest 4/4 (渲染/rIC/fallback/静默失败) |
| 40.6 | **ChatPanel 集成** — 挂载 `<ContentPreloader />` 在聊天页顶部 | ✅ | vitest ChatPanel 无回归 |
| 40.7 | **文档闭环** — roadmap + requirements-log + daily + memory 更新 | ✅ | check-docs ✅ |

**门禁**: vitest 1150/1150 · tsc 0 · eslint 0 · check-docs ✅
**涉及文件**: `questions.ts` (edit) · `ContentPreloader.tsx` (new) · `ChatPanel.tsx` (edit) · `ContentPreloader.test.tsx` (new)

---

## Phase 41 — 内容导航体验 🟢

> **范围**：Learn 页导航体验提升 — 内容地图、阅读位置记忆、推荐路径。
> **当前 Batch：8**。

### ✅ Phase 41 Batch 1 — Learn 页内容地图

| # | 子任务 | 状态 | 验证 |
|---|--------|:----:|------|
| 41.1 | **WelcomeView → 内容仪表盘** — 空态升级为内容进度面板：总进度 31/93 进度条 + 每章进度条 (answeredCount/questionCount) + 推荐阅读提示 | ✅ | vitest 1146/1146 |
| 41.2 | **侧栏章节进度条** — QuestionList 每章头部显示 `answeredCount/questionCount` + 颜色进度条（全部完成绿色/部分完成 brand色/零完成灰色） | ✅ | vitest QuestionList 11/11 |
| 41.3 | **硬编码消除** — `"8 章 93 问"` 替换为动态 `{chapters.length} 章 {totalQuestions} 问` | ✅ | vitest + tsc |
| 41.4 | **全栈门禁** | ✅ | vitest 1146/1146 · tsc 0 · eslint 0 · check-docs ✅ · check-theme 5 route 0 error |

**门禁**: vitest 1146/1146 · tsc 0 · eslint 0 · check-docs ✅ · check-theme ✅
**涉及文件**: `LearnClientShell.tsx` (edit) · `QuestionList.tsx` (edit) · `LearnPage.test.tsx` (edit) · `QuestionList.test.tsx` (edit)

### ✅ Phase 41 Batch 2 — 阅读位置记忆 + 推荐路径升级

| # | 子任务 | 状态 | 验证 |
|---|--------|:----:|------|
| 41.5 | **`useLocalStorage` SSR-safe hook** — `useLocalStorage<T>(key, defaultValue)` 泛型 hook，`try/catch` 兜底 | ✅ | vitest useLocalStorage 7/7 |
| 41.6 | **阅读位置持久化** — LearnClientShell `selectedId` 读写 localStorage `gm-learn-last-read`，刷新后自动恢复到上次阅读位置；无效 ID 回退到默认 | ✅ | vitest LearnPage 18/18（+3 阅读位置测试） |
| 41.7 | **侧栏 + 折叠状态持久化** — `sidebarOpen` 持久化到 `gm-learn-sidebar`；章节折叠状态持久化到 `gm-learn-collapsed`，QuestionList 受控折叠 props | ✅ | tsc 0 · eslint 0 |
| 41.8 | **推荐路径升级** — ContentDashboard 优先推荐"继续阅读"（上次阅读位置的下一篇未读内容），无记录时回退到最佳完成率章节 | ✅ | tsc 0 · eslint 0 |
| 41.9 | **全栈门禁** | ✅ | vitest 1160/1160 · tsc 0 · eslint 0 · check-docs ✅ |

**门禁**: vitest 1160/1160 · tsc 0 · eslint 0 · check-docs ✅
**涉及文件**: `useLocalStorage.ts` (new) · `constants.ts` (edit) · `LearnClientShell.tsx` (edit) · `QuestionList.tsx` (edit) · `useLocalStorage.test.tsx` (new) · `LearnPage.test.tsx` (edit)

### ✅ Phase 41 Batch 3 — 修复合集 + 仪表盘产品化

| # | 子任务 | 状态 | 验证 |
|---|--------|:----:|------|
| 41.10 | **SSR hydration 修复** — `useLocalStorage` 改为首帧返回 defaultValue，useEffect 后同步，消除 hydration mismatch | ✅ | dev log 0 hydration error |
| 41.11 | **章节折叠互斥修复** — `toggleChapter` useCallback 闭包陷阱，`[]` deps 捕获首帧空 collapsedProp → 每次 toggle 从空集开始 | ✅ | eslint 0 |
| 41.12 | **AnswerCard root 竞态修复** — `createRoot` 重复调用（queueMicrotask 延迟卸载 vs 新 effect 立即创建）→ `Map<container, root>` 复用 | ✅ | dev log 0 unmount warning |
| 41.13 | **showDashboard 标记** — 返回仪表盘不擦除 localStorage 阅读位置，避免 `handleBack → setStoredId(null)` 丢失历史 | ✅ | vitest LearnPage 18/18 |
| 41.14 | **Toolbar 图标产品化** — `RiHomeLine`→`RiBarChart2Line`, hover「返回仪表盘」→「学习进度」 | ✅ | tsc 0 · eslint 0 |
| 41.15 | **仪表盘视觉重构** — SVG 环形进度图 + 章节卡片行（各章 emoji + `h-2` 进度条）+ 推荐卡品牌色 `bg-brand/5` + 箭头常显 | ✅ | vitest 1160/1160 |
| 41.16 | **页面布局大气化** — 内容区 `max-w-3xl`→`max-w-5xl`，AnswerCard 阅读区收窄 `max-w-3xl`，`gap-gm-5` 统一垂直节奏 | ✅ | check-theme 5 route 0 error |
| 41.17 | **全栈门禁** | ✅ | vitest 1160/1160 · tsc 0 · eslint 0 · check-docs ✅ · check-theme ✅ |

**门禁**: vitest 1160/1160 · tsc 0 · eslint 0 · check-docs ✅ · check-theme ✅
**涉及文件**: `useLocalStorage.ts` (edit) · `LearnClientShell.tsx` (edit) · `QuestionList.tsx` (edit) · `AnswerCard.tsx` (edit) · `useLocalStorage.test.tsx` (edit) · `LearnPage.test.tsx` (edit)

### ✅ Phase 41 Batch 4 — URL 路由化（Deep Linking）

| # | 子任务 | 状态 | 验证 |
|---|--------|:----:|------|
| 41.18 | **LearnPage searchParams** — page.tsx 接收 `searchParams.q`，Suspense 包裹 LearnClientShell | ✅ | tsc 0 |
| 41.19 | **LearnClientShell URL 路由** — `useSearchParams` + `useRouter` 替代 `overrideId` + `showDashboard` useState，URL `?q=` 为真相源 | ✅ | tsc 0 · eslint 0 |
| 41.20 | **优先级链重构** — `urlId (URL) > storedId (localStorage) > defaultId (首答)`，`sidebarSelectedId` 与 `selectedAnswer` 分离 | ✅ | vitest URL 路由测试 |
| 41.21 | **导航同步 URL** — `handleSelect`/`handlePrev`/`handleNext` 触发 `router.replace` 更新 `?q=` 参数 | ✅ | vitest 导航测试 |
| 41.22 | **回仪表盘清除 URL** — `goToDashboard` 通过 `router.replace(pathname)` 清除 `?q=` | ✅ | vitest 仪表盘测试 |
| 41.23 | **浏览器前进/后退支持** — `useSearchParams` 自动响应 URL 变化，组件按 URL 重新渲染 | ✅ | vitest URL 参数测试 |
| 41.24 | **全栈门禁** | ✅ | vitest 1163/1163 · tsc 0 · eslint 0 · check-docs ✅ |

**门禁**: vitest 1163/1163 · tsc 0 · eslint 0 · check-docs ✅
**涉及文件**: `page.tsx` (edit) · `LearnClientShell.tsx` (edit) · `LearnPage.test.tsx` (edit) · `docs/roadmap.md` (edit)

---

### ✅ Phase 41 Batch 5 — 仪表盘交互增强

> **范围**：ContentDashboard 移动端适配 + 章节卡片可点击跳转。两者同属仪表盘交互域。

| # | 子任务 | 状态 | 验证 |
|---|--------|:----:|------|
| 41.25 | **移动端 Dashboard** — 小屏 `lg:hidden` 分支 `<QuestionList>` → `<ContentDashboard>`，原 QuestionList 保留为返回目标 | ✅ | vitest 1167/1167 |
| 41.26 | **章节卡片可点击** — ContentDashboard 每章 `div` → `button`，`onClick` 跳转到该章首题（优先未答），复用已有 `onNavigate` | ✅ | vitest 3 新测试（导航/全答/空）|

**门禁**: tsc 0 · eslint 0 · vitest 1167/1167
**涉及文件**: `LearnClientShell.tsx` (edit) · `LearnPage.test.tsx` (edit)

### ✅ Phase 41 Batch 6 — 搜索过滤 + 阅读历史

> **范围**：QuestionList 浏览体验增强 — 过滤器 + 最近阅读轨迹。

| # | 子任务 | 描述 | 文件量 | 类型 | 状态 |
|---|--------|------|:------:|:----:|:----:|
| 41.27 | **搜索过滤按钮** | 搜索框下方加 filter chips（已答/未答/P0-P3）+ 与现有搜索组成 AND 逻辑 | 1 (QuestionList) | 功能 | ✅ |
| 41.28 | **阅读历史** | `gm-learn-visit-history` 滑动窗口 5 条，`handleSelect` 追加，侧栏底部渲染最近阅读列表 | 2 (LearnClientShell + QuestionList) | 功能 | ✅ |

**门禁**: tsc 0 · eslint 0 · vitest 1180/1180
**涉及文件**: `constants.ts` (edit) · `QuestionList.tsx` (edit) · `LearnClientShell.tsx` (edit) · `QuestionList.test.tsx` (edit · 11 新测试) · `LearnPage.test.tsx` (edit · 2 新测试)

### ✅ Phase 41 Batch 7 — 收藏/书签

> **范围**：星标问题 + 按收藏过滤。

| # | 子任务 | 描述 | 文件量 | 状态 |
|---|--------|------|:------:|:----:|
| 41.29 | **书签持久化** | `useLocalStorage<string[]>` key `gm-learn-bookmarks`，`AnswerCard` 星标 toggle 按钮 | 4 (AnswerCard + LearnClientShell + constants + test) | ✅ |
| 41.30 | **书签过滤** | QuestionList filter 加"只看收藏"选项，书签为空时隐藏 | 2 (QuestionList + test) | ✅ |

**影响**: `constants.ts` (edit) · `AnswerCard.tsx` (edit) · `QuestionList.tsx` (edit) · `LearnClientShell.tsx` (edit) · `AnswerCard.test.tsx` (edit) · `QuestionList.test.tsx` (edit)
**验证**: tsc 0 · eslint 0 · vitest 1191/1191 (11 新 tests)

### ✅ Phase 41 Batch 8 — 搜索增强：全文搜索

> **范围**：搜索范围从问题标题扩展到 `l0/l1/l2/l3` 答案正文，引入 Fuse.js 模糊匹配 + 匹配内容摘要 + 关键词高亮。

| # | 子任务 | 描述 | 文件量 | 类型 | 验证 |
|---|--------|------|:------:|:----:|:----:|
| 41.31 | **全文搜索工具** | Fuse.js 搜索索引，覆盖 `question`/`l0`/`l1`/`l2`/`l3`，按字段加权 | 2 (search.ts + install) | 功能 | ✅ vitest 23/23 |
| 41.32 | **搜索结果聚合视图** | 分章分组渲染 + 匹配字段标签 + 摘要 + `<mark>` 高亮 | 2 (QuestionList + test) | 功能 | ✅ vitest 32/32 |

**验证**：
| 层级 | 检查项 | 结果 |
|------|--------|:----:|
| L1 语法 | tsc 0 · eslint 0 · vitest 1218/1218 (82 files) | ✅ |
| L2 组件测试 | 4 新测试（L0/L1/AND/field label），全绿 | ✅ |
| L3 契约兼容性 | QuestionListProps 无变更 · search.ts 为新增模块，无上游依赖 | ✅ |
| L4 浏览器运行时 | 纯 JS 逻辑 + Fuse.js 库，无 DOM 副作用 | N/A |


---

### ✅ Phase 41 残留项 — 已全部排入 Batches 5-8

> 原 6 项已全部纳入 Phase 41 Batch 5-8 计划，见上方各 Batch 详情。**该项下不再保留未排期项**。

---

## Phase 42 — Ch1 内容 Pilot + 答案质量基线 🟢

**目标**：逐题填充 Ch1（上下文工程）17 问的 L0-L4 答案内容，以 P0/P1 优先。

### ✅ Phase 42 Batch 1 — Ch1 内容 Pilot（q1.2 + q1.3）

**需求**：42.1 q1.2「输出超出窗口」L0-L3 + mermaid · 42.2 q1.3「重复信息三层去重」L0-L3 + mermaid
**验证**：q1.2 和 q1.3 答案完整（含 mermaid 流程图），vitest 1223/1223 · tsc 0 · eslint 0
**影响范围**：`ch1.ts` (edit) · `chapters.ts` (edit)

### ✅ Phase 42 Batch 2 — ChatMessage 窗口分区透镜

**需求**：42.3 ChatMessage 助理消息新增「{usage_pct}% 窗口 · 怎么分的？」ContextualLens 显示分区图 · 42.4 OnionPanel L3 新增「📐 窗口分区怎么分的？」ContextualLens · 42.5 `buildPartitionChart()` 工具函数
**验证**：5 新测试 · vitest 1223/1223 · tsc 0 · eslint 0 · check-theme 5 route 0
**影响范围**：`ChatMessage.tsx` (edit) · `OnionPanel.tsx` (edit) · `ChatMessage.test.tsx` (edit)
**commit**: `717622a`

### ✅ Phase 42 Batch 3 — q1.4 噪声信息内容 + context_meta 守卫

**需求**：q1.4「噪声信息」L0-L3 + mermaid · 🔧 ChatMessage context_meta 空值守卫（修复 mock 测试崩溃）
**验证**：vitest 1223/1223 · tsc 0 · eslint 0
**影响范围**：`ch1.ts` (edit) · `ChatMessage.tsx` (edit) · `content-integrity.test.ts` (edit) · `chapters.ts` (edit)
**commit**: `41f8f0f`

### ✅ Phase 42 Batch 4 — q1.5 不一致信息内容

**需求**：q1.5「不一致信息处理」L0-L3 + mermaid 流程图
**内容**：三源分类（用户改变主意/召回冲突/系统指令隐含冲突）→ 三步法（冲突检测/裁决优先级/显式标记）→ 工程实现（时间戳链/置信度加权/语义矛盾检测）→ 与去重(q1.3)/噪声(q1.4)边界辨析
**验证**：vitest 1223/1223 · tsc 0 · eslint 0
**影响范围**：`ch1.ts` (edit) · `chapters.ts` (edit) · `content-integrity.test.ts` (auto)

### ✅ Phase 42 Batch 5 — q1.8 上下文组装策略

**需求**：q1.8「上下文组装策略：给定一个 token 预算，如何决定塞什么、按什么顺序塞？」L0-L3 + mermaid 流程图
**内容**：四步决策（算预算→分四区→按优先级填→定顺序）+ Lost-in-the-Middle 排列策略 + `_build_system_prompt()` 管线 + 固定 vs 动态配额讨论
**验证**：vitest 1223+ content-integrity ✅ · tsc 0 · eslint 0
**影响范围**：`ch1.ts` (edit) · `chapters.ts` (edit) · `content-integrity.test.ts` (auto)

### ⏳ Ch1 待填充下一题（Phase 42 继续，双轨并行）

> 优先级排列：q1.9（多轮携带策略）→ q1.10（利用效率度量）→ q1.11（结构化 vs 非结构化）→ q1.6（多语言）→ q1.7（多任务）→ q1.12-ch1.19 余 6 题（更低优先级）

---

## Phase 43 — 跨页交互体验 🟢

**目标**：打通 Learn/Lab/Chat 三页之间的交互路径，让用户从「看书」到「动手试」到「对话探索」形成闭环。与 Phase 42 内容填充双轨并行。

**进入条件**：Phase 42 Batch 5 完成（q1.8 上下文组装策略），产品交互方向独立成 Phase。

### ✅ Phase 43 Batch 1 — Lab URL 路由

**需求**：43.1 Lab 页支持 `?tab=` URL 参数定位
**内容**：LabShell 通过 `useSearchParams` 读取 `?tab=` 参数，合法值设置初始 Tab，非法/空值默认 `context`。`lab/page.tsx` 加 Suspense 包裹。
**验证**：vitest 13 tests (LabShell) · tsc 0 · eslint 0
**影响范围**：`lab/page.tsx` (edit) · `LabShell.tsx` (edit) · `LabShell.test.tsx` (edit)
**Commit**: `feat(Phase 43 Batch 1): Lab URL 参数路由`

### ✅ Phase 43 Batch 2 — Learn→Lab 桥接按钮

**需求**：43.2 labLinks 可点击按钮从 Learn 页跳转到 Lab 页对应 Tab
**内容**：`types.ts` 新增 LabLink 接口 + Answer.labLinks 可选字段；`AnswerCard.tsx` 在 L3 后新增桥接按钮组（RiFlaskLine 图标 + brand 按钮），每个 labLinks 渲染一个按钮
**验证**：vitest 29 tests (AnswerCard) · 2 新测试（按钮渲染 + 导航）· vitest 1225/1225 · tsc 0 · eslint 0
**影响范围**：`types.ts` (edit) · `AnswerCard.tsx` (edit) · `AnswerCard.test.tsx` (edit)
**Commit**: `feat(Phase 43 Batch 2): 桥接按钮`

### ✅ Phase 43 Batch 3 — 跨章 labLinks 注册

**需求**：43.3 ch1/ch2/ch3 已完成答案注册 labLinks
**内容**：ch1 q1.1-q1.5 + q1.8 → context 溢出模拟沙箱/上下文策略对比 · ch2 7 题 → data/graph 相关 Lab · ch3 6 题 → context 意图测试/重规划对比
**验证**：vitest 1227/1227 · tsc 0 · eslint 0 · check-theme 5 route 0 error
**影响范围**：`ch1.ts` (edit) · `ch2.ts` (edit) · `ch3.ts` (edit)
**Commit**: `feat(Phase 43 Batch 3): ch1,ch2,ch3 labLinks 注册`

---

## Phase 44 — 记忆系统内容攻坚 + 透明化设计穿插 🆕

> 战略定位：Phase 42-43（Ch1 上下文工程填充 6 题 + Lab 桥接）完成后，从用户最关心的"AI 怎么记住、怎么忘"入手，攻坚 Ch2 记忆系统 26 问（1 已做），穿插 Ch7 透明化设计 5 问（1 已做）。
>
> 详细计划：[docs/plans/phase-44-memory-content.md](docs/plans/phase-44-memory-content.md)

| 批次 | 内容 | 状态 | 实际完成 Phase |
|------|------|:----:|:----:|
| Batch 1 | q2.2 不一致处理 + q2.3 反幻觉 | ✅ | Phase 48 (Ch2 26/26 闭环) |
| Batch 2 | q2.4 信息压缩 + q2.5 压缩反幻觉 | ✅ | Phase 46 B1/B2 |
| Batch 3 | q2.6 合理遗忘 + q2.7 固话 | ✅ | Phase 48 B1 |
| Interlude 4 | q7.1 多视角 + q7.2 三视角（Ch7 ①） | ✅ | Phase 50 B4 (q7.2) + Phase 48 (q7.1) |
| Batch 5 | q2.8 重复 + q2.9 不一致 | ✅ | Phase 48 B1 |
| Batch 6 | q2.10 定期更新 + q2.11 长期存储 | ✅ | Phase 48 B2 |
| Batch 7 | q2.12 人物画像 + q2.13 记忆分层 | ✅ | Phase 48 B3 |
| Interlude 8 | q7.3 边界 + q7.4 叙事vs数据（Ch7 ②） | ✅ | Phase 50 (Ch7 6/6 闭环) |
| Batch 9 | q2.14 混合检索 + q2.15 冲突仲裁 | ✅ | Phase 48 (Ch2 26/26 闭环) |
| Batch 10 | q2.16 画像更新 + q2.17 真删vs降权 + q2.18 可解释性 | ✅ | Phase 48 B4 (q2.16) / B5-B6 |
| Interlude 11 | q7.5 渐进披露 | ✅ | Phase 50 B3 |
| Batch 12 | q2.19-q2.22 冷启动/自清洁/灾难/因果 | ✅ | Phase 48 B4/B5/B6 |
| Batch 13 | q2.23-q2.26 内隐/情绪/程序/免疫（Ch2 完 ✅） | ✅ | Phase 48 B5/B6 |

---

### 📱 远期 — 移动端产品化（独立 Phase，待排期）

> 范围：聊天页 + 文档/问题列表 + 画像页 3 个移动端 MVP。其余页面（可观测/实验室/复杂图表）不在移动端适配范围内。
> 前置条件：产品内容成熟后启动。当前只保留 Phase 33 Batch 1 的窄屏可用性基础设施，不继续投入。

---

## 四支柱研究纵深 — 排期总览

> 最后更新: 2026-06-30 (Phase 55-61 全量拆解完成)
> 来源：原 Phase 27 → Phase 30 的战略规划。每个子阶段独立成 Phase，每 Phase ≤5 Batch。

### 一、记忆设计

| # | 子阶段 | Phase | Batch 数 | 现状 |
|---|--------|:---:|:---:|------|
| 1.2 | 多层存储架构 | **Phase 54** | 5 | ✅ 完成（5 Batch — TierClassifier → Store → RecallEngine → TierRebalancer → API + 前端可视化）|
| 1.3 | 智能召回 (MMR) | Phase 20 Batch 82 | — | ✅ 已交付 (`src/memory/recall.py:140`) |
| 1.4 | 记忆固化 | **Phase 56** | 2 | ✅ B1 ✅ · B2 ✅ — **Phase 56 全部闭环** 🎉 |
| 1.5 | 用户记忆控制 | Phase 30 | — | ✅ 完成 |

### 二、上下文处理

| # | 子阶段 | Phase | Batch 数 | 现状 |
|---|--------|:---:|:---:|------|
| 2.1 | Token 预算机制 | **Phase 63** ✅ | 2 | ✅→✅ 查询分级+预算分配+自动降级全量交付（Phase 17 容量感知/四区配比已交付） |
| 2.2 | 按需展开 | **Phase 58** | 2 | ✅ B1 条目概要化 + B2 两阶段注入 ✅ |
| 2.3 | 上下文压缩管道 | **Phase 64** ✅ | 2 | ✅ B1 ✅ · B2 ✅ — **Phase 64 全量闭环** 🎉
| 2.4 | 跨会话连续性 | **Phase 59** | 2 | ✅ B1 ✅ · B2 回归摘要+待办跟踪 ✅ |

### 三、Token 效率

| # | 子阶段 | Phase | Batch 数 | 现状 |
|---|--------|:---:|:---:|------|
| 3.2 | 分级响应 | **Phase 63+65** ✅ | 3 | ✅→✅ 自动降级(B63✅)+敏感本地分流(B65✅)（Phase 17 管线差异化路由已交付） |
| 3.3 | 缓存策略 | **Phase 62** ✅ (1st) + Phase 65 | 3 | ✅ 响应缓存已交付（Phase 62）· ✅ 敏感本地分流已交付（Phase 65） |
| 3.4 | 模型路由 | **Phase 55** (P1) | 4 | ✅ B1 ✅ · B2 ✅ · B3 ✅ · B4 ✅ 前端可见 — **Phase 55 全部闭环** |

### 四、任务规划

| # | 子阶段 | Phase | Batch 数 | 现状 |
|---|--------|:---:|:---:|------|
| 4.1 | Plan 生成/存储 | Phase 53 | 2 | ✅ 完成 (Schema + Store + API + 前端接入) |
| 4.2 | 记忆引导规划 | **Phase 60** | 3 | ✅ B1 历史计划检索 · B2 成败模式学习 · B3 自适应生成 — 全量闭环 |
| 4.3 | 动态重规划 | **Phase 57** (P1) | 3 | ✅ B1 步骤监控 · B2 局部重规划 · B3 用户干预接口 — 全栈闭环 |
| 4.4 | 反思闭环 | **Phase 61** | 2 | ✅ B1 事后总结 · B2 知识沉淀+计划蒸馏 — 全量闭环 |

**总计**：15 子阶段，11 完成 + 4 部分 (2.1/2.3/3.2/3.3) — 所有已排期 Phase (55-61) 全部交付 🎉
**下一阶段**：Phase 62-65 四支柱收尾——4 个部分交付 → 全量闭环（↓下方）。7 Batch，3.3 响应缓存最先（用户感知最强）→ 2.1 预算第二（架构乘数最高）。

### 依赖拓扑与执行顺序

```
已交付:  1.2(多层存储)  1.3(MMR)  1.5(用户控制)  4.1(Plan存储)  2.1/2.3/3.2/3.3(部分)
P1 优先: Phase 55 (3.4 模型路由) ✅ ∥ Phase 57 (4.3 动态重规划) ✅ B1 ✅ · B2 ✅ · B3 ✅ — 全栈闭环
P2 后续: Phase 56 (1.4 记忆固化 2批) ✅ → Phase 59 (2.4 跨会话) ✅ → Phase 58 (2.2 按需展开) ✅
          Phase 60 (4.2 记忆引导) → Phase 61 (4.4 反思闭环) [依赖 4.1✅+4.3]
四支柱收尾: Phase 62 (3.3 响应缓存) ✅ → Phase 63 (2.1 预算+3.2 降级) ✅ → Phase 64 (2.3 压缩加固) ✅ → Phase 65 (3.2 敏感本地) ✅
             优先级: 3.3 > 2.1 > 2.3 > 3.2 (用户感知递减 + 架构乘数递减)
```

---

## Phase 45 — 流程图位置升级 + 风格对齐 🆕

| Batch | 内容 | 状态 | 关键交付 |
|:------|------|:----:|---------|
| Phase 45 Batch 1 | q1.2/q1.3 流程图从 l3 升级移至 l1 + 风格对齐（emoji/完整配色） | ✅ | `ch1.ts` q1.2 l1 新增三方案决策图，q1.3 l1 新增三层防线漏斗图；旧 l3 mermaid 移除。验证：tsc 0 · vitest 1012/1012 |

---

## Phase 46 — 内容补齐（记忆系统 + 任务规划）

> 战略定位：承接 Phase 44 搁置的 q2.4/q2.5 空壳，继续补齐 P0 空壳。B1-2 补齐 Ch2 记忆系统，B3 补齐最后一个 P0 空壳 q3.2（Ch3 任务规划）。

| Batch | 内容 | 状态 | 关键交付 |
|:------|------|:----:|---------|
| Phase 46 Batch 1 | q2.4 信息压缩手段对比（L0-L3 + mermaid 流程图） | ✅ | `ch2.ts` q2.4 L0-L3 全部填充，含五手段对比 mermaid 流程图 + 代码引用段 + 对比表。验证：tsc 0 · eslint 0 · vitest 1228/1228 |
| Phase 46 Batch 2 | q2.5 LLM 压缩反幻觉 | ✅ | `ch2.ts` q2.5 L0-L3 全部填充，含六道防线 mermaid 流程图 + 代码引用段 + 对比表 + labLinks 注册。验证：tsc 0 · eslint 0 · vitest 1228/1228 |
| Phase 46 Batch 3 | q3.2 LLM 意图识别流程详解 | ✅ | `ch3.ts` q3.2 L0-L3 全部填充，含四步流程 + 三层容错 mermaid 流程图 + 完整代码引用（`_classify_via_api()` / `_parse_intent()` / `IntentResult`）+ labLinks 注册。**14 P0 空壳全量清零 🎉**。验证：tsc 0 · eslint 0 · vitest 1228/1228 |

---
## Phase 47 — Ch1 上下文工程内容补齐

> **战略定位**：Phase 42（Ch1 内容管线）交付了 q1.1-q1.5+q1.8 后暂停去做跨页交互。Phase 46 完成 Ch2/Ch3 内容后回来收 Ch1 的尾。11 个空壳按 P1→P2→P3 逐批补齐。
> **对齐关系**：用户读完已完成的「上下文溢出→重复→噪声→不一致→组装」叙事链后，最自然追问「跨轮次怎么带」——q1.9 多轮携带策略。

| Batch | 题目 | 优先级 | 状态 | 关键交付 |
|:------|------|:------:|:----:|---------|
| Phase 47 Batch 1 | q1.9 多轮携带策略 + q1.10 利用效率度量 | P1 | ✅ | 双题 L0-L3 全量填充，含三层携带决策树 + 效率度量框架 mermaid 流程图 + 代码引用（`SessionState`/`_build_system_prompt()`/`ContextPartitions`/`OverflowSimResult`/`TokenLedger`）+ 对比表 + labLinks。验证：tsc 0 · eslint 0 · vitest 1228/1228 |
| Phase 47 Batch 2 | q1.12 System Prompt 膨胀治理 | P1 | ✅ | 完整 L0-L3 填充，含暗物质比喻四来源 + 五条治理策略详解 + 代码引用（`_build_system_prompt()`/`ContextPartitions`/`fact.py`/`planner` 四模块膨胀画像）+ 对比表 + mermaid 流程图。验证：tsc 0 · eslint 0 · vitest 1228/1228 |
| Phase 47 Batch 3 | q1.6 多语言 + q1.7 多任务 | P2 | ✅ | 双题 L0-L3 全量填充，含 Tokenizer 语言差异对比表 + `_estimate_tokens()` 代码引用 + 5 模块多语言风险审计 + PlannerEngine 5 类意图 → 任务映射 + 三任务隔离缺失机制 + mermaid 双流程图。验证：tsc 0 · eslint 0 · vitest 1228/1228 |
| Phase 47 Batch 4 | q1.11 结构化 vs 非结构化 + q1.13 迷失中间 | P2 | ✅ | 双题 L0-L3 全量填充，含 token 效率对比表 + 格式选择决策 mermaid + Lost-in-the-Middle 研究引用（Liu et al. 2023）+ 注意力分布与缓解策略 mermaid + 代码引用（`compute_partitions()`/`_build_system_prompt()`/`simulate_overflow()`/`TokenLedger`）。验证：tsc 0 · eslint 0 · vitest 1228/1228 |
| Phase 47 Batch 5 | q1.14 格式编码 + q1.15 指令层级冲突 | P3/P2 | ✅ | 双题 L0-L3 全量填充，含四种格式 token 成本对比表 + `_build_system_prompt()`/`_ZONE_DEFS` 编码结构代码解剖 + 三层指令优先级详解 + `engine.py:179-184` API 调用层级代码引用 + 软覆盖模式分析 + 指令层级 mermaid 流程。验证：tsc 0 · eslint 0 · vitest 1228/1228 |
| Phase 47 Batch 6 | q1.16 时间维度 + q1.17 上下文水合 | P2 | ✅ | 双题 L0-L3 全量填充，含三层组织方案代码解剖（`_build_system_prompt()`/`RecallEngine.recall()`/`mmr_rerank()`）+ 存储-召回直通路径 + 三分区对比表 + 水合架构设计 + 真压缩-水合循环方案。Ch1 全部完成 🎉。验证：tsc 0 · eslint 0 · vitest 1228/1228 |

---

## Phase 48 — Ch2 记忆系统内容攻坚 🆕

> **战略定位**：承接 Phase 46 已完成的 q2.4/q2.5 与 Phase 36 完成的 6 题，继续攻坚 Ch2 记忆系统剩余 15 空壳。从最直接的「怎么记住」开始，覆盖固话/冲突/刷新/分层/极端场景/高级记忆类型，将 Ch2 answeredCount 从 11/26 推到 26/26。
> **对齐关系**：用户读完 Ch1 上下文工程（塞什么、怎么塞）后，最自然追问的是「塞进去以后怎么记住、怎么处理矛盾的记忆」——正好对应 q2.7 记忆固话 + q2.9 不一致记忆处理。

| Batch | 内容 | 状态 | 关键交付 |
|:------|------|:----:|---------|
| Phase 48 Batch 1 | q2.7 记忆固话 + q2.9 不一致记忆处理 | ✅ | 双题 L0-L3 全量填充 + `ForgettingEngine.strengthen()`/`decay_all()` 代码引用 + `_dedup_and_store()` 冲突检测代码引用 + 三手段/四策略对比表 + 协同流程 mermaid + 概率事实融合等前沿方向。Ch2 answeredCount 11→13。验证：tsc 0 · eslint 0 · vitest 1228/1228 |
| Phase 48 Batch 2 | q2.10 定期更新 + q2.11 长期存储 | ✅ | 双题 L0-L3 全量填充 + `RecallEngine.recall()` 召回增强/`store.update_strength()`/`add_episode()` 代码引用 + 三模式/三层架构对比表 + schema 表结构 + 多层热温冷前沿。Ch2 answeredCount 13→15。验证：tsc 0 · eslint 0 · vitest 1228/1228 |
| Phase 48 Batch 3 | q2.12 人物画像 + q2.13 记忆分层 | ✅ | 双题 L0-L3 全量填充 + `get_predicate_tag_summary()`/`update_fact_confidence()`/`switch_profile()` 代码引用 + 画像即聚合设计哲学 + 三层强度区间自然边界 + `current_strength()`/`recall()` score/`decay_all(lambda_override)`/`strengthen()` 代码引用 + 分层对比表 + schema 字段 + 聚合/分层双 mermaid 图。Ch2 answeredCount 15→17。验证：tsc 0 · eslint 0 · vitest 1228/1228 |
| Phase 48 Batch 4 | q2.16 画像更新 + q2.19 冷启动 | ✅ | 双题 L0-L3 全量填充 + 三种画像更新方案对比（纯增量 SQL / 全量重建快照 / 事件驱动增量）+ 冷启动四引擎行为表 + 演化曲线 mermaid + `extract_and_store()`/空 FAISS/`decay_all()` 空行代码引用。Ch2 answeredCount 17→19。验证：tsc 0 · eslint 0 · vitest pass |
| Phase 48 Batch 5 | q2.20 记忆污染与自清洁 + q2.26 记忆免疫系统 | ✅ | 双题 L0-L3 全量填充 + 三重自清洁机制交互+mermaid（衰减/冲突/增强）+ 三道免疫防线+mermaid（去重/冲突/MMR）+ 三种逃逸路径分析（渐变异/跨属性/社交工程）+ `_dedup_and_store()`/`update_fact_confidence()`/`decay_all()`/MMR 完整代码引用 + 频率门控/免疫记忆/LLM可信度提示等前沿方向。Ch2 answeredCount 19→21。验证：tsc 0 · eslint 0 · vitest pass |
| Phase 48 Batch 6 | q2.21 灾难性记忆 + q2.22 因果关系建模 + q2.23 内隐/外显记忆 + q2.24 情绪记忆 + q2.25 程序性记忆 | ✅ | 五题 L0-L3 全量填充 + `decay_all(lambda_override)`/`delete_fact()`/`delete_episode()` 灾难性记忆代码引用 + 因果缺失结构性证据（`add_fact()`/`add_episode()` schema 无因果字段）+ 内隐外显无差别存储代码引用（`add_fact()` 统一 confidence）+ 情绪记忆静态 importance 代码引用（`add_episode()` 默认 0.5）+ 程序性偏好混合统计代码引用（`get_predicate_tag_summary()`）+ 各题前沿方向（事件驱动衰减/因果图/来源感知衰减/动态 importance/频率门控偏好）。Ch2 answeredCount 21→26。验证：tsc 0 · eslint 0 · vitest pass |

---

## Phase 49 — Ch3 任务规划内容攻坚 🆕

> **战略定位**：承接近期已填写的 q3.1-3.17 已有 7 题，继续推进剩余 9 题空壳填充。覆盖规划核心流程（拆解/验证/工具/失败处理）+ 规划的交互与边界（人机协作/语言/记忆/中断/可否决性），将 Ch3 answeredCount 从 7/16 推到 16/16。

| Batch | 内容 | 状态 | 关键交付 |
|:------|------|:----:|---------|
| Phase 49 Batch 1 | q3.3 意图识别失败 + q3.6 任务拆解 + q3.7 工具编排 + q3.8 计划验证 | ✅ | 四题 L0-L3 全量填充 + `classify_intent()`/`_parse_intent()` 三层容错+兜底代码引用 + `_parse_plan()` 三阶回退 + 截断 + `PlanResult`/`_derive_dag_edges()` DAG 拆解代码引用 + 工具选择缺失现状（`PlanResult` 无 tool 字段）代码引用 + 无 `validate_plan()` 验证代码引用。Ch3 answeredCount 7→11。验证：tsc 0 · eslint 0 · vitest pass |

## Phase 49 Batch 2 — 规划的交互与边界 ✅

| Batch | 内容 | 状态 | 关键交付 |
|:------|------|:----:|---------|
| Phase 49 Batch 2 | q3.10 人机协作 + q3.11 规划语言 + q3.12 规划与记忆 + q3.13 中断恢复 + q3.14 可否决性 | ✅ | 五题 L0-L3 全量填充 + PlanResult.confidence/ReplanDetector/ReflectionEngine/MemoryStore 代码引用。Ch3 answeredCount 11→16（Ch3 闭环 ✅）|

## Phase 49 Batch 3 — Ch3 跨章关联 ✅

| Batch | 内容 | 状态 | 关键交付 |
|:------|------|:----:|---------|
| Phase 49 Batch 3 | Ch3 全部 16 题跨章关联 — 连接 Ch1/Ch2/Ch4/Ch5 | ✅ | types.ts 新增 CrossChapterConnection 类型 + Answer.crossChapterConnections 字段 + ch3.ts 16 题全量填充（48 条关联）+ AnswerCard 渲染 + 测试覆盖。验证：tsc 0 · eslint 0 · vitest 1228 pass |

---

---

## Phase 50 — Ch7 透明化设计内容攻坚 🆕

> **战略定位**：承接 Phase 47 已完成的 Ch1 全部 17 题与 Phase 48 Ch2 全部 26 题，Phase 49 Ch3 全部 16 题，继续推进 Ch7 透明化设计的剩余内容空壳填充。B3 完成 q7.5 渐进披露，B4 完成 q7.2 三视角实操，Ch7 answeredCount 5→6。

| Batch | 内容 | 状态 | 关键交付 |
|:------|------|:----:|---------|
| Phase 50 Batch 3 | q7.5 渐进式信息披露（L0→L1→L2→L3 四层内容填充） | ✅ | `ch7.ts` q7.5 L0-L3 全量填充 + 三层纵深防御图 + 四层电梯演讲 + 自检清单。验证：tsc 0 · eslint 0 · vitest pass |
| Phase 50 Batch 4 | q7.2 三视角实操：一条召回记忆、三个视角看 | ✅ | `ch7.ts` q7.2 L0-L3 全量填充 + 四步管线三栏对照表 + RecallItem 三路渲染代码架构 + 行业对标 + 视角切换未解问题。Ch7 answeredCount 5→6。验证：tsc 0 · eslint 0 · vitest pass |

任何批次验证不通过 → 停止，修好再进下一批。

---

## Phase 51 — Ch6 时间与节奏内容攻坚 ✅

> **战略定位**：承接 Phase 50 Ch7 闭环后，完成 Ch6「时间与节奏」6 问内容攻坚。叙事弧线从"四大支柱集成"（Ch5）延伸到"时间维度"（Ch6），为后续 Ch8 元认知引入时间概念基础。3 批 × 2 问。

| Batch | 内容 | 状态 | 关键交付 |
|:------|------|:----:|---------|
| Phase 51 Batch 1 | q6.1 同步 vs 异步认知操作 + q6.2 自然时间 vs 事件时间衰减 | ✅ 已完成 | `ch6.ts` q6.1+q6.2 L0-L3 全量填充 + Mermaid ×2-3 + crossChapterConnections ×3+。Ch6 answeredCount 0→2。验证：tsc 0 · eslint 0 · vitest pass · L0-L3 渲染正确 · 代码引用真实 |
| Phase 51 Batch 2 | q6.3 用户昼夜节律 + q6.4 系统成长轨迹 | ✅ 已完成 | `ch6.ts` q6.3+q6.4 L0-L3 全量填充 + Mermaid ×2 + crossChapterConnections ×5 + ⚠️ L5 拉通自检执行。Ch6 answeredCount 2→4。验证：tsc 0 · eslint 0 · vitest 1232/1232 · L5 置信度 0.87 |
| Phase 51 Batch 3 | q6.5 信息时效性分层衰减 + q6.6 实时 vs 批处理边界 | ✅ 已完成 | `ch6.ts` q6.5+q6.6 L0-L3 全量填充 + Mermaid ×2 + crossChapterConnections ×6 + L5 拉通自检执行。Ch6 answeredCount 4→6，Ch6 全章闭环。验证：make check 657/657 · tsc 0 · eslint 0 · vitest 1232/1232 · ch6.ts 全部 confidence 梯度正确 · 代码引用真实（store.py:130 / forget.py:25 / engine.py:153 / engine.py:292）|

任何批次验证不通过 → 停止，修好再进下一批。

---

## Phase 52 — Ch8 元认知内容攻坚 🆕

> **战略定位**：承接 Phase 51 Ch6 闭环后，攻克最后一章 Ch8「元认知」6 问。叙事弧线从"系统怎么做"的七章延伸到"系统怎么知道自己做得好不好"。5 批完成——3 批内容创建 + 2 批 L5 nitpick 修复。**Ch8 是 93 问的终点——项目全部内容闭环 🎉。**

| Batch | 内容 | 状态 | 关键交付 |
|:------|------|:----:|---------|
| Phase 52 Batch 1 | q8.5 求助升级粒度 + q8.1 置信度校准 | ✅ 已完成 | `ch8.ts` q8.5+q8.1 L0-L3 全量填充 + Mermaid ×2 + crossChapterConnections ×6。Ch8 answeredCount 0→2。验证：tsc 0 · eslint 0 · vitest 1232/1232 |
| Phase 52 Batch 2 | q8.2 已知未知 + q8.3 自我质疑 | ✅ 已完成 | `ch8.ts` q8.2+q8.3 L0-L3 全量填充 + Mermaid ×2 + crossChapterConnections ×6 + L5 拉通自检。Ch8 answeredCount 2→4。验证：tsc 0 · eslint 0 · vitest 1232/1232 |
| Phase 52 Batch 3 | q8.4 能力边界 + q8.6 元认知 Token 成本 | ✅ 已完成 | `ch8.ts` q8.4+q8.6 L0-L3 全量填充 + Mermaid ×2 + crossChapterConnections ×6。Ch8 answeredCount 4→6。Ch8 全章闭环 🎉。验证：tsc 0 · eslint 0 · vitest 1232/1232 |
| Phase 52 Batch 4 | q8.4 L2 能力表分组重构 | ✅ 已完成 | `ch8.ts` q8.4 L2 14行扁平表 → 🔘显式开关(4行)+📦隐式常驻(5×2双列) 两子表。降低信息密度，增加扫读性。验证：content-integrity 16/16 |
| Phase 52 Batch 5 | q8.4/q8.6 L3 格式差异化 | ✅ 已完成 | `ch8.ts` q8.4 L3→设计权衡矩阵(3方案×5维度) / q8.6 L3→ROI评估(2×2成本价值矩阵+4步优化路线)。打破6题同模板疲劳。验证：content-integrity 16/16 |

任何批次验证不通过 → 停止，修好再进下一批。

## Phase 53 — Plan 存储 (4.1) 🆕

> **战略定位**：P0 首发。四支柱中 Plan 生成已交付但结果零持久化——这是最大的"已有代码浪费"。Phase 53 打通 Plan 存储→查询链路（Schema + Store + API + 前端接入），2 Batch。

| Batch | 内容 | 状态 | 关键交付 |
|:------|------|:----:|---------|
| Phase 53 Batch 1 | Schema + PlanStore 方法 | ✅ 已完成 | `schema.sql` 新增 `plan_runs` + `plan_subtasks` 表（2 表 + 2 索引）。`store.py` 新增 `insert_plan` / `get_plan` / `list_plans` / `get_latest_plan` 四方法 + `_migrate()` 扩展。`config.py` 新增 `plan_storage_enabled` feature flag。`test_memory_store.py` +9 tests。DB 表 5→7，tests 657→666，store.py 502→673 行 |
| Phase 53 Batch 2 | API + 管线接入 + 前端 mock→真 | ✅ 已完成 | `schemas.py` +3 模型。`planner.py` +2 GET 端点。`chat.py` Step 4.5 Plan 持久化（lazy import settings + 门控）。前端 `PlanRun`/`PlanSubtask`/`PlanDetail` 类型 + `api.getPlans()`/`api.getPlan()` 方法。`SidebarReflectionCard` mock→真（`api.reflect()` 接线）。`ReplanComparePanel` mock→真（API 获取最近 2 plans 并排对比）。`test_api.py` +9 集成测试。验证：675 Python tests · 1224 frontend tests · make check 全绿 |
| Phase 54 Batch 1 | 分级逻辑 + TierClassifier | ✅ 已完成 | `src/memory/tier.py` — TierClassifier（三权重热力评分：recency 0.4 + access 0.3 + importance 0.3）+ TierLevel(HOT/WARM/COLD) StrEnum + TierResult frozen dataclass + classify/classify_batch/get_tier_distribution/get_tier_episode_ids。`config.py` +6 tier 字段。`tests/test_tier.py` +26 tests。验证：701 Python tests · make check 全绿 |
| Phase 54 Batch 2 | Schema + Store 分层方法 | ✅ 已完成 | `schema.sql` episodes 加 tier 列（`tier TEXT NOT NULL DEFAULT 'warm'`）+ `idx_episodes_tier` 索引。`store.py` `_migrate()` 扩展 + 4 分层方法（`set_episode_tier`/`set_episode_tiers_batch`/`get_episodes_by_tier`/`get_tier_distribution`）。`test_memory_store.py` +10 tests（`TestTierStorage`：设置/批量/按层查询/分布/迁移/默认值）。验证：713 Python tests · make check 全绿 |
| Phase 54 Batch 3 | RecallEngine 分层感知 | ✅ 已完成 | `recall.py` 两阶段搜索（hot 全量→warm 补充→cold 排除）+ `_score_episodes` 评分提取。`config.py` +1 `tier_search_k` 参数。`test_recall.py` +8 tests（`TestTierAwareRecall`：hot 优先/warm 补充/cold 排除/向后兼容/全 hot/全 warm/空/facts 包含）。验证：721 Python tests · make check 全绿 |
| Phase 54 Batch 4 | 定时重均衡 + 管线触发 | ✅ 完成 | `tier.py` TierRebalancer（定时重算热度分 + 跨层迁移）。`chat.py` 周期性触发（lazy import + feature flag 门控）。`test_tier.py` +6 tests。**3 文件 · 1 关注点 · 依赖 B3** |
| Phase 54 Batch 5 | API + 前端可见 | ✅ 已完成 | `schemas.py` TierDistributionResponse + EpisodeOut.tier。`memory.py` `GET /memory/tiers` 端点（TierClassifier 实时分级 + feature flag 门控）。`MemoryBrowserPanel.tsx` tier 过滤 pills（全部/热层/温层/冷层）+ 彩色徽章 + 详情展开 tier 字段。`types-memory.ts` TierDistributionResponse + EpisodeOut.tier。`client.ts` getTiers()。`types.ts` re-export。`JourneyHistoryBrowser.test.tsx` 4 fixtures +tier。验证：721 Python + 1231 frontend · lint zero · mypy zero · tsc zero · eslint zero。**7 文件 · 2 关注点 · Phase 54 全部闭环 ✅** |

任何批次验证不通过 → 停止，修好再进下一批。

---

## Phase 55 — 模型路由 (3.4) 🔵 P1

> **战略定位**：P1 优先。Token 效率支柱最后一个缺失子阶段——本地小模型做简单任务、DeepSeek 做复杂任务、失败自动回退。依赖 4.1 Plan 存储的 intent 信号作为路由键。4 Batch 渐进式交付。
> **前置条件**：Phase 53 ✅（Plan 存储 + intent 信号可用）

| Batch | 内容 | 关键交付 | 文件数 |
|:---:|------|------|:---:|
| **Phase 55 Batch 1** | ModelRouter 决策引擎 | `src/chat/model_router.py` (新) — `ModelRouter` 类 + `RoutingDecision` dataclass（intent→complexity→model 规则链）+ `config.py` +routing 字段（`routing_enabled`/`simple_model`/`complex_model`/`simple_intents`）。`tests/test_model_router.py` +16 tests | ✅ 3 (2新+1改) |
| **Phase 55 Batch 2** | 管线接入 | `src/chat/engine.py` — `_run_generation_phase` 前插入 `router.decide(intent)` → 选择模型。feature flag 默认 OFF。`tests/test_engine.py` +routing tests | ✅ 2 (api/routers/chat.py 插路由步骤 + src/chat/__init__.py 导出) |
| **Phase 55 Batch 3** | 失败回退 | `src/chat/model_router.py` 扩展 — 主模型超时/4xx/5xx → fallback 模型 + 1 次重试（不退化为无限重试）。新增 `RoutingResult` dataclass + `FallbackExhaustedError` + `is_retryable_error()` + `execute_with_fallback()`。`tests/test_model_router.py` +25 fallback tests（含 is_retryable_error/execute_with_fallback/FallbackExhaustedError/RoutingResult 四类） | ✅ 2 (model_router.py + test) |
| **Phase 55 Batch 4** | 前端可见 | `api/schemas.py` +`RoutingInfo` Pydantic 模型（7 字段）。`ChatResponse` +`routing` 字段。`ModelRoutingCard.tsx`（新）— Sidebar 路由状态卡片（路由决策 + 回退指示 + 模型 override 下拉）。`ChatParamsContext` +`lastRouting`/`routingOverrideModel` 状态。`toChatParams()` 仅在 override 时发送 model 字段（其余走自动路由）。`tests/test_api.py` +3 routing response tests | ✅ 8 (3 Python + 5 TSX/TS) |

**交付指标**：721→779 Python tests（+58）· 零新 API 端点 · `model_router.py` ~180 行 · `ModelRoutingCard.tsx` ~145 行（新）· Phase 55 四批全部闭环 ✅

任何批次验证不通过 → 停止，修好再进下一批。

---

## Phase 56 — 记忆固化 (1.4) 🔵 P2

> **战略定位**：依赖 1.2 多层存储（Phase 54）。两阶段纯后端——B1 慢降温（时间维度固化）→ B2 用进效应（访问维度反固化）。两批咬合形成完整的记忆巩固+遗忘管理闭环。
> **前置条件**：Phase 54 ✅（三层分级架构就绪：TierClassifier 三权重评分 + TierLevel 三级标签 + TierRebalancer 批量重均衡）
> **设计原则**：Consolidator 负责"调什么"，TierClassifier 负责"怎么分"。Consolidator 的输出（调整后的 importance）是 TierClassifier 的输入之一。
> **原 B3 剥离**：原"跨对话隐含关联发现"涉及 entity 共现分析 + fact_links 表，属于知识图谱推理（1.3 推理增强），不在记忆固化（1.4）范围。归档到独立的图谱扩展 Phase。

| Batch | 内容 | 关键交付 | 文件数 |
|:---:|------|------|:---:|
| **Phase 56 Batch 1** ✅ | ConsolidationCore + 日终慢降温 | `src/memory/consolidate.py` (新) — `ConsolidationCore` 类 + `consolidate_all` 慢降温（乘性衰减 ×0.98/次）+ `consolidate_if_stale` 机会主义触发（24h 间隔）。`config.py` +5 字段。`tests/test_consolidate.py` +13 tests（3 类：核心逻辑/触发/迁移）。 | 3 (2新+1改) |
| **Phase 56 Batch 2** ✅ | 动态重要性 + 遗忘豁免 | `src/memory/consolidate.py` 扩展 — `_compute_access_freq_norm` tanh 归一化 + `recalc_importance` 用进效应 + 合并公式（冷却 × boost）+ `protect_hot` 连续 N 次召回豁免。`src/memory/store.py` +`update_importance_batch`（仅写 importance，不动 last_consolidated_at）。`config.py` +5 字段。`tests/test_consolidate.py` 13→39 tests (+26 新，4 新类)。**Phase 56 全部闭环 🎉** | 4 (2改+2新) |

**交付指标**：~857→~870 Python tests (844→870 via Phase 56) · `consolidate.py` ~320 行 · 零新 DB 表 · 零 API 变更 · 零前端变更

**剥离项**：原 B3 "跨对话隐含关联发现"（entity 共现 + fact_links 表）→ 归档至独立的知识图谱扩展 Phase，不属 1.4 记忆固化范围。

任何批次验证不通过 → 停止，修好再进下一批。

---

## Phase 57 — 动态重规划 (4.3) ✅ P1 — 全部闭环

> **战略定位**：P1 优先。三步全栈闭环：B1 步骤监控（StepStatus + StepRecord + 3 钩子）→ B2 局部重规划（PartialReplanResult + generate_partial_replan + 二阶回退解析）→ B3 用户干预接口（PATCH endpoint + PlanOverride 模型 + ReplanComparePanel 逐步骤/批量干预按钮）。Python 825 tests · Frontend 1231 tests。
> **前置条件**：Phase 53 ✅（Plan 存储 + PlanResult 持久化）

| Batch | 内容 | 关键交付 | 文件数 | 状态 |
|:---:|------|------|:---:|:---:|
| **Phase 57 Batch 1** | 执行监控 + 失败检测增强 | `src/planner/replan.py` 扩展 — +`StepStatus` 枚举（5 态）+ `StepRecord` 数据类 + `monitor_step()` 钩子 + `get_step_summary()` 聚合 + `reset_monitor()` 清空。`tests/test_replan.py` +18 tests（35 total）| 2 | ✅ |
| **Phase 57 Batch 2** | 局部重规划 | `src/planner/replan.py` 扩展 — +`PartialReplanResult` 数据类 + `generate_partial_replan()` 主入口 + `_call_partial_replan_api()` + `_build_partial_replan_prompt()` + `_parse_partial_replan_response()` (二阶回退) + `_merge_partial_plan()`。`tests/test_replan.py` +23 tests (58 total) | 2 | ✅ |
| **Phase 57 Batch 3** | 用户干预接口 | `api/schemas.py` +5 模型（`PlanOverrideAction` StrEnum + `PlanOverride` + `PlanOverrideRequest` + `PlanOverrideResponse`）。`src/memory/store.py` +`update_subtask()` 方法。`api/routers/planner.py` +`PATCH /planner/plans/{plan_id}`（批量干预，终态保护）。前端 `types-chat.ts` +4 类型 + `client.ts` +`api.updatePlan()` + `ReplanComparePanel.tsx` +3 逐步骤按钮（✓/✕/⏭）+ 2 批量按钮（接受全部/拒绝全部）+ 反馈提示。`test_memory_store.py` +4 tests · `test_api.py` +7 tests · Python 825 tests | 4 | ✅ |

**交付指标**：Python tests: 779→820 (+41 B1+B2) · 预计终态 ~840 · `replan.py` 357→~600 行 → ~650 行

任何批次验证不通过 → 停止，修好再进下一批。

---

## Phase 58 — 按需展开 (2.2) 🔵 P2

> **战略定位**：上下文工程优化——召回条目先给概要（一行摘要），用户点击/追问时再展开完整内容。两阶段注入减少首轮 token 消耗。2 Batch 纯后端改动。
> **前置条件**：Phase 54 ✅（三层分级为概要化提供粒度基础）

| Batch | 内容 | 关键交付 | 文件数 |
|:---:|------|------|:---:|
| **Phase 58 Batch 1** ✅ | 条目概要化 | `src/context/partition.py` 扩展 — `summarize_recall_item()` 函数（从 RecallItem 提取一行摘要：主体+谓词+宾语，截断 ≤80 char）。`tests/test_partition.py` +summary tests | 2 |
| **Phase 58 Batch 2** ✅ | 两阶段注入 + 自引用标注 | `src/chat/engine.py` — `_build_two_stage_prompt()` + `expand_references()` + `generate(two_stage=True)`。`src/context/overflow_sim.py` 传播 `_ref_id`。`tests/test_engine.py` +17 two-stage tests | 3 |

**交付指标**：~770→~780 Python tests · 零 API 变更 · 零前端变更（后端透明优化）

任何批次验证不通过 → 停止，修好再进下一批。

---

## Phase 59 — 跨会话连续性 (2.4) 🔵 P2

> **战略定位**：用户关闭 Tab 后重开，系统能识别"上次聊到哪"并生成回归摘要。2 Batch 独立交付。
> **前置条件**：Phase 56 ✅（记忆固化提供跨会话数据基础）

| Batch | 内容 | 关键交付 | 文件数 |
|:---:|------|------|:---:|
| **Phase 59 Batch 1** ✅ | 会话边界检测 | `src/context/session_boundary.py` (新) — `SessionBoundaryResult` + `SessionBoundaryDetector`（三级回退 + 非终态 subtask 检测 + ?/? 启发式）。`src/config.py` +2 字段 (feature flag + gap)。`src/context/__init__.py` +2 导出。`tests/test_session_boundary.py` +18 tests。集成点延至 Batch 2（ChatEngine 无会话概念，边界检测在 API/CLI 层做）。 | 4 (2新+2改) |
| **Phase 59 Batch 2** ✅ | 回归摘要 + 待办跟踪 | `src/context/session_boundary.py` 扩展 — `RegressionSummary` @dataclass + `generate_regression_summary()`（对比最近 N 个 session_summaries 识别 ongoing/resolved 项）+ `track_open_items()`（持久化边界快照）+ `_build_summary_text()`。`src/memory/store.py` +`session_summaries` 表（2 CRUD 方法）+ `src/memory/schema.sql` 建表 + 索引。`src/config.py` +1 字段 (`num_sessions_for_regression`)。`tests/test_session_boundary.py` +11 tests。零 API 变更 · 零前端变更。 | 6 (1新+5改) |

**交付指标**：888→899 Python tests (+11) · `session_boundary.py` ~380 行 · +1 新 DB 表 · `store.py` +55 行 · `config.py` +1 字段 · 零 API 变更 · 零前端变更

任何批次验证不通过 → 停止，修好再进下一批。

---

## Phase 60 — 记忆引导规划 (4.2) 🔵 P2

> **战略定位**：让 Planner 从历史计划中学习——检索相似历史计划→提取成败模式→影响新计划生成。3 Batch 独立交付。
> **前置条件**：Phase 53 ✅（Plan 存储可查询）+ Phase 57 ✅（replan 信号丰富成败标签）

| Batch | 内容 | 关键交付 | 文件数 |
|:---:|------|------|:---:|
| **Phase 60 Batch 1** | 历史计划检索 | `src/planner/plan_history.py` (新) — `PlanHistoryRetriever`（基于 intent+entities 检索相似历史 PlanRun，复用 `src/memory/store.py` 的 `list_plans` 方法）。`tests/test_plan_history.py` +8 tests | 3 (2新+1改) |
| **Phase 60 Batch 2** | 成败模式学习 ✅ | `src/planner/plan_history.py` 扩展 — `extract_patterns()`（从历史 PlanRun 提取：全部子任务成功=成功模板 / 某类子任务反复失败=失败模式 / 平均耗时）。`tests/test_plan_history.py` +6 pattern tests（TestNormalizeDescription 2 + TestExtractPatterns 4）。B1 已内置代码，B2 补测试 + 修 `_normalize_description` 正则 `\s` 空白匹配 bug | 2 |
| **Phase 60 Batch 3** | 自适应生成 ✅ | `src/planner/plan.py` — `generate_plan()` 新增 `plan_history` 参数 + `_build_history_enriched_prompt()` 静态方法（成功模板→优先复用 / 失败模式→避免或加验证步）。`src/planner/intent.py` — `PlannerEngine.generate_plan()` 透传。`api/routers/chat.py` — Step 1.5 PlanHistoryRetriever 管线集成（feature flag 门控）。`tests/test_plan_generation.py` +7 history-aware tests | 3 |

**交付指标**：962 Python tests (+13 B2+B3) · `plan_history.py` ~400 行 · `plan.py` +60 行 · 零新 API · Phase 60 全量闭环 🎉

任何批次验证不通过 → 停止，修好再进下一批。

---

## Phase 61 — 反思闭环 (4.4) 🔵 P2

> **战略定位**：四支柱最后一个未排期子阶段。事后总结→知识沉淀（元知识）→计划蒸馏（最佳实践模板）。`src/planner/reflection.py` ReflectionEngine 已有基础。2 Batch 收尾。
> **前置条件**：Phase 53 ✅（Plan 存储）+ Phase 57 ✅（replan 信号）+ Phase 60 ✅（成败模式）

| Batch | 内容 | 关键交付 | 文件数 |
|:---:|------|------|:---:|
| **Phase 61 Batch 1** | 事后总结增强 ✅ | `src/planner/reflection.py` 扩展 — `PostMortemDeviation` + `PostMortemResult` dataclasses + `post_mortem()` 方法（`_extract_deviations()` 纯算法提取偏差 + LLM 合成改进建议 + `_parse_post_mortem()` 三阶解析）。`tests/test_reflection.py` +16 tests（10→26） | 2 |
| **Phase 61 Batch 2** | 知识沉淀 + 计划蒸馏 ✅ | `src/planner/reflection.py` 扩展 — `extract_meta_knowledge()`（从多次反思中提取跨计划的通用模式→存储为元知识事实）+ `distill_plan_template()`（从成功计划蒸馏最佳实践模板）+ `_parse_meta_knowledge()` 三阶回退。`src/memory/store.py` +`reflection_insights` 表 + 4 CRUD 方法（insert/list/get/upsert）。`tests/test_reflection.py` +21 tests | 5 |

**交付指标**：999 Python tests (+47 vs B1 起点) · `reflection.py` ~865 行 (+485 B2) · `store.py` +156 行 CRUD · Phase 61 全量闭环 🎉

任何批次验证不通过 → 停止，修好再进下一批。

---

## Phase 62 — 响应缓存 (3.3 收尾) 🔵 P2 · 优先级 1st ✅

> **战略定位**：四支柱 4 个部分交付中用户感知最强的一项——语义相似查询秒回。依赖现有 `EmbeddingCache` + `embed()` L2 normalized vectors。2 Batch 全量闭环。
> **前置条件**：Phase 17 ✅（EmbeddingCache + FactCache 已交付）

| Batch | 内容 | 关键交付 | 文件数 |
|:---:|------|------|:---:|
| **Phase 62 Batch 1** ✅ | SemanticResponseCache 核心 | `src/cache/` 包（模块→包转换）+ `semantic_cache.py` — `SemanticResponseCache`（brute-force cosine similarity via `np.dot` + 阈值 0.95 + FIFO 64）+ `config.py` +3 字段。`tests/test_semantic_cache.py` +15 tests | 6 (4新+1删+1改) |
| **Phase 62 Batch 2** ✅ | 管线接入 + 前端可见 | `api/routers/chat.py` Step 0 cache check（命中 bypass 全管线）+ `api/schemas.py` `ChatResponse` +`from_cache` + `cache_hit_score` + 前端类型同步 + `CacheHitIndicator.tsx` 绿色闪电指示器 + `tests/test_api.py` +3 integration tests | 7 (1新+6改) |

**交付指标**：999→1017 Python tests (+18) · `semantic_cache.py` ~170 行 · `CacheHitIndicator.tsx` ~40 行 · +2 API 字段 (`from_cache`, `cache_hit_score`) · 零破坏性变更 · Phase 62 全量闭环 ✅

任何批次验证不通过 → 停止，修好再进下一批。

---

## Phase 63 — 上下文预算 + 自动降级 (2.1 收尾 + 3.2 降级) 🔵 P2 · 优先级 2nd · ✅ 全量闭环

> **战略定位**：架构乘数最高——所有管线步骤受益于预算感知。QueryClassifier + BudgetAllocator + AutoDegradationEngine 三步一体，2 Batch。
> **前置条件**：Phase 17 ✅（分区可视化 + 容量感知已交付）

| Batch | 内容 | 关键交付 | 文件数 |
|:---:|------|------|:---:|
| **Phase 63 Batch 1** ✅ | QueryClassifier + BudgetAllocator | `src/context/budget.py` — `QueryClassifier`（intent + msg_length + history_len → `QueryClass` StrEnum: LIGHT/MEDIUM/HEAVY）+ `BudgetAllocator`（三级配比：轻 10%/中 40%/重 60% 窗口给记忆）+ `config.py` +budget 字段（`budget_enabled` / `light_budget_pct` / `medium_budget_pct` / `heavy_budget_pct`）。`tests/test_budget.py` 41 tests | 4 (2新+2改) |
| **Phase 63 Batch 2** ✅ | AutoDegradationEngine + 管线接入 | `src/context/budget.py` 扩展 — `AutoDegradationEngine`（运行时监控 token 用量 → 超标按优先级砍：①事实抽取 ②温层摘要 ③召回数量）+ `DegradationPlan` + `should_skip_step` 门控。`api/routers/chat.py` 步骤 2.5 budget check（分类→分配→降级评估→门控 warm 过滤→门控 recall 缩减→门控 fact_extraction）。`src/chat/engine.py` `generate_and_store()` +`skip_fact_extraction` 参数。`tests/test_budget.py` +28 tests（5 类：DegradationLevel×3 + DegradationPlan×3 + AutoDegradationEngine×15 + should_skip_step×7）。| 4 (3改+0新) |

**交付指标**：1086 Python tests · `budget.py` ~280 行 · 零 API 变更 · 零前端变更（后端透明优化）

任何批次验证不通过 → 停止，修好再进下一批。

---

## Phase 64 — 压缩质量加固 (2.3 收尾) 🔵 P2 · 优先级 3rd · B1✅ B2✅ 🎉

> **战略定位**：压缩管道已跑通，补质量保障层——关键信息保护 + 时序保真度评估。2 Batch 全部闭环。
> **前置条件**：Phase 17 ✅（单消息压缩 + 对话结构识别 + 增量摘要已交付）

| Batch | 内容 | 关键交付 | 文件数 |
|:---:|------|------|:---:|
| **Phase 64 Batch 1** ✅ | CriticalInfoProtector | `src/context/protector.py` — `CriticalInfoProtector`（regex+启发式检测：专名/数字/日期/决策/承诺 → 标记不可概括 span）+ `ProtectionReport` + `verify(original, compressed) → VerificationResult`（被保护项是否在压缩后完整保留）。`tests/test_protector.py` 52 tests (15 类：ProtectCategory×2 / ProtectedSpan×2 / ProtectionReport×7 / VerificationResult×3 / 专名×6 / 数字×7 / 日期×7 / 决策×5 / 承诺×5 / Detect×5 / VerifyConvenience×3)。`src/context/__init__.py` +5 exports。| 3 (2新+1改) |
| **Phase 64 Batch 2** ✅ | TemporalFidelity 评估 + 管线接入 | `src/context/protector.py` 扩展 — `TemporalFidelityEvaluator`（事件顺序保持率检测，LCS 比对 + 逆序检测）+ `TemporalFidelityResult` + `TemporalFidelityReport` + `TemporalAnchor` 四新类。`tests/test_protector.py` +23 fidelity tests (TemporalAnchor×3 / TemporalFidelityResult×4 / TemporalFidelityReport×7 / TemporalFidelityEvaluator×9)。`src/context/__init__.py` +4 exports。纯规则引擎，零 LLM 依赖。| 2 (1改+1改) |

**交付指标**：~1050 Python tests · `protector.py` ~200 行 · 零 API 变更 · 零前端变更

任何批次验证不通过 → 停止，修好再进下一批。

---

## Phase 65 — 敏感信息本地分流 (3.2 收尾) 🔵 P2 · 优先级 4th 🆕

> **战略定位**：安全兜底。PII/敏感查询走本地管线，不上传 API。1 Batch。
> **前置条件**：Phase 17 ✅（管线差异化路由已交付）

| Batch | 内容 | 关键交付 | 文件数 |
|:---:|------|------|:---:|
| **Phase 65 Batch 1** | SensitiveInfoDetector + local pipeline | `src/chat/local_router.py` — `SensitiveInfoDetector`（关键词+模式匹配：身份证/手机/银行卡/地址/密码/邮箱/API密钥）+ `route_local()` 本地管线（skip 外部 API，仅本地 recall + response 合成）。`config.py` +`local_routing_enabled` flag。`tests/test_local_router.py` +57 tests | 3 (2新+1改) | ✅ |

**交付指标**：1218 Python tests (+57) · `local_router.py` ~320 行 · 零 API 变更 · 零前端变更

任何批次验证不通过 → 停止，修好再进下一批。

---

> **四支柱收尾汇总**：Phase 62-65 共 7 Batch → 4 个 ✅ → 15/15 子阶段全量闭环 🎉 🎉 🎉
> **执行顺序**：Phase 62 (3.3) → Phase 63 (2.1+3.2降级) → Phase 64 (2.3) → Phase 65 (3.2敏感)。按用户感知递减 + 架构乘数递减排列。全部完成 ✅

---

## Phase 1000 Batch 29-33 — P2 治理：CSS 令牌 + 组件补齐 + 架构拆分 🆕

> 战略定位：四支柱 15/15 全量闭环后，master-backlog P2 项清零。5 批渐进式交付，按风险从低到高排列。
> 最后更新: 2026-07-02
> L5 触发点: B29→B30 完成后（2 批累积）

| Batch | 域 | 内容 | 文件 | 风险 | 状态 |
|:---:|------|------|:---:|:---:|:---:|
| **B29** | 审计+清理 | Backlog 审计清零（关闭 10 已修复条目）+ `backups/m4-pre/` 删除 + `tests/__init__.py` docstring | 2+删除 | 零 | ✅ |
| **B30** | CSS 令牌 | 硬编码 px → token（U5/U17/U8/U18）+ globals.css ~12 处 px 迁移 | 6 | 低 | ✅ |
| **B31** | 组件补齐 | Lab SVG zoom ×3（KnowledgeGraph/EmbeddingSpace/DecayDistribution）+ 2 组件测试补齐 | 5 | 中 | ✅ |
| **B32** | Feature 接线 | L2 召回参数后端接线（top_k/threshold/lambda 从 request body 读取） | 6 | 中 | ✅ |
| **B33** | CSS 架构 | globals.css 1089 行 → tokens/theme/animations/components 四文件拆分 | 6 | 高 | ✅ |

**本轮不纳入**（延后处理）：
- U4: ProcessDrawer 高度瑕疵（已知难点，3 次未果，需专门调试）
- D1: 代码块+说明文字模式统一（需进一步调查）
- D4/D5/F4: 会话累计 Token 等 feature（另起功能 Phase）
- Q6: 组件样式模式不一致（范围模糊）
- U6 剩余 ~18 处 px：动画/装饰性 1-2px 值，迁移性价比低

---

## Phase 1000 Batch 35-41 — P2 打磨：A11y → CROSS 令牌/动画 → 布局 → 主题 🆕

> 战略定位：A11y 无障碍补齐为最优先（用户可感知）→ CROSS 令牌/动画 token 化（工程一致性）→ 布局统一（架构健康）→ 主题适配（暗色模式）。
> 最后更新: 2026-07-02

| Batch | 域 | 内容 | 条目 | 文件 | 风险 | 状态 |
|:---:|------|------|------|:---:|:---:|:---:|
| **B35** | A11y 上 | tooltip 键盘可达 + radio role | A13/A14/A15 | ~6 | 低 | ✅ |
| **B36** | A11y 中 | 平台快捷键 + 移动端底部导航 | A16/A17 | ~4 | 中 | ✅ |
| **B37** | A11y 下 | renderMarkdown DOMPurify XSS 防护 | A18 | ~3 | 中 | ✅ |
| **B38** | CROSS 令牌 | 死 token 删除 + 命名对齐 + 计数文档化 | CROSS-9/10/11 | ~4 | 低 | ✅ |
| **B39** | CROSS 动画 | transition 粒度 + 缓动 token 化 | CROSS-14/15 | ~2 | 低 | ✅ |
| **B40** | CROSS 布局 | 滚动架构统一 + Grid 单列退化 | CROSS-5/6 | ~4 | 中 | ✅ |
| **B41** | CROSS 主题 | 动画验证闭环 + SVG 图例 var() 化 | CROSS-16/17/24 | ~2 | 低 | ✅ |

**探索验证的误报**（不纳入）：
- CROSS-4: Sidebar 宽度已统一 256px，仅注释残留 280px
- CROSS-16/17: `gm-fade-in`/`gm-slide-in` 已使用 `var()` token

**L5 点位**：B35+B36 → 第一次 L5 ✅（A11y 上半场）· B37+B38 → 第二次 L5 ✅（A11y 闭环 + 令牌收尾）· B39+B40 → 第三次 L5 ✅（全量闭环）

---

## Phase 1000 Batch 42-44 — CI 底座 🆕

> 战略定位：项目零 CI/CD，质量门禁全在本地 pre-commit hooks。三批递进：文档+命令 → 测试加厚 → 双平台配置。
> 最后更新: 2026-07-02
> L5 触发点: B42→B43 完成后（2 批累积）

| Batch | 域 | 内容 | 文件 | 风险 | 状态 |
|:---:|------|------|:---:|:---:|:---:|
| **B42** | CI/CD | CI/CD 决策文档 + `make ci` 目标 + 文档闭环 | ~5 | 低 | ⏳ |
| **B43** | 测试 | 骨架测试加厚（3 files, +13 tests）+ 文档闭环 | ~5 | 低 | ✅ |
| **B44** | CI/CD | GitHub Actions + Gitee Go 双平台 CI 配置文件 + 文档闭环 | ~5 | 中 | ✅ |

**B42 交付物**：
- `docs/ci-cd.md`（新建）— ADR 格式：当前状态 / 方案对比表 / 决策 `make ci` 为主方案 / GitHub Actions 备选 / Gitee Go 备选 / 迁库策略 / 文件索引
- `Makefile` — 新增 `make ci` 目标（= check + check-all），语义化一键全栈门禁
- 文档闭环（roadmap + requirements-log + master-backlog）

**B43 交付物**：
- `tests/test_api_root.py` 1→6 tests (+5: 方法拒绝/Content-Type/版本格式)
- `tests/test_api_cors.py` 2→6 tests (+4: POST preflight/无 Origin/custom headers/不同路由)
- `tests/test_api_health.py` 2→6 tests (+4: 全错/空组件/异常/非字符串状态)

**B44 交付物**：
- `.github/workflows/ci.yml`（新建）— push/PR to master 触发
- `.gitee/workflows/ci.yml`（新建）— Gitee Go 原生 CI
- `docs/ci-cd.md` 更新 — 双平台配置文件索引

**设计原则**：
- `make ci` 为主方案（跨平台可移植、离线可用、迁库零成本）
- 双平台 CI 配置文件只是 `make ci` 的薄包装
- CI 不做过度设计——单 job、无矩阵、无缓存优化

---

## Phase 1000 Batch 45 — 可观测性 F8+F6 前端拉通 🆕

> 战略定位：可观测性页面 50% 占位符 → 75% 可用。F8 Trace tab 激活（后端就绪→前端拉通）+ F6 仪表盘升级（+Token 消耗 +步骤延迟两张卡片）。
> 最后更新: 2026-07-02

| Batch | 域 | 内容 | 文件 | 风险 | 状态 |
|:---:|------|------|:---:|:---:|:---:|
| **B45** | 可观测性 | F8 Trace tab 激活 + F6 仪表盘升级 | 6 | 低 | ✅ |

**B45 交付物**：
- `ObserveShell.tsx` — traces tab 从 PlaceholderTab → PipelineTracePanel，4 tab 中 3 个有实际内容
- `TokenMetricsCard.tsx`（新建）— 消费 GET /metrics/tokens，展示 session 级 token 消耗摘要（总计+按调用点分段柱状条）
- `StepLatencyCard.tsx`（新建）— 消费 GET /metrics/steps，展示 pipeline 步骤延迟分布（次数+均值+范围，颜色编码）
- `HealthDashboard.tsx` — 指标卡片区（Token 消耗 + 步骤延迟 2-col grid）
- `ObserveShell.test.tsx` — 更新测试：mock PipelineTracePanel + 2 条 updated + 占位测试指向 compression tab

**设计原则**：
- F8 零新组件——复用 lab/ 已有的 PipelineTracePanel（功能完整，直接导入）
- F6 卡片自包含——各卡片独立 fetch + DataState 三态，不耦合 HealthDashboard 的数据流
- 风格一致——卡片沿用 HealthCard 的 accent bar + surface-elevated + rounded-gm-sm 模式

---

## Phase 1000 Batch 46 — 可观测性 F7 日志详情 🆕

> 战略定位：日志查看器从列表-only → 支持单条详情。补齐后端 GET /logs/{id} + 前端 LogDetailModal。
> 最后更新: 2026-07-02

| Batch | 域 | 内容 | 文件 | 风险 | 状态 |
|:---:|------|------|:---:|:---:|:---:|
| **B46** | 可观测性 | F7 日志详情（GET /logs/{id} + LogDetailModal） | 8 | 中 | ✅ |

**B46 交付物**：
- `api/schemas.py` — LogEntry +id: int · 新增 LogDetailResponse（prev_id/next_id 导航）
- `api/routers/logs.py` — `_parse_log_lines` 支持行号追踪 · 新增 GET /logs/{log_id} 端点（404 保护）
- `LogDetailModal.tsx`（新建）— 右侧抽屉，元信息网格+消息 pre+原始 JSON pre，前后导航+ESC/遮罩关闭
- `LogViewer.tsx` — 行 hover 高亮 + onClick → 打开详情抽屉
- `types-traces.ts` — LogEntry +id + LogDetailResponse 新类型
- `client.ts` — +getLogById(id) 方法
- `test_api_logs.py` — +7 tests（单条获取/导航/末条/畸形/越界404/零号404/列表含id）

**设计原则**：
- 行号即 ID — JSON Lines 文件追加写入，行号天然稳定且唯一
- 内部 dict 存 str(id)，LogEntry 构造时显式 int 转换 — mypy strict 相容
- 抽屉模式 — 不遮挡列表，支持前后导航无缝浏览日志上下文
- 契约兼容 — LogEntry.id 新增字段，旧字段不变，L3 快照 58/58 ✅

---

## Phase 1000 Batch 47 — 可观测性 F9 压缩统计 API 🆕

> 战略定位：压缩日志 tab 后端数据源。新增 GET /metrics/compression 聚合 ledger + pipeline_trace 双源。
> 最后更新: 2026-07-02

| Batch | 域 | 内容 | 文件 | 风险 | 状态 |
|:---:|------|------|:---:|:---:|:---:|
| **B47** | 可观测性 | F9 压缩统计 API（GET /metrics/compression + CompressionStatsResponse） | 3 | 低 | ✅ |

**B47 交付物**：
- `api/schemas.py` — 新增 CompressionStatsResponse（session_compression_count / session_tokens_saved / session_prompt_tokens / session_completion_tokens / historical_compression_count）
- `api/routers/metrics.py` — 新增 GET /metrics/compression 端点（ledger 当前会话 + pipeline_trace 历史聚合）
- `test_api_metrics.py` — +4 tests（empty / ledger-only / historical-only / both-sources）

**设计原则**：
- 双数据源 — ledger 提供当前会话实时数据（compression + compression_savings call_point），pipeline_trace 提供历史持久化计数
- 不修改引擎 — compress_message() 当前未接入管线，trace 存储是独立工程决策。API 已查询 pipeline_trace，未来接入后自动可见
- B48 前端面板消费此端点，完成压缩日志 tab 闭环

## Phase 1000 Batch 48 — 可观测性 F9 压缩日志前端面板 🆕

> 战略定位：可观测性页面最后一个占位 tab → 全功能可用。后端 B47 已就绪，B48 拉通前端面板完成 F6-F9 四问题闭环。
> 最后更新: 2026-07-02

| Batch | 域 | 内容 | 文件 | 风险 | 状态 |
|:---:|------|------|:---:|:---:|:---:|
| **B48** | 可观测性 | F9 压缩日志前端面板（CompressionLogPanel + ObserveShell 接线） | 6 | 低 | ✅ |

**B48 交付物**：
- `frontend/src/lib/api/types-traces.ts` — 新增 CompressionStatsResponse 类型（镜像后端 Pydantic schema，5 fields）
- `frontend/src/lib/api/types.ts` — re-export CompressionStatsResponse
- `frontend/src/lib/api/client.ts` — 新增 getCompressionStats() 方法
- `frontend/src/components/observability/CompressionLogPanel.tsx` — 新建面板（fetch → DataState → 5-card grid + 事件列表占位）
- `frontend/src/components/observability/ObserveShell.tsx` — 替换 compression tab 占位为 CompressionLogPanel，移除 PlaceholderTab
- `frontend/src/__tests__/components/CompressionLogPanel.test.tsx` — +8 tests（loading / 5 stats cards / error / retry / refresh / placeholder / all-zero）

**设计原则**：
- DataState 三态统一 — loading / error(success) 与可观测性其他面板一致，零新增模式
- 事件列表占位 — 后端当前只返回聚合统计（不含 per-event 列表），面板显示 stats 卡片 + "后续批次交付"占位
- RefreshButton 复用 — 使用共享组件的 bordered variant，aria-label 可访问性完备

**F6-F9 四问题收官总结**：
| 问题 | 内容 | 批次 | 类型 |
|:---:|------|:---:|:---:|
| F6 | 仪表盘升级（Token 消耗 + 步骤延迟卡片） | B45 | 纯前端 |
| F7 | 日志详情（GET /logs/{id} + LogDetailModal） | B46 | 全栈 |
| F8 | Trace tab 激活（PipelineTracePanel 接线） | B45 | 纯前端 |
| F9 | 压缩日志（API + 前端面板） | B47 + B48 | 全栈 |

可观测性页面从 50% 占位 → 4/4 tab 全功能可用。**四问题 4 批（B45-B48）零前端回归，1270 tests 全绿。**

## Phase 1000 Batch 49-53 — U20 知识图谱 ECharts 迁移 🆕

> 战略定位：SVG → R3F 3D → ECharts 2D，三次迭代落地最优方案。
> 最后更新: 2026-07-02

| Batch | 域 | 内容 | 文件 | 风险 | 状态 |
|:---:|------|------|:---:|:---:|:---:|
| **B49** | 依赖 | 安装 three/R3F/drei/d3-force-3d | 4 | 低 | ✅ |
| **B50** | 引擎 | useForceGraph hook (d3-force-3d 仿真 + 类型声明) | 2 | 中 | ✅ |
| **B51** | 可视化 | KnowledgeGraphScene R3F Canvas 3D 力导向图 | 2 | 中 | ✅ |
| **B52** | 质量 | 测试修复 + 视觉升级（度数色板+贝塞尔曲线） | 3 | 中 | ✅ |
| **B53** | 重构 | R3F→ECharts 2D 迁移 + 主题配色修复 | 2 | 中 | ✅ |
| **B54** | 文档 | U20 知识图谱文档闭环 | 4 | 低 | ✅ |

## Phase 1000 Batch 55 — HMR WebSocket 127.0.0.1 origin 阻止修复 🆕

> 安全配置：Next.js v15.2.2+ `allowedDevOrigins` 白名单补齐。
> 最后更新: 2026-07-03

| Batch | 域 | 内容 | 文件 | 风险 | 状态 |
|:---:|------|------|:---:|:---:|:---:|
| **B55** | 安全配置 | `next.config.ts` 新增 `allowedDevOrigins: ["localhost", "127.0.0.1"]` | 1 | 低 | ✅ |
| **B54** | 文档 | 文档闭环（requirements/roadmap/architecture/memory 四同步） | 4 | 低 | ✅ |

**B53 交付物**：
- `KnowledgeGraphScene.tsx` — ECharts 2D 力导向图（零 3D 依赖，~260 行）
- 移除 5 个废弃包：`three`, `@react-three/fiber`, `@react-three/drei`, `d3-force-3d`, `echarts-for-react`
- 删除 `useForceGraph.ts` + `d3-force-3d.d.ts`（代码净减少 1,079 行）
- **配色独立 GraphColors 色板**：客体 teal `#0d9488`/`#2dd4bf` 替代 sky-blue，节点标签近黑/近白 max 对比度
- **置信度筛选器**：range 滑块 0-100% 过滤低置信度边 + 孤立节点
- **`useIsDarkTheme` hook 抽取**：Scene + Panel 共享 MutationObserver
- `KnowledgeGraphPanel.tsx` 图例色 + 摘要同步筛选状态

**U20 总结**：三次迭代（SVG 二分 → R3F 3D → ECharts 2D），ECharts 方案零 3D 依赖、主题自适应、代码轻量（净 -1,079 行）。B54 文档闭环完成，U20 知识图谱全量交付（6 Batch: B49-B54）。

---

## Phase 1000 Batch 56-60 — Shared Module Governance — 工具化 + Critical 模块治理 🆕

> 战略定位：Phase 66 B27 复盘→通用化→全量扫描→框架落地→工具化→模块治理→文档闭环。
> 风险公式：返修成本 = N(消费者数) × K(抽象层数)。13 个 ≥3 消费者模块中 12 个未做 Risk Assessment。
> 最后更新: 2026-07-03

| Batch | 域 | 内容 | 文件 | 风险 | 状态 |
|:---:|------|------|:---:|:---:|:---:|
| **B56** | 工具 | `tools/check_shared_modules.py` — 机械防呆扫描 + `make check-docs` 集成 | 2 | 低 | ✅ |
| **B57** | 治理 | `api/schemas.py` Risk Assessment — 82 Model · 12 路由消费者 · 数据模型 5 层 | 1+doc | 低 | ✅ |
| **B58** | 治理 | `src/config.py` Risk Assessment — 83 字段 · 28 文件消费者 · 配置 5 层 | 1+doc | 低 | ✅ |
| **B59** | 治理 | `src/memory/store.py` Risk Assessment — 58 方法 · 22 文件消费者 · 存储 5 层 | 1+doc | 低 | ✅ |
| **B60** | 文档 | 复盘 + 文档闭环 + L5 拉通 — requirements/roadmap/pitfalls/lessons-learned 四同步 | 4 | 低 | ✅ |

**B56 交付物**：
- `tools/check_shared_modules.py` — 消费者扫描 + Risk Assessment 交叉检查 + 风险等级报告
- `Makefile` — `check-docs` + `check-all` 集成
- 首次运行生成 13 个模块 baseline，🔴 Critical 无 RA → exit 1

**B57-B59 交付物**：每模块 Consumer Impact Analysis + Abstraction Layer Enumeration + Consumer Surface Map → requirements-log。三批合计覆盖 50 消费者（schemas 14 + config 28 + store 22）· 15 个抽象层（数据模型 5 + 配置 5 + 存储 5）· 16 项发现（schemas 5 + config 6 + store 10（含 B59 当场修 3 项））。

**B60 交付物**：
- LRN-2026-055: Shared Module Governance 框架落地——个案→通用化→全量扫描→工具化→模块治理→闭环六阶段路径
- LRN-2026-056: renderMarkdown 12 次返修跨五层案例——"打错层"反模式 + 三层诊断方法论
- L5 拉通 B58+B59（累积 2 批，L5 计数器已复位）
- requirements-log.md / roadmap.md / lessons-learned.md 全更新
- .contract-snapshot.json 更新（session_id 签名变更）
- 🔴 embed.py（11 consumers）缺 Risk Assessment → 登记为 I-118 待办

---

## Issue I-118 — embed.py Risk Assessment 🆕（已迁移）

> ⚠️ 待办项已迁移至 [`docs/master-backlog.md`](master-backlog.md) — 活跃待办看板 P0 段。
> 战略定位：B56-B60 覆盖了 4 个 Critical 模块中的 3 个（schemas.py/config.py/store.py）。embed.py（11 consumers · 嵌入模型品类）为遗漏的第 4 个 🔴 Critical 模块——`check_shared_modules.py` 持续报告 1 个 Critical 缺 RA。B60 复盘时确认为已知 gap 并登记。
> 最后更新: 2026-07-03

| Batch | 域 | 内容 | 文件 | 风险 | 状态 |
|:---:|------|------|:---:|:---:|:---:|
| **I-118** | 治理 | `src/embed.py` Risk Assessment — 11 consumers · 嵌入模型品类 5 层 | 1+doc | 低 | ⬜ |

---

## Issue B61-B63 + I-100-I-107 — RA 发现治理 Backlog ✅（已迁移）

> ⚠️ 待办项已迁移至 [`docs/master-backlog.md`](master-backlog.md) — 活跃待办看板。此处仅保留已完成项记录。
> 战略定位：B57（schemas.py）+ B58（config.py）Risk Assessment + pitfalls.md 全局扫描共产出 12 项关注事项。每项发现 = 默认待办，不等"下次碰到再说"。
> 原则：低成本项当场修（≤2 文件改动），中高成本项排入 backlog，按严重度降序执行。
> 最后更新: 2026-07-03

| Batch | 来源 | 发现 | 严重度 | 修复复杂度 | 状态 |
|:---:|------|------|:---:|:---:|:---:|
| **B61** | B57-5 | `ErrorCode` plain class → StrEnum 迁移 — 9 个错误码无类型安全 · 无枚举自省 · 拼写错误运行时才暴露 | 🟠 | 低 | ✅ |
| **B61** | B58-5 | 3 个 CDN URL 常量零引用清理 — REMIX_ICON_CDN/MERMAID_CDN/VIS_NETWORK_CDN 假代码 | 🟡 | 极低 | ✅ |
| **B62** | B58-1 | 13 个 feature flag 审计 trail — `check_shared_modules.py` 增强：检测 feature flag 变更 → 打印消费者影响范围 | 🔴 | 中 | ✅ |
| **B63** | B58-4 | `Settings.__post_init__` 验证 — 非法值组合静默拦截（tier 阈值反转/预算超出/负值） | 🟠 | 中 | ✅ |
| **I-100** | B58-6 | 四支柱 38 字段按 phase 拆嵌套 dataclass — PlannerSettings/TierSettings/ConsolidationSettings 等 | 🟢 | 高 | ⬜ |
| **I-101** | B57-1 | `RecallItem` 双用途模型拆分 — episode 特有字段 + fact 特有字段分离，extra="allow" 收窄 | 🔴 | 高 | ⬜ |
| **I-102** | B57-3 | `dict[str, object]` × 8 → TypedDict 或子模型替换 — 无 schema 约束的消费者协议 | 🟠 | 高 | ⬜ |
| **I-103** | B58-2 | `settings.extra: dict[str, object]` → TypedDict 约束 — 隐式全局状态通道审计 + 收窄 | 🟠 | 中 | ✅ B71 |
| **I-104** | B57-4 | `from_attributes=True` × 4 — ORM→Pydantic 字段映射测试覆盖补齐 | 🟡 | 低 | ⬜ |
| **I-105** | B58-3 | Lazy import TOCTOU 文档化 — 当前无实际触发路径（profile switch 仅启动阶段），标注为已知限制 | 🟡 | 低 | ⬜ |
| **I-106** | B57-2 | `lambda_` alias 文档化 — Python 保留字 workaround，前后端字段名不一致已知限制 | 🟡 | 低 | ⬜ |
| **I-107** | pitfalls | `OverflowSandboxPanel.getCellStatus` 前缀匹配误标 — 后端截断 20 字符 vs 前端 15 字符前缀不匹配，格式标记/换行差异致丢弃项误归为摘要 | 🟢 | 低 | ⬜ |

---

## Issue I-108-I-117 — B59 store.py RA 发现治理 Backlog ✅（已迁移）

> ⚠️ 待办项已迁移至 [`docs/master-backlog.md`](master-backlog.md) — 活跃待办看板。此处仅保留已完成项记录。
> 战略定位：B59（store.py）Risk Assessment 共产出 10 项关注事项。每项发现 = 默认待办。
> 原则：低成本项当场修（≤2 文件改动），中高成本项排入 backlog，按严重度降序执行。
> 最后更新: 2026-07-03

| Batch | 来源 | 发现 | 严重度 | 修复复杂度 | 状态 |
|:---:|------|------|:---:|:---:|:---:|
| **B59** | B59-3 | `delete_episodes_by_session` 显式事务包裹 — 4 表级联删除添加 BEGIN/COMMIT/ROLLBACK 保护 | 🟠 | 极低 | ✅ |
| **I-108** | B59-1 | `session_boundary.py` 6 处 `conn.execute()` bypass + `api/routers/memory.py` 2 处 `_db.execute()` bypass — 公共 API 缺失补充 | 🔴 | 中 | ⬜ |
| **I-109** | B59-2 | `update_fact_confidence` 返回值增强 — `None`→`tuple[float, float]`（before, after），消除 `api/routers/memory.py` bypass | 🟠 | 中 | ⬜ |
| **I-110** | B59-4 | 读路径类型安全 — `list[dict[str, object]]`→TypedDict/NamedTuple，至少 Episode/Fact 高频方法先行 | 🔴 | 高 | ⬜ |
| **I-111** | B59-5 | `_migrate()` 内部 import Triple 提取 — 移到模块顶部或 TYPE_CHECKING | 🟡 | 极低 | ⬜ |
| **I-112** | B59-6 | schema.sql 与 `_migrate()` 交叉验证 — 自动化测试对比两处列默认值一致性 | 🟠 | 低 | ⬜ |
| **I-113** | B59-7 | Schema versioning — 添加 `schema_version` 表 + 版本号追踪 + 迁移顺序保证 | 🟠 | 中 | ⬜ |
| **I-114** | B59-8 | WAL 模式启用 + 连接池评估 — `PRAGMA journal_mode=WAL` + 读写分离可行性 | 🟡 | 低 | ⬜ |
| **I-115** | B59-9 | 空值语义统一 — `get_plan`→None·`get_latest_plan`→None·`list_plans`→[] 三态归一 | 🟡 | 低 | ⬜ |
| **I-116** | B59-10 | FK ON DELETE CASCADE — schema.sql 4 条外键关系添加级联删除声明 | 🟡 | 低 | ⬜ |
| **I-117** | B59 | `_migrate()` 迁移原子性 — 单次 `_migrate()` 调用包裹在 BEGIN/COMMIT/ROLLBACK 中 | 🟠 | 极低 | ⬜ |

---

## Phase 66 — UI/UX 升级 (五页全面交付 · 总² 拉通完成 · 2026-07-08 溯源落地)

> **缘起**（2026-07-01）：用户决策从"内容丰实"转向"质量提升"。核心论点——"当前 UI 拿不出手，没人看内容，内容准确性就没有 ROI。UI 优化过程中逐个过组件、逐条读文案，问题自然暴露。看着舒服有天花板，不是无底洞。"
>
> **战略定位**：美观大气、简单易用——不苛求酷炫，达到商业化标准即可。六维度评估（视觉一致性/交互完整性/排版节奏/状态覆盖/布局稳定性/易用性），总分总执行。
>
> **执行策略**：
> ```
> 总¹ 全局基础（B1-B3）→ 分 逐页面（AI 收集问题清单 → 用户补充 → 汇总统筹 → 拆 Batch）→ 总² 拉通复查
> 页面优先级：Chat → Learn → Lab → Observability → Profile
> ```
>
> **实际进度**：五页全面交付。总¹（B1-B3）✅ · Chat（B4-B27 + B98-B106）✅ 深度打磨 · Learn（B55-B69）✅ a11y/搜索/阅读增强/侧栏/章序号 · Lab（B71-B96）✅ 上下文Tab/管线Tab/DataTab/ExperimentTab · Observability（B71-B74）✅ 扫描修复 · Profile（Phase 1000 B112-B113 + Phase 66 B107-B109 + B112）✅ 治理段 + 空态/四态/StatBadge + hover 增强。B110-B112 产品走查修复段闭环：ARIA tab 全链路 (B110+B111) + Profile 标签云 hover (B112) + L5 拉通 ✅。B119 移动端侧边栏 slot 线程 ✅。B120 移动端 QuestionList 精简 ✅。B121 总² 启动 ✅ — 过渡 token 标准化（7 文件 10 处硬编码 → `var(--gm-duration-*)`）+ 全站四态扫描排 B122-B125。B122 UI 共享组件四态补齐 ✅（8 文件 14 处）· B123 Observability + Layout 四态补齐 ✅（7 文件 21 处）· B124 Lab 面板四态补齐 ✅（12 文件 ~26 处）· B125 Learn 四态收尾 ✅（6 文件 ~34 处）。总² 拉通复查 ✅ — 四态补齐 33 文件 ~109 处 + 微交互过渡系统化 + B122-B125 L5 拉通。
> 最后更新: 2026-08-08
>
> ⚠️ **Phase 66 永不关闭**：UI/UX 优化是持续过程，非用户明确声明关闭则保持活跃。新增 UI/UX 类 Batch 归入此 Phase，不另建新 Phase。

### Phase 66 Batch 1 — 总¹ 全局基础 ✅

| # | 严重度 | 问题 | 改动文件 | 状态 |
|:--:|:--:|------|---------|:--:|
| 17 | 🔴 | 品牌统一 — Header/Footer/Sidebar 品牌文案去重 | Header.tsx · Footer.tsx · Sidebar.tsx | ✅ |
| 5 | 🟡 | :active 全局基类 — 可交互元素按下态反馈 | components.css | ✅ |
| 10 | 🟡 | Nav 链接 :active 反馈 — 桌面+移动端导航按下态 | navLinks.ts | ✅ |
| 12 | 🟡 | Footer 源码链接修复 — github.com → Gitee 项目仓库 | Footer.tsx | ✅ |
| 14 | 🟢 | Header 副标题中文前置 — 中文在前英文在后 | Header.tsx | ✅ |
| 15 | 🟢 | AppShell inline style → components.css | AppShell.tsx · components.css | ✅ |

**品牌文案**：统一为「逐层解剖 AI Robot 工作原理 — See How AI Remembers, Thinks, and Plans」
- Header 副标题：中文前置 · 英文在后
- Footer：简版（品牌行）
- Sidebar 关于：完整版（四维度展开）

**验证**：tsc 0 · eslint 0 · vitest 1261 pass · Python 1246 pass · check-docs ✅

### Phase 66 Batch 2 — 排版 + 布局 + 品牌收拢 ✅

| 改动 | 文件 | 说明 |
|------|------|------|
| Header 排版升级 | `Header.tsx` | 副标题 `text-center` → `text-left` + `ml-[2rem]` 锚定到 Logo 正下方 + `mt-gm-1` → `mt-gm-2` |
| Footer 拉通全宽 | `Footer.tsx` | `lg:col-start-2` → `lg:col-start-1 lg:col-span-2` + 内部 `lg:pl-[var(--spacing-sidebar-w)]` 内容对齐主列 |
| Footer 品牌增强 | `Footer.tsx` | 新增版本号 `v0.1.0` + `GlassCortex` 加 `font-medium text-text` 强化 |
| Sidebar 品牌去重 | `Sidebar.tsx` | 删除顶部项目身份块（icon+名称+版本号）+ 底部"关于"段 |
| 品牌收拢 | 全局 | GlassCortex 品牌仅 Footer 一处 — 全宽背景条 + 左对齐内容 + 完整信息 |

**去重效果**：Sidebar 删 RiBrainLine · RiInformationLine · CollapsibleSection 3 个引用，净删 ~20 行。

**验证**：tsc 0 · eslint 0 · vitest 1259 pass · Python 1246 pass · check-docs ✅

### Phase 66 Batch 3 — Sidebar 内容区七层重排 ✅

| 变更 | 说明 |
|------|------|
| 区块重排 | 10 区块从无序堆叠 → 七层递进（身份→状态→认知→收获→调节→管理→系统） |
| 层间分隔 | 6 条 `<hr>` 视觉分隔，每层加注释标注 |
| 测试修复 | mock 顺序适配新渲染序（ProfileCard → SidebarReflectionCard → SessionHarvest） |

**新顺序**：ProfileCard → 本次会话统计 + TokenGauge → ModelRoutingCard + ReflectionCard → SessionHarvest → 认知参数 + ParamReplay → 重置数据 → 系统状态

**验证**：tsc 0 · eslint 0 · vitest 1259 pass · Python 1246 pass

### Phase 66 Batch 4 v2 — FourPillar 完全重写 ✅

**交付**：v1 三问题（字体层级跳跃 + SVG 弧线脆弱 + 展开面板数据 dump）→ 完全重写。

**COLLAPSED 状态**：四张干净卡片 centered 布局，icon + metric + label + subtitle 四行，`title` 属性 hover tooltip。移除 SVG 弧线、badge 芯片、accent bar、description 文字。Typography 统一三个字号（text-gm-lg / text-gm-xl / text-gm-2xs）。

**EXPANDED 状态 — 视觉化详情**：
- Memory → Episode/Fact 标签卡片（左侧 2px 色条 + content + recall_reason）
- Context → CSS 进度条（容量使用）+ StatPills（策略/记忆/溢出）
- Token → 堆叠柱状图（prompt vs completion 比例）+ StatPills（模型/耗时/合计）
- Planning → SVG 置信度环（stroke-dasharray 动画）+ category + rationale

**四支柱流程图**（所有展开面板底部共享）：
- 4 步 CSS 水平流向节点（当前高亮 + 彩色圆点）
- 箭头连接符（`→` 字符）
- 底部虚线反馈循环（`border-t dashed`）

**删除组件**：CrossDependencyArcs · CrossDependencyBadges · KVRow · 旧版 4 个 Detail 组件
**新增组件**：PillarCard(重写) · MemoryVisualDetail · ContextVisualDetail · TokenVisualDetail · PlanningVisualDetail · PillarFlowChart · StatPill

**修改文件**：`FourPillar.tsx` (全量重写 ~420→~380 行) · `FourPillar.test.tsx` (36→34 tests)
**验证**：tsc 0 · eslint 0 · vitest 1274 pass（FourPillar 34/34）

### Phase 66 Batch 5 — 四支柱统一入口 ✅

**交付**：ChatMessage 按钮行瘦身（9→4 按钮 → 最终 3 按钮）+ 四支柱详情内化为 JourneyCards 展开能力。

**按钮行演进**：
- 原：9 个独立功能按钮（消息旅程 · 对话历史 · 洋葱面板 · 记忆设计 · 上下文工程 · Token 效率 · 任务规划 · 四支柱全景 · 深度抽屉）
- Batch 5 初期：瘦身至 4（消息旅程 · 对话历史 · 洋葱面板 · 四支柱）
- Batch 6 最终：瘦身至 3（消息旅程 · 对话历史 · 洋葱面板），四支柱合并入消息旅程

**修改文件**：`ChatMessage.tsx`（按钮行重排）· `FourPillar.tsx`（详情组件导出供 JourneyCards 复用）

**验证**：tsc 0 · eslint 0 · vitest pass

### Phase 66 Batch 6 — JourneyCards + FourPillar 统一 ✅

**交付**：JourneyCards 吸收 FourPillar 的展开详情能力——六卡片点击展开时内化四支柱视觉详情组件（PlanningVisualDetail / MemoryVisualDetail / ContextVisualDetail / TokenVisualDetail），彻底去重合并。FourPillar 从 ChatPanel 移除，仅作为视觉详情组件导出方存在。

**卡片→详情映射**：理解→PlanningVisualDetail · 召回→MemoryVisualDetail · 组装→ContextVisualDetail · 花费→TokenVisualDetail · 回复→ReplyDetail · 记忆→MemoryStorageDetail

**修改文件**：`JourneyCards.tsx`（+209 行展开详情逻辑）· `ChatMessage.tsx`（移除 FourPillar 按钮）· `ChatPanel.tsx`（移除 FourPillar 渲染）

**验证**：tsc 0 · eslint 0 · vitest 1257 pass

### Phase 66 Batch 6 续 — 消息旅程卡片美化 ✅

**设计方向**：简约大气 — 去装饰化、增呼吸感、提品质感。

**卡片（JourneyCard）**：
- 砍掉顶部渐变 accent bar → 2px 彩色左边框（`borderLeft`），视觉噪音降低但保留身份色
- 砍掉 `gm-card-lift` 悬浮跳升 → 柔和 `hover:border-border hover:shadow-gm-xs` 过渡
- 砍掉 `uppercase tracking-wider` → 普通大小写 `font-medium`
- "详情 ▼" 文字 → `RiArrowDownSLine` 图标，展开时旋转 180°
- 指标字号：`text-gm-2xl font-extrabold` → `text-gm-xl font-bold`
- 新增 `line-clamp-2` 防止长文本撑破卡片

**展开详情面板（ExpandedDetailPanel）**：
- 砍掉彩色圆点 + 底部分隔线 → 彩色左边框统一视觉语言
- 关闭按钮：`rounded-gm-sm` → `rounded-full`

**StatPill 升级**（ReplyDetail/MemoryStorageDetail/StatPill）：
- 字号：`text-gm-2xs` → `text-gm-xs` · 新增 `bg-surface` 底色
- 边框：`border-border/60` → `border-border/40`
- 内边距：`px-gm-2 py-gm-1` → `px-gm-2_5 py-gm-1_5`

**记忆条目（MemoryVisualDetail）**：
- 从"细左边条 + 无背景" → 软卡片（`bg-surface`、`rounded-gm-sm`、`border-border/40`）
- 标签中文化：`Episode`/`Fact` → `对话片段`/`事实`

**进度条（Context/Token）**：纯色 → 渐变色（`linear-gradient`）+ `duration-gm-slow` 过渡

**修改文件**：`JourneyCards.tsx`（JourneyCard + ExpandedDetailPanel + ReplyDetail + MemoryStorageDetail 四组件重设计）· `FourPillar.tsx`（StatPill + MemoryVisualDetail 重设计 + Context/Token 进度条渐变）· `FourPillar.test.tsx`（测试文案同步）

**验证**：tsc 0 · eslint 0 · vitest 1257 pass（84 files）· Python 1246 pass

### Phase 66 Batch 7 — Markdown 渲染共享引擎 ✅

**交付**：`renderMarkdown()` 统一渲染管线 — 从 `marked` 解析 → DOMPurify 净化 → 自定义 `marked.Renderer` 扩展（Mermaid 占位符 + 视频/音频标签）。ChatMessage 消息气泡接入，`dangerouslySetInnerHTML` 替代裸 `<p>` 渲染。

**支持语法**：标题 h1-h6 · 粗体/斜体 · 行内代码 · 代码块 · 无序/有序列表 · 引用块 · 链接 · 图片 · 表格 · Mermaid 流程图

**修改文件**：`renderMarkdown.ts`（新）· `ChatMessage.tsx`（Markdown 渲染接入 + Mermaid hydration 生命周期）

**验证**：tsc 0 · eslint 0 · vitest 1278 pass

### Phase 66 Batch 8 — 多模态渲染 ✅

**交付**：图片（点击 lightbox 全屏 + backdrop 模糊 + 四角按钮关闭 + ESC 关闭）· Mermaid hydration（createRoot → MermaidDiagram 组件渲染）· 视频/音频（HTML5 `<video>` / `<audio>` 标签）· 表格（responsive 横向滚动容器 + 斑马纹 `<tbody>` + 对齐感知 colgroup）

**修改文件**：`ChatMessage.tsx`（lightbox 状态管理 + Mermaid roots Map + ESC 监听）· `components.css`（`.chat-prose` 范围样式 — lightbox/mermaid/table/video/audio）

**验证**：tsc 0 · eslint 0 · vitest 1282 pass

### Phase 66 Batch 9 — Chat 页剩余项闭环 ✅

**范围**：Chat 页审计 18 项中剩余 11 项一次性闭环。原 B8/B9/B10 三批合并执行——避免跨批文件冲突。

| # | 组件 | 修复 | 类型 |
|:--:|------|------|:--:|
| C2 | OnionPanel | `bg-bg-accent/10` → `bg-accent/10` | 🔴 未定义 token |
| C3 | OnionPanel | `border-t border-border-subtle` → `border-t border-border-light` | 🔴 未定义 token |
| C4 | OnionPanel | `text-gm-3xs` → `text-gm-2xs` | 🔴 未定义 token |
| C17 | OnionPanel | RecallItemRow 按钮 +focus-visible ring + active 态 + cursor-pointer | 🟡 交互四态 |
| C5 | JourneyHistoryBrowser | 20+ inline style → Tailwind 工具类（text-text-muted/text-text/text-accent/bg-bg-subtle） | 🟡 反模式 |
| C9 | JourneyHistoryBrowser | 搜索框 +focus-within ring | 🟡 缺 focus ring |
| C10 | JourneyHistoryBrowser | 清除按钮 + 行按钮 +focus-visible ring + cursor-pointer | 🟡 交互四态 |
| C15 | JourneyHistoryBrowser | 冗余 `text-gm-icon` + `style={{color}}` → `text-accent text-gm-icon` | 🟢 视觉冗余 |
| C6 | ChatMessage | 三按钮（消息旅程·对话历史·洋葱面板）+focus-visible ring + cursor-pointer | 🟡 交互四态 |
| C7 | ChatInput | 发送按钮 +active:scale-[0.98] | 🟡 缺 active 态 |
| C11 | ChatInput | textarea +hover:border-text-muted + disabled:cursor-not-allowed | 🟡 交互四态 |
| C12 | ChatInput | 发送按钮 disabled:cursor-wait（loading 态） | 🟡 缺 loading 光标 |
| C8 | ChatPanel | 快捷提问按钮 +focus-visible ring + active:scale-[0.98] + cursor-pointer | 🟡 交互四态 |
| C13 | ChatPanel | 特性卡片移除 gm-card-lift（不可交互元素误暗示可点击） | 🟢 误导 affordance |
| C16 | ChatPanel | Learn 链接 +focus-visible ring | 🟢 缺 focus ring |

**JourneyHistoryBrowser 重构细节**：
- 所有 `style={{ color: "var(--gm-*)" }}` 替换为 Tailwind 工具类
- 搜索框 wrapper 从 `style={{ background }}` → `bg-bg-subtle` class + `focus-within:ring-2`
- 展开详情 grid 内 16 处 `<span>/<p>` inline style → `text-text-muted` / `text-text` class
- "为什么召回这条" 分隔线 `border-t border-border-subtle` → `border-t border-border-light`

**修改文件**：`OnionPanel.tsx` · `JourneyHistoryBrowser.tsx`（全量重写）· `ChatMessage.tsx` · `ChatInput.tsx` · `ChatPanel.tsx`

**验证**：tsc 0 · eslint 0 · vitest 1282 pass（85 files）· Chat 页 18/18 ✅

**下一站**：Phase 66 Batch 10 — Chat 收尾（ProcessDrawer + 交叉扫描 → 按粒度拆批）

---

### Phase 66 L5 拉通修复 — 组件树遗漏 ✅

**发现**：B9 修复仅覆盖 OnionPanel.tsx 直接文件，未追踪子组件（ContextualLens ×4 · ModelInferencePanel ×1 · CacheHitIndicator ×1），导致 6 个交互元素遗漏 focus-visible ring + cursor-pointer。

**修复文件**：`OnionPanel.tsx` · `ContextualLens.tsx` · `ModelInferencePanel.tsx` · `CacheHitIndicator.tsx` · `ContextualLens.test.tsx`

**验证**：tsc 0 · eslint 0 · vitest 1282 pass · check-theme 5 路由 0 错误

**流程落地**：CLAUDE.md 新增协作纪律 18「组件树深度检查」· methodology.md 新增 L2f 检查清单 · lessons-learned.md LRN-2026-051

---

### Phase 66 renderMarkdown 代码块 CRLF 修复 ✅

**问题**：AI 回复中的 `\`\`\`html` 代码块未渲染，用户看到裸 Markdown 标记。根因：正则 `/`\`\`(\w*)\n/` 在 `\r\n`（Windows 换行）和语言标签后跟空格两种边界条件下失配。

**修复**：首行 `\r\n` → `\n` 归一化 + 两处正则加 `\s*` 容错 + 4 边界测试。

**验证**：tsc 0 · eslint 0 · vitest 1286 pass (+4 tests)

---

### Chat 页深度审计 — 7 Batch 排期（B11-B17）

> 27 项审计问题（3 用户直报 + 9 严重 + 15 中等），按优先级拆为 7 Batch。

| Batch | 范围 | 关键技术点 | 状态 |
|:--:|------|------|:--:|
| **B11** | 代码块渲染升级 | Prism.js 集成 + CopyButton + CSS 行号 | ✅🔧 |
| B12 | 流程图 Lightbox 全屏化 | ImageViewer 100vw×100vh + z-index 升级 + click-to-close | ✅ |
| B13 | 键盘交互 + 取消/停止 | Enter=换行/Shift+Enter=发送 + abort 按钮 | ✅ |
| B14 | 聊天基础体验 | 自动滚底 + aria-live + 清除对话 | ✅ |
| B15 | 无障碍横扫 | Drawer 焦点陷阱 + 9 组件 aria + WelcomeView | ✅ |
| B16 | Markdown 引擎 + 主题 | h1/h2/h4 + 嵌套列表 + 硬编码色→token | ✅ |
| B17 | 打磨收尾 | 时间戳 + 加载区分 + ContentPreloader + 响应式 | ✅ |
| **合计** | **7 Batch** | **Chat 页 27 项审计全量闭环** | **🎉** |

### Phase 66 Batch 11 — 代码块渲染升级 ✅

**需求**：Chat/Learn 页代码块无语法高亮、无行号、无复制按钮。集成 Prism.js（轻量），对齐现有 mermaid hydration 模式（useEffect DOM 增强）。

**变更**：
- **新增** `src/lib/prism.ts` — Prism 核心 + 9 语言语法（JS/TS/Python/Bash/JSON/CSS/HTML/YAML/SQL）+ line-numbers 插件
- **新增** `src/hooks/useCodeHighlight.tsx` — 自定义 hook（useEffect DOM query → Prism.highlightElement() → 行号 class → createRoot 挂载 CopyButton）
- **修改** `ChatMessage.tsx` — 接入 useCodeHighlight(contentRef, [message.content])
- **修改** `AnswerCard.tsx` — 接入 useCodeHighlight(articleRef, [answer.l1, answer.l2, answer.l3])
- **修改** `layout.tsx` — 引入 prism-line-numbers.css
- **修改** `components.css` — 新增 Prism token 色映射（→`--gm-*`）+ 复制按钮定位（hover 显示）+ 行号样式
- **修改** `package.json` — 新增 `prismjs` + `@types/prismjs`
- **测试** renderMarkdown.test.ts +1 test（class="language-xxx" 兼容验证）

**验证**：tsc 0 · eslint 0 · vitest 1256 pass (~1286 baseline, 1 pre-existing flaky) · check-theme 5 路由 0 errors

**🔧 修复 (2026-07-02)**：Chat 页代码块高亮不生效——根因 `ChatMessage` 缺少 `React.memo`，ChatPanel context 更新触发的重渲染通过 `dangerouslySetInnerHTML` 重置了 Prism DOM mutation。修复：`export default memo(ChatMessage)` 阻止无关重渲染。详见 `docs/pitfalls.md`「React.memo 缺失」+ `docs/lessons-learned.md` LRN-2026-052。

### Phase 66 Batch 12 — 流程图 Lightbox 全屏化 ✅

**需求**：流程图 lightbox 缩放框在 90vw×90vh 容器内，非真正全屏，且 z-index 低于 tooltip（用户直报 U2）。[变更类型: bugfix]

**变更**：`ImageViewer.tsx` 五处 CSS 值修改：

1. `.gm-image-viewer` 背景层 z-index: `--gm-z-modal`(100) → `--gm-z-notify`(110) — 确保高于所有 tooltip/popover/drawer
2. `.gm-iv-close` 关闭按钮 z-index: `calc(--gm-z-modal + 1)` → `calc(--gm-z-notify + 1)`
3. `.gm-iv-svg-layer` 尺寸: `90vw × 90vh` → `100vw × 100vh` — 真正全屏
4. `.gm-iv-svg-layer` + `.gm-image-viewer`: 移除 `overflow: hidden` — 放大后不裁剪平移/缩放内容
5. `.gm-iv-svg-layer` + `.gm-iv-svg-iframe`: 移除 `border-radius` — 全屏状态下圆角无意义
6. `.gm-iv-img` 图片模式: `max-width/max-height: 90vw/90vh` → `100vw/100vh`

**验证**：tsc 0 · eslint 0 · vitest 1287 pass · check-theme 5 路由 0 errors

**🔧 修复 1 (2026-07-02)**: `createPortal(lightbox, document.body)` — 脱离父容器 stacking context / overflow 限制，对齐 ExplainPopover portal 模式 (commit `a115c62`)。Playwright: `parentTag: BODY` · `position: fixed` · `zIndex: 110` · `1280×900 = 视口` ✅

**🔧 修复 2 (2026-07-02)**: 单击关闭替代 zoom toggle — 白色 SVG 背景上看不清关闭按钮，单击图片直接关闭 lightbox。缩放仅通过滚轮/捏合手势 (commit `9d3cd2f`)。

### Phase 66 Batch 13 — 键盘交互 + Abort 停止按钮 ✅

**需求**：Enter 换行 / Shift+Enter 发送（对齐微信/Slack 习惯）+ 发送中可取消生成。[变更类型: enhancement]

**变更**：
- **ChatInput.tsx**: `handleKeyDown` Enter+shiftKey→发送（原 Enter 发送, Shift+Enter 换行交换）· placeholder 更新 · 新增 `onAbort` prop → disabled+onAbort 时显示红色停止按钮（RiStopFill）替代发送中状态
- **useChat.ts**: 新增 `AbortController` ref → `abort()` 取消当前请求 → `sendMessage` 创建 controller 传入 `api.chat(signal)` → AbortError 静默回 idle 不触发 error
- **ChatPanel.tsx**: `useChat` 解构 `abort` → 传给 `ChatInput onAbort`
- **api/client.ts**: `chat()` 新增第二个参数 `opts?: { signal?: AbortSignal }`
- **测试**: ChatInput +2 tests（停止按钮渲染/onAbort 回调）· 3 tests 键盘行为翻转 · ChatPanel 2 tests 键盘行为翻转

**验证**：tsc 0 · eslint 0 · vitest 1293 pass · check-theme 5 路由 0 errors

### Phase 66 Batch 14 — 聊天基础体验 ✅

**需求**：ChatPanel 补齐三项基础体验——新消息自动滚动到底部、屏幕阅读器 aria-live 消息播报、清除对话按钮。[变更类型: enhancement]

**变更**：
- **ChatPanel.tsx**: 新增 `clearMessages` 从 useChat 解构 · 新增 `messagesEndRef` + `useEffect scrollIntoView` 自动滚底 · 消息容器新增 `role="log"` + `aria-live="polite"` + `aria-label="聊天消息"` · 新增清除对话按钮（RiDeleteBinLine + 错误色调 hover + 仅在有消息时显示）· 滚动锚点 `<div ref={messagesEndRef} />`
- **测试**：setup.ts 新增 `scrollIntoView` jsdom polyfill

**验证**：tsc 0 · eslint 0 · vitest 1294 pass · check-theme 5 路由 0 errors

### Phase 66 Batch 16 — Markdown 引擎 + 主题 ✅

**需求**：Markdown 渲染引擎补齐嵌套列表支持 + heading 视觉层级区分 + 硬编码色 token 化验证。[变更类型: enhancement]

**变更**：
- **renderMarkdown.ts**: 新增缩进感知嵌套列表解析（栈算法）— 列表块检测 → indent 解析 → 栈式 HTML 生成 → sentinel 保护绕过 flat regex · 更新文档注释（h1-h6 全 6 级）· +54 行
- **renderMarkdown.test.ts**: +6 测试（2 级嵌套 · 3 级深层 · 混合有序/无序 · 4 空格缩进 · inline markdown · 无嵌套回退）
- **components.css**: h2 字号升级 sm→md + 添加底部 border 分割线（与 h3 视觉分离，形成 h1/md/700 > h2/md/600+border > h3/sm/600 > h4/sm/600/secondary 四级）

**验证**：tsc 0 · eslint 0 · vitest 40/40 pass (+6 tests) · check-theme 5路由 0 errors

### Phase 66 Batch 16 修复 — renderMarkdown 有序列表被 ul 误覆盖 ✅

**问题**：AI 回复中的 `1. xxx / 2. xxx` 有序列表渲染为纯文本而非 `<ol>` 列表。根因：有序 `<li>` 被 `<ol>` 包裹后，无序列表正则 `/(?:<li>.*<\/li>\n?)+/` 再次匹配 `<ol>` 内的 `<li>`，造成 `<ol><ul><li>...</li></ul></ol>` 双包裹。DOMPurify 剥离无效嵌套后列表完全不可见。[变更类型: bugfix]

**修复**：renderMarkdown.ts — `<ol>` 包裹后用 sentinel（`\x00OLn\x00`）保护 → 无序列表处理完 → 还原。13 行保护/还原脚手架 + 2 行核心修复。

**验证**：tsc 0 · eslint 0 · vitest 1294 pass (renderMarkdown 34/34 +1 test) · check-theme 5 路由 0 errors

### Phase 66 Batch 17 — 打磨收尾 ✅

**需求**：Chat 页 7 批审计收官——消息时间戳显示 + 加载状态阶段化 + ContentPreloader 验证 + 移动端响应式打磨。[变更类型: enhancement]

**变更**：
- **useChat.ts**: Message 接口新增 `createdAt: number` 字段（`Date.now()`）— 用户消息和助理消息创建时均记录时间戳
- **formatTime.ts** (新): 中文相对时间格式化工具 — `formatRelativeTime(ts)` → "刚刚"/"1分钟前"/"1小时前"/"昨天"/"3天前"/"6月26日" + 未来时间时钟偏差保护
- **ChatMessage.tsx**: 气泡下方新增时间戳显示（`text-gm-xs text-text-muted` 右/左对齐 + `aria-label` 绝对时间供屏幕阅读器）· 导入 `formatRelativeTime` · 气泡宽度响应式 `max-w-[80%]/[88%]` → +`sm:max-w-[70%]/[80%]`（桌面端稍窄防过度拉伸）
- **ChatPanel.tsx**: 加载状态从单一 "思考中…" 升级为三阶段渐进文案——"正在理解问题…"（0s）→ "正在检索记忆…"（1.5s）→ "正在生成回复…"（3.5s），每阶段带独立 emoji 图标 · 阶段推进通过 `setInterval` 回调驱动（满足 ESLint `set-state-in-effect` 规则）· ContentPreloader 已验证无变更
- **ChatInput.tsx**: 移动端响应式打磨 — 内边距 `p-gm-2 sm:p-gm-3` · 字号 `text-gm-sm sm:text-gm-base` · 初始行数 3→2（移动端更紧凑）· 移除未使用的 `TEXTAREA_INITIAL_ROWS` 常量
- **formatTime.test.ts** (新): 7 条测试覆盖所有时间粒度 + 边界条件（未来时间/时钟偏差）

**验证**：tsc 0 · eslint 0 · vitest 1310 pass (+16 tests) · check-theme 5 路由 0 errors

### Phase 66 Batch 18 — 列表渲染修复：块元素段落隔离 ✅

**问题**：AI 回复中列表前有引导文字时（如 "处理过程拆为四步：\n1. xxx"），`<ol>`/`<ul>` 卡在 `<p>` 内导致列表不渲染。之前 B11/B16 两次修复未触及根因。[变更类型: bugfix]

**根因**：段落包装器 `/\n\n+/g → </p><p>` 只在双换行处拆分。引导文字与列表间仅单 `\n` 分隔时，`<ol>` 与引导文字进入同一 `<p>`。现有清理正则 `/<p>(<ol...)/` 只匹配块元素紧邻 `<p>` 后（`<p><ol>`），不匹配 `<p>text\n<ol>` 中间有文本的场景。**bug 在段落包装阶段，不在列表正则本身。**

**修复**：`renderMarkdown.ts` — 段落包装前新增 2 行：① 块级开放标签前补插 `\n\n`（`([^\n])\n(<(?:ol|ul|table|pre|hr|h[1-6]|blockquote|div))` → `$1\n\n$2`）② 块级闭合标签后对称处理。确保所有块元素在段落拆分阶段被正确隔离。

**测试**：+5 tests — 引导文字+有序列表 · 引导文字+无序列表 · 列表项含 `**bold**` · 无序列表含 `**bold**` · 完整场景（引导+四步+bold）

**验证**：tsc 0 · eslint 0 · vitest 1315 pass (+5 tests) · check-theme 5 路由 0 errors

**经验编号**：LRN-2026-053（见 lessons-learned.md）

### Phase 66 Batch 19 — ConfirmModal 基础组件 ✅

**需求**：替换 `ProfileShell` 中的 `window.confirm()` 为统一确认弹窗组件，为 B22（ChatPanel 清除对话集成）提供可复用基础设施。[变更类型: enhancement]

**变更**：
- **ConfirmModal.tsx** (新): 居中确认对话框 — `isOpen`/`onClose`/`onConfirm`/`title`/`message`/`confirmLabel`/`variant`(danger|default)/`isLoading`/`error` props · Esc 关闭 · 遮罩点击关闭 · 右上角 X 关闭 · loading 时全部禁用 · 自动聚焦确认按钮 · danger 变体红色确认按钮+警告图标 · error 复用 ErrorDisplay
- **ProfileShell.tsx**: `window.confirm` → ConfirmModal — 新增 `deleteTarget`/`deleting`/`deleteError` 三状态 · `handleDelete` 无参数化（从 state 读 `deleteTarget`）· 删除按钮 onClick 改为 `setDeleteTarget(p.name)` · JSX 末尾新增 `<ConfirmModal>` 实例
- **ConfirmModal.test.tsx** (新): 13 tests — 开关/渲染/自定确认文案/取消/遮罩/Escape/确认/loading 禁用/lodaing spinner/error 显示/danger 样式/default 样式/async onConfirm
- **ProfileShell.test.tsx**: 删除测试重构 — `window.confirm` spy → ConfirmModal 交互（点击删除按钮→弹窗出现→点击确认→API调用→弹窗关闭→列表更新）

**验证**：tsc 0 · eslint 0 · vitest 25 pass (13 ConfirmModal + 12 ProfileShell) · `grep -rn "window\.confirm" frontend/src/` 仅 JSDoc 注释

### Phase 66 Batch 20 — Session→Episode 链路 ✅

**需求**：`episodes` 表无 `session_id` 列，episode 不知道自己属于哪个会话。打通 API → Engine → Store 三层 session_id 透传链路，为 B21（Forget API）提供 session 级联删除基础。[变更类型: enhancement]

**变更**：
- **schema.sql**: episodes 表新增 `session_id TEXT` 列（可空，向后兼容）
- **store.py**: `add_episode()` + `session_id` 参数 → INSERT · `_migrate()` 自动迁移旧 DB（`ALTER TABLE ADD COLUMN` + `CREATE INDEX`）· 新增 `get_episodes_by_session(session_id)` 查询 · 新增 `delete_episodes_by_session(session_id)` 级联删除（episodes→facts→recall_log→confidence_log + 收集 faiss_ids 供 FAISS 清理）
- **engine.py**: `store_response()` + `session_id` 参数 → `generate_and_store()` + `session_id` 参数透传
- **api/routers/chat.py**: `generate_and_store()` 调用 +1 行（`session_id=body.session_id or None`，空串→None）
- **tests/test_memory_store.py**: +10 tests — session_id 写入/查询/排序/隔离 · 级联删除（空 session/级联 episodes+facts/recall_log/confidence_log/隔离/target_only/faiss_ids 采集）· 旧 DB 迁移兼容
- **tests/test_engine.py**: +3 tests — store_response/generate_and_store session_id 端到端透传 · 默认 None 向后兼容
- **tests/test_api_chat.py**: 1 test 参数更新（`session_id=None` 加入 mock 断言）

**验证**：make check 全绿（ruff 0 · mypy 0 · pytest 1260 pass (+13 new)）· session_id 透传链路 API→Engine→Store 三跳完整 · _migrate 幂等 · 空串→None 正确转换 · 级联删除不遗漏 · 已有测试全部向后兼容

### Phase 66 Batch 21 — Forget API 后端 ✅

**需求**：B20 已打通 session_id 链路，需 ForgettingEngine 定向遗忘方法 + REST 端点，按 session_id 级联清理 episodes/facts/FAISS 向量。[变更类型: enhancement]

**变更**：
- **forget.py**: `ForgettingEngine.__init__` + 可选 `index: IndexManager | None` 参数（向后兼容）· 新增 `forget_session(session_id)` 方法——调 `store.delete_episodes_by_session()` 完成 SQL 级联删除 → 通过 `IndexManager.remove_faiss_ids()` 清理 FAISS 向量 → 返回 `{episodes_deleted, facts_deleted, faiss_vectors_removed, session_id}`
- **bootstrap.py**: `ForgettingEngine(store)` → `ForgettingEngine(store, idx)` — 注入 IndexManager 使遗忘引擎可清理 FAISS
- **schemas.py**: + `SessionForgetRequest(session_id: str, min_length=1)` · + `SessionForgetResponse(episodes_deleted, facts_deleted, faiss_vectors_removed, session_id)`
- **routers/session.py**: + `POST /session/forget` 端点——从 engines[3] 取 ForgettingEngine → `forget_session(body.session_id)` → 返回统计回执 + 日志记录
- **tests/test_forget.py**: +5 tests — 定向删除计数/其他 session 不受影响/不存在 session 返回零/FAISS 清理调 remove_faiss_ids/空 session 隔离性
- **tests/test_api_session.py**: +5 tests — 200 响应结构/schema 校验/调用引擎/缺少 session_id 422/空 session_id 422

**验证**：make check 全绿（ruff 0 · mypy 0 · pytest 1269 pass (+10 new)）· tsc 0 · eslint 0 · vitest 1328 pass · FAISS 清理路径已验证 · L5 触发待 B22（B19-B22 全链路拉通）

### Phase 66 Batch 22 — 前端清除对话集成 ✅

**需求**：B19 ConfirmModal + B21 Forget API 已交付，前端 ChatPanel"清除对话"按钮需从纯本地清空升级为真正的记忆遗忘触发入口。[变更类型: enhancement]

**变更**：
- **types-memory.ts**: + `SessionForgetRequest` / `SessionForgetResponse` 前端类型
- **types.ts**: 桶导出新增两种类型
- **client.ts**: + `api.forgetSession(body)` → POST /session/forget
- **useChat.ts**: + `sessionIdRef`（mount 时生成 UUID）· `sendMessage` 传 `session_id` · + `forgetSession()` + `forgetResult` 状态
- **ChatPanel.tsx**: "清除对话"按钮 → ConfirmModal（danger variant）→ 确认调 forgetSession → 遗忘摘要横幅（5s 自动消失）
- **useChat.test.ts**: +4 tests（session_id 生成/传递/跨轮稳定 · forgetSession 成功/失败）
- **ChatPanel.test.tsx**: 更新清除流程——弹窗→确认→API→横幅→清空

**验证**：tsc 0 · eslint 0 · vitest 1334 pass (+6) · make check 全绿（pytest 1269）· B19-B22 全链路 L5 拉通

### Phase 66 Batch 23 — IntentPill Rationale 可见化 ✅

**需求**：意图分类理由（rationale）仅通过 `title` 属性 hover 可见，移动端无法查看。在 confidence 旁添加 info 图标 + click-triggered popover。[变更类型: enhancement]

**变更**：
- **IntentPill.tsx**: + `useFloating` / `shift` / `flip` / `offset`（@floating-ui/react）· + `RiInformationLine` info 图标按钮 · + rationale popover（click 展开 · 外部点击/Esc 关闭 · `aria-expanded` + `role="tooltip"`）· 移除 `title` 属性（rationale 不再通过原生 tooltip 暴露）· info 图标 `stopPropagation` 防止冒泡到父 onClick
- **IntentPill.test.tsx**: +7 tests（info 图标渲染/缺席 · click 展开/二次关闭 · 外部点击关闭 · Esc 关闭 · 冒泡阻止）· 更新 title 测试（rationale 有/无两种场景）

**验证**：tsc 0 · eslint 0 · vitest 1342 pass (+8)

### Phase 66 Batch 24 — Drawer 布局偏移修复 ✅

**需求**：body scroll lock padding-right 补偿逻辑缺测试覆盖。补齐测试 + 添加 CSS 自定义属性 `--gm-scrollbar-w` 供 future fixed 元素对齐。[变更类型: test + enhancement]

**变更**：
- **Drawer.tsx**: `acquireBodyLock()` 添加测量时机注释 + `setProperty("--gm-scrollbar-w", ...)` · `releaseBodyLock()` 添加 `removeProperty("--gm-scrollbar-w")`
- **Drawer.test.tsx**: +5 tests — scrollbarW>0 padding-right 设置 · scrollbarW=0 不设置 · 关闭恢复 · 多 Drawer refcount 保护 · html overflow 恢复

**诊断结论**：header 在 grid flow 内（非 fixed），已天然响应 body padding，无需手动偏移。`--gm-scrollbar-w` 为未来 fixed 元素预留对齐能力。

**验证**：tsc 0 · eslint 0 · vitest 1347 pass (+5) · Python 1269 pass

### Phase 66 Batch 27 — Tailwind v4 Preflight CSS 列表样式复位修复 ✅

**需求**：AI 回复的 Markdown 列表（无序 `- ` / 有序 `1. `）渲染为正确 HTML（`<ul><li>` / `<ol><li>`）但页面不显示圆点/数字。[变更类型: fix — CSS]

**根因**：Tailwind v4 preflight CSS（`@import "tailwindcss"` base layer）对 `ol, ul, menu { list-style: none }`。`chat-prose` CSS 已设 `margin` + `padding-left` 但未显式设 `list-style-type`，导致列表标记被静默吞掉。此前 B18/B25/B26 六次修复全在 renderMarkdown 的正则和管线架构上打转，未能定位到 CSS 层。

**变更**：
- **components.css**: `:is(.chat-prose, .prose) ul/ol` 块添加 `list-style-position: outside` · `ul` 设 `list-style-type: disc` · `ol` 设 `list-style-type: decimal`
- **ChatMessage.tsx**: 临时诊断日志已移除（本轮诊断使用，问题定位后清理）

**举一反三**：对 Tailwind v4 preflight 11 项 CSS reset 逐项交叉对照 chat-prose 覆盖情况——仅 `list-style` 1 项缺失，其余 10 项均已有显式声明。详细对照表见 `docs/pitfalls.md` LRN-2026-057。

**方法论沉淀**：同批更新 `docs/methodology.md` §4 L2i「CSS Reset 交叉对照」— 任何涉及 CSS 的变更，必须在 `check-theme` 前先交叉对照项目的 CSS reset 层（Tailwind preflight/normalize.css等）与目标元素样式。Playwright `getComputedStyle` 比正则调试更早定位 CSS 层问题。

**验证**：tsc 0 · eslint 0 · vitest 1368 pass · check-theme 5 routes 0 errors · Playwright `getComputedStyle` 确认 `list-style-type: disc` 生效

### Phase 66 Batch 28 — ContextBar 颜色 Token 化 ✅

**需求**：ContextBar 组件 8 处硬编码 Tailwind 颜色（`text-slate-*` / `bg-slate-*` / `border-slate-*`）替换为 `text-text-*` / `bg-surface-*` / `border-*` token。

**变更**：`ContextBar.tsx` 8 处颜色替换，暗色模式自动跟随。

**验证**：tsc 0 · eslint 0 · vitest pass

### Phase 66 Batch 29 — ChatInput 二连修：停止按钮 Token 化 + 键位翻转 ✅

**C3 停止按钮 Token 化**：`bg-red-600`/`hover:bg-red-700`/`ring-red-500/50` → `bg-danger`/`hover:bg-danger-hover`/`ring-danger/50`。新增 `--gm-danger-hover` token（light: #b91c1c / dark: #ef4444）。

**M1 键位翻转**：Enter 发送 / Shift+Enter 换行（原行为相反，与 ChatGPT/Claude 主流习惯不一致）。新增 `!e.ctrlKey && !e.metaKey` IME 守卫。placeholder 同步更新。

**变更**：`tokens.css` (+2 token) · `theme.css` (+1 映射) · `ChatInput.tsx` (C3+M1) · `ChatInput.test.tsx` (3 断言翻转 + 1 placeholder 更新)

**验证**：tsc 0 · eslint 0 · vitest 14/14 pass

### Phase 66 Batch 55 — Learn 页 a11y 合规：focus-visible + aria-live ✅

**LC5 键盘焦点指示**：9 个 CSS 共享类 + 11 处内联元素添加 `:focus-visible` / Tailwind ring 样式。**LC6 搜索 aria-live**：搜索结果变化时 sr-only 区域播报结果数量。**LC7 沉浸 aria-live**：问题/仪表盘切换时播报当前内容标题。

**变更**：`components.css`（+9 条 :focus-visible 规则）· `AnswerCard.tsx`（+5 处）· `QuestionList.tsx`（+2 处 + aria-live）· `LearnClientShell.tsx`（+4 处 + aria-live）· `QuestionList.test.tsx`（2 处适配）

**验证**：tsc 0 · eslint 0 · vitest 1388/1388 pass · Python 1331 pass

**计划进度**：B50→B55 — T0 信息架构 ✅ · T0 章节体系 ✅ · T1 安全 6/6 ✅ · T2 a11y 3/6 ⬜ B56

### Phase 66 B56-B69 — Learn 页连续交付（roadmap 略，详见 requirements-log）

> B56-B69 为 Learn 页密集交付段（a11y · 搜索体验 · Token 体系 · Mermaid · 阅读增强 · NotesPanel · 侧栏 · 章序号 · 走查），详见 `docs/requirements-log.md`。

### Phase 66 Batch 70 — 记忆/召回卡片内容展示补齐 ✅

**需求**：B38/B39 补齐了数字维度但缺失内容维度 — 用户点开记忆卡片只能看到 stats 看不到实际记忆内容。B70 三文件补齐闭环。[变更类型: enhancement]

**变更**：
- `src/memory/fact.py` (+4): `extract_and_store` trace dict 新增 `user_msg` + `assistant_msg` key
- `JourneyCards.tsx` (+18): `MemoryStorageDetail` 新增「📝 本次记忆内容」区块（用户原话 + AI 回复）
- `FourPillar.tsx` (+20): 新增 `EpisodeContent` 子组件 — 内容 `text-gm-sm` + 200 字符以上可展开/收起

**验证**：pytest 1325 pass · tsc 0 · eslint 0 · vitest 1456 pass

### Phase 66 B71-B84 — Lab 上下文 Tab 深度优化系列 ✅

> B71-B84 为 Lab 上下文 Tab 从可用→专业的全链路打磨：可观测页扫描修复（B71-B74） · 上下文扫描 12 项清零（B76-B78） · 排版优化 P1-P6（B79-B80） · 表面 token 收敛 + 控件重构（B81-B82） · trace 可见性 + 窗口自由输入 + 演示标注（B83） · 面板排序重构 + 命名统一（B84）。详见 `docs/requirements-log.md`。

---

## Phase 67 — Windows Server 部署 + 仓库独立化 🚀 (2026-07-09 → 07-26 全线闭环)

> **缘起**：项目需要在 Windows Server 上生产部署。最大阻塞点是 FAISS 在 Windows 上 pip wheel 不稳定。同时项目托管在 monorepo 子目录 `glasscortex/` 下，需要独立为 standalone repo 并建立 Gitee→GitHub 镜像推送链路。
>
> **执行策略**：三幕递进 — Act 1 部署拉通（B1-B7）→ Act 2 仓库基建（B10-B14）→ Act 3 收尾升级（B15-B17）。19 commits，17 Batches。
>
> **交付物**：usearch 向量索引（替代 FAISS）· Windows 部署全家桶（Nginx + NSSM + 构建打包 + 离线部署）· DeepSeek 连接诊断 · monorepo 拆分 · Gitee→GitHub 镜像 · DeepSeek v4 模型升级
>
> ⚠️ **Phase 67 永不关闭**：运维/部署是持续过程，非用户明确声明关闭则保持活跃。新增运维/部署类 Batch 归入此 Phase，不另建新 Phase。

### Act 1 — 部署拉通（B1-B7）

**Phase 67 Batch 1 — FAISS→usearch + 部署基础设施** ✅

| 文件 | 改动 |
|------|------|
| `src/memory/index.py` | FAISS → usearch 替换（纯 C++，Windows wheel 完善） |
| `deploy/nginx.conf` · `deploy.ps1` · `install-services.ps1` 🆕 | Nginx 反向代理 + NSSM Windows Service + 一键部署脚本 |

**Phase 67 Batch 2 — 部署文档 + B1 缺口修补** ✅

| 文件 | 改动 |
|------|------|
| `deploy/README.md` 🆕 | 7 章主手册（架构/环境/部署/运维/排错/离线模型/更新） |
| `deploy/offline-model.md` 🆕 | 嵌入模型离线下载 SOP |
| `.env.example` 🆕 | 环境变量模板 |
| `install-services.ps1` | 修复 standalone bug (`next start` → `node server.js`) |
| `deploy.ps1` | 补目录兜底 + 健康检查 |

**Phase 67 Batch 3→7 — Windows Server 实机部署全线拉通** ✅

| Batch | 内容 |
|:--:|------|
| B3 | Python 编码兼容（GBK `read_text()` 修复）+ 前端字体本地化（Google Fonts → `next/font/local`）+ 离线打包脚本（`build-package.ps1` / `.sh`） |
| B4 | 生产加固文档：nginx TLS 参考 + dev/prod 模式 + `NEXT_PUBLIC_API_URL` 文档化 |
| B5 | 构建产物完整性：standalone static 拷贝 + `.env.production` 硬编码回退兜底 |
| B6 | DeepSeek 连接诊断（`src/health.py` 真实探测 `models.list()` → SSL/连接/超时三类诊断）+ 5 模块 `OpenAI()` 超时补齐 + 前端错误分类修复 |
| B7 | HF_ENDPOINT 镜像支持（国内 `hf-mirror.com`）+ **except 语法全量修复**（16 处 `except X, Y:` → `except (X, Y):`，Python 3.12 兼容）+ deploy README 排错 6 条 |

**L5 B1→B2 拉通**：抓 6 处 nginx 启动命令跨文档不一致（`nginx` vs `.\nginx.exe`）+ methodology.md L5 部署类子项 SOP

**里程碑**：Windows Server 代码变更 → 构建机打包 → 服务器解压 → 服务启动 → 健康检查 200 OK ✅

### Act 2 — 仓库基建（B10-B14）

**Phase 67 Batch 10 — make ship 推送镜像一体化** ✅

| 文件 | 改动 |
|------|------|
| `Makefile` | 新增 `ship` target（check-all → git push → mirror-to-github） |
| `scripts/mirror-to-github.sh` | 增量缓存（bare clone → 后续增量 fetch） |
| `scripts/github-makefile` | 公开版 `ship` target（仅 push，不含 mirror） |

**Phase 67 Batch 12 — monorepo 拆分** ✅

去 `glasscortex/` 前缀 — pre-commit 路径修正 + mirror 脚本适配独立仓库 + clone URL 更新 + `Makefile` `../.git` → `.git`

**Phase 67 Batch 13 — pre-push hook 自动镜像** ✅

每次 `git push` 自动触发 `mirror-to-github.sh`，镜像推送零手动。

**Phase 67 Batch 14 — GitHub 镜像脱敏扫描** ✅

全量审计发现 7 项（I-135–I-141），登记到 master-backlog：
- 🟠 I-135 脚本泄露（mirror-to-github.sh 不在 HIDDEN_PATHS）
- 🟠 I-136 CI 兼容断裂（github-makefile 缺 check-theme/check-visual target）
- 🟡 I-137–I-141 文档脱敏覆盖度

### Act 3 — 收尾升级（B15-B17）

**Phase 67 Batch 15 — 脱敏收尾** ✅

I-135 修复（HIDDEN_PATHS 追加）+ I-136 修复（github-makefile 桩 target）+ master-backlog 登记

**Phase 67 Batch 16 — DeepSeek v4 模型 ID 升级（后端）** ✅

`deepseek-chat` → `deepseek-v4-flash` · `deepseek-reasoner` → `deepseek-v4-pro`（7 文件，`src/config.py` + 4 测试文件 + model-comparison.md 别名映射表）

**Phase 67 Batch 17 — DeepSeek v4 模型 ID 升级（前端 + 内容）** ✅

18 文件 43 行纯机械替换 — 前端源码（3）· 前端测试（11）· Python 测试辅助（1）· 内容文件 ch4/ch8（2）· 文档（1）。ModelRoutingCard 显示名更新。

**Phase 1000 B126 — I-141 脱敏分类原则文档化** ✅

`docs/desensitization-classification.md` 🆕 — 三维分类框架（受众价值 · 内容敏感性 · 内容稳定性）+ 决策树 + 17 文档逐一决策记录

### Phase 67 完成总结

| 指标 | 数值 |
|------|------|
| Batches | 17 (B1→B17) |
| Commits | 19 |
| 新增文件 | ~15（部署脚本/配置/文档/打包） |
| 关键决策 | usearch 替代 FAISS · monorepo 拆分 · Gitee→GitHub 镜像 · DeepSeek v4 升级 · 脱敏分类框架 |
| 部署目标 | Windows Server — `git push` → 构建 → 解压 → 启动 → 200 OK 全链路验证通过 |

**Phase 67 后项目状态**：可在 Windows Server 上一键部署 · FAISS 依赖完全消除 · 仓库独立可公开镜像 · 模型 ID 对齐 DeepSeek 官方最新命名

---

## Phase 68 — 工程管理基础设施 🏗️ (2026-08-07→08-08, B1→B19)

> **缘起**：项目经过 67 个 Phase 积累了大量工程门禁（check-docs / L5 / 违纪闭环 / 日报 / 共享模块治理），但所有健康指标只能通过终端 `make check-docs` 查看。新人接手项目缺少产品视角导览文档。Phase 68 建立"终端→API→前端页面"完整工程管理工具链。
>
> **执行策略**：B1 项目导览 → B2 后端 API → B3 前端页面 → B4 打磨 + L5 拉通 → B5 Mermaid 水合 → B6 TOC 导航 → B7 侧栏布局重构 → B8 二级菜单快捷入口 → B9 图标对齐 + 水合修复 → B10 独立滚动 → B11 字号调节 → B12 UI 美化 → B13 日报列表修复 → B14 日历面板 → B15 文档卡片化 → B16 需求日志统一列表 → B17 摘要卡片。十七批递进，每批独立可验证。
>
> **交付物**：`docs/ONBOARDING.md` (私密导览) · `api/routers/admin.py` (3 端点) · `tools/check_docs.py --json` 模式 · `frontend/src/app/admin/` (密码门禁 + 仪表盘 + 文档浏览器 + TOC 目录导航)

### Phase 68 Batch 1 — ONBOARDING.md + .gitignore 防线 ✅

| 文件 | 改动 |
|------|------|
| `docs/ONBOARDING.md` 🆕 | 私密文档（.gitignore 保护），5 章：项目名片 · 功能全景 · 技术地图 · 协作方式 · 快速上手。协作方式章展开 6 个子主题（人的角色 · 为什么这样工作 · Batch 工作单元 · 五层自检金字塔 · 浏览器运行时验证 · 文档闭环）。全文 318 行 |
| `.gitignore` | +3 行 — `docs/ONBOARDING.md` 忽略规则 + 注释 |

**验证**：make check-docs ✅ · .gitignore 规则正确（文件未进入 git status）

### Phase 68 Batch 2 — Admin API ✅

| 文件 | 改动 |
|------|------|
| `tools/check_docs.py` | +106 行 — `--json` 参数 + `_main_json()` 函数，输出结构化 JSON（git log 摘要 · Phase/Batch · L5 间隔 · 日报 · 违纪 · 文档新鲜度 · 检查项结构化结果） |
| `api/routers/admin.py` 🆕 | 224 行 — 3 端点：`GET /api/admin/health`（check-docs JSON 透传 + 超时/异常保护）· `GET /api/admin/docs`（文档清单分组归类 + 日报/归档子目录折叠）· `GET /api/admin/docs/{name}`（路径穿越防护 + 沙箱限制） |
| `api/main.py` | +2 行 — admin router 注册 |

**安全设计**：`_sanitize_name` 防 `..` 穿越 + `resolve()` 越界检测 + `_ALLOWED_DIRS` 沙箱

**验证**：ruff 0 · mypy 0 · pytest 1351 · API 端点连通确认

### Phase 68 Batch 3 — Admin 前端管理页面 ✅

| 文件 | 改动 |
|------|------|
| `frontend/src/lib/api/types-admin.ts` 🆕 | Admin API 领域类型（AdminHealthResponse / DocListItem / DocContentResponse） |
| `frontend/src/lib/api/types.ts` | admin 类型 re-export |
| `frontend/src/lib/api/client.ts` | api 对象新增 `getAdminHealth` / `getDocs` / `getDocContent` |
| `frontend/src/app/admin/page.tsx` 🆕 | Server Component 入口（robots: noindex） |
| `frontend/src/app/admin/AdminShell.tsx` 🆕 | 733 行 Client Component — PasswordGate（NEXT_PUBLIC_ADMIN_PASSWORD + sessionStorage + 抖动动画 + 显示/隐藏切换）· TopBar（粘性顶栏 + Tab 导航）· HealthPanel（6 摘要卡片网格 + 门禁明细表 + 最近提交）· DocsPanel（GROUP_ORDER 分组折叠 + 目录展开 + 文件行信息）· DocViewer（renderMarkdown 渲染 + 骨架屏 + 错误态） |

**验证**：tsc 0 · eslint 0 · vitest 1589

### Phase 68 Batch 4 — Admin 面板打磨 + L5 全线拉通 ✅

| 改动 | 详情 |
|------|------|
| ThemeToggle 接入 | TopBar 操作区新增 `ThemeToggle` 组件（复用 `@/components/ui/ThemeToggle`），Admin 页面支持暗/亮模式 |
| Health 刷新按钮 | `lastUpdated` state + `refresh` callback · 刷新按钮（RiRefreshLine + loading 动画）+ 最后更新时间（toLocaleTimeString） |
| DocViewer 代码高亮 | `useCodeHighlight` hook 接入 → Prism 语法高亮 + line-numbers + CopyButton（复用 Chat/Learn 页管线） |

**L5 B1→B4 拉通**：
- 修复 CLAUDE.md 路由计数 8→12（B2 L5 写了但未实际执行）
- CLAUDE.md 前端结构补 `src/app/admin/` 条目
- architecture.md 补 admin API 路由 + admin 前端页面条目
- roadmap.md 日期刷新

**验证**：tsc 0 · eslint 0 · vitest 1589 · ruff 0 · mypy 0 · pytest 1351 · check-theme 0 errors

### Phase 68 Batch 5 — DocViewer Mermaid 水合 ✅

| 文件 | 改动 |
|------|------|
| `frontend/src/app/admin/AdminShell.tsx` | DocViewer 水合管线 — `createRoot` + `MermaidDiagram` 导入 · `mermaidRootsRef` (Map<HTMLElement, Root>) · `useEffect` 扫描 `.gm-mermaid-block` → base64 decode → createRoot 动态挂载 MermaidDiagram · 错误回退 + Strict Mode 安全 |

**设计**：水合逻辑与 `ChatMessage.tsx:61-93` 完全同构（sentinel 扫描 → base64 解码 → createRoot → MermaidDiagram 渲染），复用 `renderMarkdown` 的 `\x00MMD` sentinel 管道 + `MermaidDiagram` 的 mermaid.js 渲染 + 暗/亮主题跟随。

**验证**：tsc 0 · eslint 0 · vitest 1589

### Phase 68 Batch 6 — DocViewer TOC 导航 ✅

| 文件 | 改动 |
|------|------|
| `frontend/src/lib/renderMarkdown.ts` | 标题 ID 生成 — h1-h6 渲染时自动生成 `id` 属性（剥除行内 HTML 标签 → 解码 &amp;/&lt;/&gt;/&quot; → 非字母数字中文替换为 `-` → 纯符号标题兜底 `heading`） |
| `frontend/src/app/admin/AdminShell.tsx` | DocViewer 两栏布局重构 — 左侧 sticky TOC 侧栏（w-52 xl:w-56）+ 右侧文档正文 · TOC 提取 h1/h2/h3（text/id/level）· IntersectionObserver 激活追踪（`rootMargin: "-80px 0px -75% 0px"`）· 点击平滑滚动 · 重复 ID 去重 · 空/加载/错误态不渲染 TOC |
| `frontend/src/__tests__/lib/renderMarkdown.test.ts` | 标题断言更新为含 `id` 属性 |
| `frontend/src/__tests__/lib/renderMarkdown.edgecases.test.ts` | 同上 |

**设计**：TOC 侧栏 `sticky top-[88px]` 跟随滚动 · 层级缩进 h1→`pl-1` h2→`pl-4` h3→`pl-7` · 激活项 `border-primary text-primary bg-primary/8` + 左侧 2px 指示条 · IntersectionObserver 与 `[content]` dep key 同步重建。

**验证**：tsc 0 · eslint 0 · vitest 1589 · ruff 0 · mypy 0 · pytest 1351

### Phase 68 Batch 7 — Admin 侧栏菜单布局重构 ✅

| 文件 | 改动 |
|------|------|
| `frontend/src/components/admin/AdminSidebar.tsx` 🆕 | 145 行 — 可折叠分组 + 二级菜单导航 · `AdminTab` 类型导出 · 分组标题 chevron 折叠（RiArrowDownSLine/RiArrowRightSLine）· 激活项 `border-l-2 border-primary text-primary bg-primary/8` 侧栏指示条 · 桌面端 `lg:block` 显示、移动端隐藏 |
| `frontend/src/components/admin/HealthPanel.tsx` 🆕 | 215 行 — 从 AdminShell 搬出，不改逻辑 |
| `frontend/src/components/admin/DocsPanel.tsx` 🆕 | 244 行 — 从 AdminShell 搬出（含 DocGroup/DocDirRow/DocFileRow） |
| `frontend/src/components/admin/DocViewer.tsx` 🆕 | 240 行 — 从 AdminShell 搬出（含 TOC + Mermaid 水合） |
| `frontend/src/components/admin/PasswordGate.tsx` 🆕 | 106 行 — 从 AdminShell 搬出 |
| `frontend/src/components/admin/utils.ts` 🆕 | 18 行 — 共享工具函数（fmtBytes / fmtDate） |
| `frontend/src/app/admin/AdminShell.tsx` | 925→159 行重写 — 退回编排层：认证状态 + 侧栏路由 + Panel 调度 · TopBar 简化为品牌 + ThemeToggle + 退出按钮（Tab 按钮移至 Sidebar） |

**布局变更**：顶部水平 Tab → Header + 左侧折叠菜单栏 + 右侧内容区（桌面端 sidebar w-52 xl:w-56，移动端 sidebar 隐藏）。AdminShell 从 1 文件 925 行（8 个子组件混居）拆分为 7 文件（编排层 159 行 + 6 独立组件 + 1 工具文件）。

**验证**：tsc 0 · eslint 0 · vitest 1589

### Phase 68 Batch 8 — 侧栏二级菜单快捷入口 ✅

| 文件 | 改动 |
|------|------|
| `frontend/src/components/admin/AdminSidebar.tsx` | `AdminTab` 扩展 `"daily"` `"requirements-log"` · 文档管理分组新增 2 个二级菜单项（日报 RiCalendarLine · 需求日志 RiArticleLine） |
| `frontend/src/app/admin/AdminShell.tsx` | 新增 `handleTabChange` 回调 — 切换至日报/需求日志 tab 时自动构造 `DocListItem` 并触发 `loadDoc` · `backToDocs` 切回 docs 标签页 · 渲染分支覆盖 `daily`/`requirements-log` 两个新 tab |

**交互**：点击侧栏「日报」→ 自动加载今日日报 `docs/daily/2026-08-07.md` 并在 DocViewer 中展示 · 点击「需求日志」→ 自动加载 `docs/requirements-log.md` · 「返回」按钮回到文档清单。

**验证**：tsc 0 · eslint 0 · vitest 1589

### Phase 68 Batch 9 — 侧栏图标尺寸对齐 + mermaid console.warn 清零 ✅

| 文件 | 改动 |
|------|------|
| `frontend/src/components/admin/AdminSidebar.tsx` | 全部图标 `size={18}` → `size={16}`，对齐 `text-gm-sm` |
| `frontend/src/components/admin/DocViewer.tsx` | mermaid 扫描选择器 → `.gm-mermaid-block[data-chart]` 属性过滤 · cleanup 函数新增 `mermaidRootsRef` 遍历卸载 |
| `frontend/src/components/chat/ChatMessage.tsx` | 同步重构 mermaid 清理逻辑，提取 `cleanupMermaidRoots()` |

**验证**：tsc 0 · eslint 0 · vitest 1589

### Phase 68 Batch 10 — DocViewer TOC/正文独立滚动 + 标题 ID 去重 ✅

| 文件 | 改动 |
|------|------|
| `frontend/src/app/admin/AdminShell.tsx` | `<main>` flex-col + overflow-hidden 高度链 · DocViewer `flex-1 min-h-0` 解锁 flex 滚动 · `h-screen` 建立全高度约束 |
| `frontend/src/components/admin/DocViewer.tsx` | TOC + 正文各自 `overflow-y-auto` · IntersectionObserver root 切换为滚动容器 |
| `frontend/src/lib/renderMarkdown.ts` | 标题 ID 去重：同 slug 追加 `-2`/`-3` 后缀 |

**验证**：tsc 0 · eslint 0 · vitest 1589

### Phase 68 Batch 11 — DocViewer 字号调节 + hydration/Script 修复 ✅

| 文件 | 改动 |
|------|------|
| `frontend/src/components/admin/DocViewer.tsx` | 文档字号扩大：prose 标题/正文/代码块尺寸调节 |
| `frontend/src/app/admin/AdminShell.tsx` | Script 标签 hydration 警告修复 |

**验证**：tsc 0 · eslint 0 · vitest 1589

### Phase 68 Batch 12 — Admin UI 美化：菜单·目录·文档 布局/间距/字体 ✅

| 文件 | 改动 |
|------|------|
| `frontend/src/components/admin/AdminSidebar.tsx` | 菜单字体/间距/折叠样式 — Brand 区 + 分组标题 + 菜单项 拉通 |
| `frontend/src/components/admin/DocsPanel.tsx` | 目录项字体/间距 — 分组标题 + 文件行 + 元信息行 |
| `frontend/src/components/admin/DocViewer.tsx` | 文档排版 — 标题/正文字号 + 行距 |

**验证**：tsc 0 · eslint 0 · vitest 1589

### Phase 68 Batch 13 — 日报列表修复：侧栏"日报"入口展示全部历史日报 ✅

| 文件 | 改动 |
|------|------|
| `frontend/src/app/admin/AdminShell.tsx` | `handleTabChange` 移除 `daily` tab 硬编码今日日报自动加载 · daily tab 合并入 `docs || daily` 渲染分支 |
| `frontend/src/components/admin/DocsPanel.tsx` | 新增 `filterGroup` prop — API 返回后按分组名过滤 |

**验证**：tsc 0 · eslint 0 · vitest 1589

### Phase 68 Batch 14 — 日报日历面板 ✅

| 文件 | 改动 |
|------|------|
| `frontend/src/components/admin/DailyPanel.tsx` 🆕 | 389 行日历面板 — 纯 JS 日期计算 · 周一始 7 列网格 · 月份标题 + 中文周标题 · DayCell 四态（有日报/无日报/今天/空白）· 骨架屏 |
| `frontend/src/app/admin/AdminShell.tsx` | daily tab 独立渲染分支 → DailyPanel → DocViewer |

**验证**：tsc 0 · eslint 0 · vitest 1589

### Phase 68 Batch 15 — 文档清单卡片化 + 滚动修复 ✅

| 文件 | 改动 |
|------|------|
| `api/routers/admin.py` | `_extract_summary()` — 提取 .md 首段 ≤120 字符概要 · `list_docs()` 添加 `summary` 字段 |
| `frontend/src/lib/api/types-admin.ts` | `DocListItem` 新增 `summary?: string` |
| `frontend/src/app/admin/AdminShell.tsx` | `<main>` `overflow-hidden` → `overflow-y-auto` 修复内容滚动 |
| `frontend/src/components/admin/DocsPanel.tsx` | `DocFileRow` → `DocFileCard` 卡片 — 图标 + 标题 + 分组徽章 + 概要 + 元信息 · 2 列网格 · hover 态 |

**验证**：tsc 0 · eslint 0 · vitest 1589

### Phase 68 Batch 16 — 需求日志统一列表：当前 + 归档合并呈现 ✅

| 文件 | 改动 |
|------|------|
| `docs/requirements-log.md` | 顶部新增归档索引表（10 文件 + 覆盖范围 + 行数/大小） |
| `frontend/src/components/admin/RequirementsLogPanel.tsx` 🆕 | 226 行统一列表 — 当前日志卡片（brand 边框 + 绿色"当前"徽章）+ 历史归档表（Phase 倒序）· 四态 |
| `frontend/src/app/admin/AdminShell.tsx` | requirements-log tab 改用 RequirementsLogPanel 替代自动加载 |
| `frontend/src/components/admin/DocsPanel.tsx` | `filterGroup`: `string` → `string \| string[]` 向后兼容 |

**验证**：tsc 0 · eslint 0 · vitest 1589

### Phase 68 Batch 17 — DocsPanel 日报/需求日志摘要卡片 ✅

| 文件 | 改动 |
|------|------|
| `frontend/src/components/admin/DocsPanel.tsx` | `SummaryCardConfig` + `SUMMARY_CARD_CONFIGS` + `renderSummaryCard` — 日报/需求日志摘要卡片替代目录树展开 |
| `api/routers/admin.py` | `_extract_summary` 优化：需求日志文件跳过归档索引表行 |
| `frontend/src/components/admin/RequirementsLogPanel.tsx` | 日期格式化复用 `fmtDate` |

**验证**：tsc 0 · eslint 0 · vitest 1589

### Phase 68 Batch 18 — Admin 图标统一 (emoji → RemixIcon) ✅

| 文件 | 改动 |
|------|------|
| `frontend/src/components/admin/DocsPanel.tsx` | `GROUP_ICON` 5 分组 emoji → RemixIcon 组件（RiFileListLine/RiBookOpenLine/RiDashboardLine/RiBookReadLine/RiFileLine）· `SUMMARY_CARD_CONFIGS` 2 卡（RiCalendarLine/RiArticleLine）· `icon` 类型 `string`→`React.ReactNode` |
| `frontend/src/components/admin/RequirementsLogPanel.tsx` | 当前日志卡片 `📋` → RiArticleLine + import |

**验证**：tsc 0 · eslint 0 · vitest 1720 pass · check-theme 6 路由 0 errors

### Phase 68 Batch 19 — 文档检索：内联搜索 + Cmd+K 模态窗 ✅

| 文件 | 改动 |
|------|------|
| `src/lib/content/docSearch.ts` 🆕 | Fuse.js `createDocSearchIndex()` + `flattenDocs()` — 名称/摘要加权搜索 |
| `src/components/admin/SearchModal.tsx` 🆕 | Cmd+K 搜索模态窗 — backdrop + 居中卡片 + 自动聚焦 + ↑↓EnterEsc 键盘导航 |
| `src/components/admin/DocsPanel.tsx` | 内联搜索框（RiSearchLine + 清除按钮）+ 分组过滤 + `docs` prop 预取优化 |
| `src/app/admin/AdminShell.tsx` | allDocs fetch + Cmd/K 全局快捷键 + SearchModal 集成 + TopBar `⌘K` 搜索按钮 |
| 测试 | 2 新测试文件（docSearch 17 + SearchModal 20 = 37 tests）|

**验证**：L1 tsc 0 · eslint 0 · vitest 1757 pass (104 files) · L4b check-theme 6 路由 0 errors

---

## Phase 69 — 工程过程数据可视化（2026-08-08 启动）

> **范围**：协作工程数据可视化 —
> L5 时间线 · 违纪看板 · 需求覆盖钻取 · 日报热力图
> 与 Phase 68（静态文档消费）互补：Phase 68 = 文档内容 · Phase 69 = 过程数据

**执行策略**：从 Admin 仪表盘入手，逐步将工程过程数据从纯文字报告升级为可视化面板。

| Batch | 内容 | 状态 |
|:---:|------|:---:|
| B1 | 仪表盘重命名（健康仪表盘→仪表盘）+ AdminSidebar 图标更新 + HealthPanel 美化 | ✅ |
| B2 | 日报热力图 — GitHub 贡献图式 7×N 热力格子 + 仪表盘集成 | ✅ |

### Phase 69 Batch 1 — 仪表盘重命名 + 美化 ✅

侧栏「健康仪表盘」→「仪表盘」，图标 `RiHeartPulseLine` → `RiDashboardLine`。
HealthPanel 美化：页面标题区 + 摘要卡片图标 + `text-gm-xl` 数值字体 + `PageHeader` 组件化 + 去 emoji 前缀。

**文件**：AdminSidebar.tsx · HealthPanel.tsx · 2 test files（AdminSidebar + HealthPanel）
**门禁**：tsc 0 · eslint 0 · vitest 1783 pass

### Phase 69 Batch 2 — 日报热力图 ✅

GitHub 贡献图式热力格子，7×N 布局，12 个月回溯。从 AdminShell allDocs 中提取日报目录 dateMap，渲染为彩色格子（有日报 brand · 无日报 gray）。仪表盘摘要卡片下方集成。

**文件**：DailyHeatmap.tsx 🆕 (172 行) · HealthPanel.tsx (+docs prop) · AdminShell.tsx (pass allDocs) · DailyHeatmap.test.tsx 🆕 (13 tests)
**门禁**：tsc 0 · eslint 0 · vitest 1796 pass

