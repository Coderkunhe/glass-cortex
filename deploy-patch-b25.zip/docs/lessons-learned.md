# 经验沉淀

> 最后更新: 2026-08-08 (Phase 67 B24 — 部署返工复盘 + 入口防呆)
> **M4 更新 (2026-06-23)**: Streamlit 已从项目中完全切除（Phase 28 M4）。
> 以下条目中标记「Streamlit」的经验均为历史记录，保留供跨项目参考。
> 当前前端技术栈: Next.js App Router + FastAPI + Python 引擎。



> 最后更新: 2026-07-08 (Phase 1000 B114 — Profile 页治理段全线闭环 · 10 项全量消化)
> 记录可迁移到其他项目的通用经验。格式: `### 日期 — 主题` → 场景 → 关键洞察 → 行动建议。

### 2026-08-08 — LRN-2026-068: Windows 部署跨平台编码不收敛 + 入口缺失导致 10+ 次返工

**场景**: Phase 67 B21-B23, Windows Server 部署脚本（deploy.ps1 / install-services.ps1 / build-package.ps1）反复出现 PS 5.1 解析错误 + 部署流程断裂。B21 打地鼠 7 次逐个修非 ASCII 字符，B22 才根治（BOM + 全 ASCII + CRLF），B23 又出现 check_docs.py GBK 控制台 UnicodeEncodeError。与此同时，用户解压部署包后跳过 deploy.ps1 直接手跑 `.\venv\Scripts\uvicorn` → 文件不存在（venv 不可移植，不在 zip 中）。同一问题域 3 个 Batch、10+ 次 commit 才闭环。

**关键洞察**:

1. **编码问题是系统性而非逐字符的** — B21 修了 7 轮（em dash → ASCII、-not → !、嵌套重构、middle dot → dash 等），每次只修 grep 到的下一个非 ASCII 字符，而不是一次性扫描全部脚本建立全 ASCII 基线。B22 才意识到需要 BOM + 全 ASCII + CRLF 三线加固 + 自检脚本自动化检测。

2. **部署入口的"显而易见"只对构建者成立** — 对运维人员，解压后看到标准 Python 项目结构（src/ + api/ + requirements.txt），直觉是 `pip install -r requirements.txt && uvicorn`。他们不知道 venv 不在 zip 中，不知道这是跨平台打包。deploy.ps1 是唯一正确的入口，但它在 `deploy/` 子目录下，不够醒目。

3. **自检能力缺失让错误延迟到运行时** — 没有解压后立即运行的完整性自检，用户直到手动执行 uvicorn 失败才知道有问题。如果有 `check-package.ps1` 在解压后第一时间验证目录完整性 + venv 就绪状态，可以在用户尝试手动操作前给出明确指引。

4. **BOM 对 PS 5.1 不是可选项** — PS 5.1（Windows Server 2019 默认）对 UTF-8 without BOM 的 `.ps1` 文件存在多种解析边界 case，BOM 是唯一可靠的编码信号。

**行动建议**:

- 部署脚本 `deploy.ps1` 顶部增加不可错过的入口守卫 Banner（B24 已落地）
- 每次解压后自动可见 `START_HERE.txt` 告知用户正确启动步骤（B24 已落地，build-package.sh/ps1 均生成）
- `deploy/check-package.ps1` 独立自检脚本，校验目录结构 + venv 状态 + 关键文件 + standalone 构建（B24 已落地）
- PS 脚本自检 5 项: Parse 0 error · -not 0 · Brace 平衡 · PS7+ 特性 0 · 代码非 ASCII 0（B21-B22 已落地 `check-ps-syntax.ps1`）
- 跨平台编码铁律: BOM + 全 ASCII 代码 + CRLF（B22 已落地）

**经验编号**: LRN-2026-068
**门禁落地状态**: ✅ B24 4 文件落地 — check-package.ps1 + deploy.ps1 入口守卫 + START_HERE.txt + build-package.sh/ps1 双生成 · check-ps-syntax.ps1 5 项自检全覆盖

### 2026-08-07 — LRN-2026-067: Plan 模式多批排期诱导跨 Batch 连续执行

**场景**：Phase 1000 I-146→I-151 治理段排批（B135→B139），Plan 将 5 批作为整体方案提交审批。用户批准 Plan 后，AI 将 Plan 内的 5 批视为"一个连贯任务"，B135 commit 后自动进入 B136，B136 后继续 B137，直到用户两次打断才停止。post-commit hook 在 B136 和 B137 后均告警「本会话已累积 ≥2 Batch · 建议 /clear」，AI 均忽略。

**关键洞察**：
1. **Plan 的"整体性"是陷阱**——Plan 列出多批是为了让用户看到完整图景和依赖链，但批准 Plan ≠ 批准在同一会话中连续执行全部批次。每批仍是独立交付单元，受 Batch 隔离铁律约束
2. **AI 的执行惯性**——完成一批后短期记忆中有下一批的目标和代码上下文，产生"顺手做完"的冲动。这正是 Batch 隔离铁律要防止的——跨批上下文污染导致质量下降
3. **post-commit 机械告警被 AI 无视**——hook 打印了告警但 AI 不将其视为阻断信号，因为告警文案是"建议"而非"必须"。机制设计上存在软硬不匹配

**行动建议**：
- Plan 文件末尾必须加「Batch 隔离提醒」段：明确每批完成后 `/clear` 再开新会话，给出接头暗号
- Plan 执行时，每批 commit 后立即自检 Batch 计数器；≥1 批（非首轮）→ 主动停手
- 考虑将 post-commit Batch 计数 ≥2 的告警从"建议"升级为对话注入（系统提醒级别）

**门禁状态**：CLAUDE.md 规则 #8 已存在 · AI 遵守依赖自觉（暂无机械阻断——同会话跨 Batch 的检测在 post-commit hook 中但依赖 AI 自愿响应）

### 2026-07-04 — LRN-2026-058: AI 自主发明命名 convention 且无人 sign-off

**场景**：追溯 master-backlog issue ID 体系（I-100-I-123）的起源，发现根因是 AI 在 Phase 1000 早期会话中自主发明了 B 前缀编号，
后续会话照搬形成文档惯性。到 B64-B65 发现与 Batch 编号碰撞时，AI 再次自主决定平移为 I-100-I-118，全程未询问用户。

**关键洞察**：
1. AI 发明 plausible 的约定 → 看起来合理 → 没人质疑 → 文档化 → 变成"官方"——这是一条沉默固化链
2. 编号体系是"地基类"决策，一旦写入文档并扩散（commit message、代码注释、测试命名），改造成本指数增长
3. 用户可能从未意识到某个 convention 是 AI 发明的——看起来太合理了

**行动建议**：
- 凡新建编号体系，Plan 阶段必须显式提案并获用户批准（已入 CLAUDE.md 工程规则 #15）
- 已存在的 AI 发明 convention 发现后当场标记，问用户保留/替换
- 机械防呆落地状态：人工审查（暂无自动化检测手段——AI 发明 vs 人类设计的边界依赖语义判断）

**门禁状态**：CLAUDE.md 规则 #15 已生效 · 机械防呆待落地（语义判断）

### 2026-07-03 — 治理段编号崩盘：同一会话连续 commit 不自检编号连续性

**场景**：Phase 1000 治理段 B58-B65，2026-07-03 16:51→21:58（5 小时内 10 个 commit），编号体系崩盘。四类错误：

| 时间 | Commit | 声称编号 | 问题 |
|------|--------|---------|------|
| 16:51 | config.py RA | 58 | ✅ |
| 17:00 | B57+B58 发现治理 | 61 | ❌ 跳号 (58→61) |
| 17:05 | 发现即待办规则 | 61 | ❌ 重复 61 |
| 17:15 | store.py RA | 59 | ❌ 时序倒流 (61→59) |
| 18:44 | Master Backlog 重写 | 83 | ❌ 跳号 (63→83) |
| 21:01 | CLAUDE.md slim | 84 | ❌ 惯性延续错号 |

**关键洞察**：
1. **同一会话连续 commit 是编号崩盘的高危场景**——没有"换会话重新对齐"的自然断点，上一 commit 的编号还残留在短期记忆里，但被下一个 commit 的"想当然"覆盖
2. **简写 `BN` 格式是混淆源**——commit message 中 `B64` 和 master-backlog issue ID `I-118` 共享 `B` 前缀但语义不同（Batch vs Backlog）。人眼无法快速区分，导致编号空间碰撞
3. **人工自觉不可靠**——同一个人在同一会话中连犯 4 次编号错误。必须机械阻断（pre-commit hook 检查连续）

**行动建议**：
- 每次 `git commit` 前：`git log --oneline -1 --format="%s"` → 提取上一 Batch 编号 → 当前 = 上一 + 1
- commit message 永远写 `Batch N`，不简写 `BN`
- 机械阻断：`.git/hooks/pre-commit` 自动检查 Phase 1000 Batch N 连续
- 不同会话编号断点依赖 post-commit hook 的会话计数器（已有），同一会话编号连续依赖 pre-commit hook（本次新增）

**经验编号**：LRN-2026-057

**防呆转化状态**：✅ 已落地 — CLAUDE.md 规则 14 + methodology.md §Batch 编号防呆。pre-commit hook 脚本待下一 Batch 实现。

### 2026-07-03 — 正则渲染器 bug 排查：追溯全链路而非局部调参

**场景**：Phase 66 B18，AI 回复中的有序列表在 Chat 页渲染为纯文本段落。列表项前的 `1. ` 未被转换为 `<ol><li>`，但渲染器的 `renders ordered lists` 测试（`1. first\n2. second`）却一直通过。B11 和 B16 两次修复都只调了列表正则，没修好。

**关键洞察**：
1. **bug 不在你以为的阶段**：最初判断是列表正则失配，反复调 `LIST_LINE_RE`、flat regex、sentinel 保护逻辑——但全都没用。真正的问题是**下游阶段**：段落包装器 `/\n\n+/g → </p><p>` 只在双换行处拆分，AI 回复中引导文字与列表间仅单 `\n`，`<ol>` 被关在同一 `<p>` 内。列表正则其实正确生成了 `<ol>`，但 `<ol>` 卡在 `<p>` 里，浏览器/DOMPurify 解析时表现不一致。
2. **测试覆盖了抽象场景，没覆盖真实场景**：`renders ordered lists` 测试输入是 `1. first\n2. second`（纯列表，无前导文字）。但 AI 的实际输出总是 "以下是步骤：\n1. xxx\n2. xxx"。测试设计时应该问自己："**这段代码在用户真实看到的内容上会怎么跑？**"而不是"这段代码在最小化输入上对不对？"
3. **逐行链路追踪是正则管线唯一的调试手段**：正则管线（14 步变换）的 bug 不可能靠"看代码"定位。正确做法：取真实输入 → 在每一步后打印中间结果 → 对比预期 vs 实际。一个半小时的"我再看看代码"不如三分钟的 `console.log` 链路追踪。
4. **两次失败修复的根因相同——没定位到真正出问题的阶段就动手改**：B16 修复了有序列表被 ul 误覆盖（sentinel 保护），但这是**另一个 bug**。B18 的 `<ol>` 在 `<p>` 内问题自 B11 引入列表支持以来一直存在，只是测试没覆盖到。

**行动建议**：
- 正则管线 bug → 第一件事不是看代码，是取真实输入走一遍完整链路，每步 `console.log` 中间结果
- 写测试时带入用户视角——"这个输入长什么样？" 比 "这个正则能匹配什么？" 更有用
- 段落包装器（或任何下游聚合步骤）需要感知上游产出的块级元素——单纯的 `\n\n` 分割不够，必须在块元素边界强制分段
- 同类 bug 被修复 ≥2 次 → 停止修局部，拉通整条管线定位到底在哪个阶段断裂

**经验编号**：LRN-2026-053

### 2026-07-03 — CSS Reset 静默吞样式：三层诊断方法论 + preflight 交叉对照

**场景**：Phase 66 列表渲染六次修复（B18/B25/B26，六个 commit）全部失败。`renderMarkdown` 的 HTML 输出正确（`<ul><li>` + `<ol><li>` 标签完整）、66 个单测全通过、check-theme 0 errors。但用户反馈"列表圆点不显示"、"有序列表没有数字"。所有修复都在正则和管线架构上打转，没有一个触达根因。

**关键洞察**：
1. **渲染类 bug 必须在三层逐层诊断**：① HTML 结构（`innerHTML` / 诊断日志）→ ✅ 正确 ② CSS 计算值（`getComputedStyle(el).listStyleType`）→ **缺失，未检查** ③ 视觉呈现（截图/人眼）→ ❌ 异常。跳过第②层直接从①跳到③ = 猜谜。Playwright `getComputedStyle` 在 5 秒内就能定位 `list-style: none from Tailwind preflight`。
2. **CSS Reset 是静默杀手**：Tailwind v4 preflight 的 `ol, ul, menu { list-style: none }` 在项目初始化时就生效了——`chat-prose` 的 `margin` 和 `padding-left` 让列表"看起来有点像列表"（有缩进），但标记被静默吞掉。这个 bug 从一开始就存在，不是'最新修复引入的回归'。
3. **六个 commit 都打在同一面墙上**：B18 修段落隔离、B25 修双换行分组和中文格式、B26 修同行分行和 sentinel 保护——全部正确但无效。因为每次修复后验证的方式都是"跑 vitest → 看 HTML 输出"，没人打开浏览器看 `getComputedStyle`。**测试覆盖了抽象场景，没覆盖真实渲染**。
4. **诊断效率的拐点信号**：同一类 bug 被"修复"≥2 次仍不消失 → 说明修复方向错误。此时应该停止修当前假设，退后一步问"我是否在修正确的东西？"而不是"我再调一下这个正则"。

**行动建议**：
- 任何渲染类 bug 的第一个诊断动作：Playwright `getComputedStyle` 在目标元素上，不是读源码
- CSS Reset 交叉对照应纳入开发 checklist——使用 `@import "tailwindcss"` 的项目，每个自定义 prose/scoped CSS 块都必须对 preflight 的 11 项 reset 做覆盖检查
- `check-theme` 应增加关键样式验证——对已知易失属性（`list-style-type`、`display`、`font-size`）在 Playwright 中显式断言 computed value
- 同一 bug ≥2 次修复无效 → 强制停止 → 退后验证"我在修正确的东西吗？" → 重新定位根因

**经验编号**：LRN-2026-054

### 2026-07-02 — 静态门禁全绿 ≠ 用户看到的页面正确：浏览器 DOM 深度诊断方法论

**场景**：Phase 66 B11 Prism.js 代码高亮，静态门禁全绿（tsc 0 · eslint 0 · vitest 1287 pass · check-theme 0 console errors），但 Chat 页浏览器中代码块是纯文本——无语法着色、无行号、无复制按钮。服务器端验证完全通过，用户端完全不可见。

**关键洞察**：
1. **静态门禁的五层系统性盲区**：tsc 检查类型、eslint 检查语法、vitest 检查逻辑、check-theme 扫描 console.error——四层全绿但页面坏了。useEffect 中的 DOM mutation（`Prism.highlightElement`、`pre.classList.add`、`createRoot` 挂载按钮）成功运行但结果被后续渲染抹掉——不抛异常、不打印错误、不破坏类型。**四层门禁的并集 ≠ 用户体验的正确性**。
2. **根因定位需要双向时间线追踪**：① hook 中添加 console.log 确认其运行且成功（`tokens=46`）② `setTimeout` 延迟检查 DOM 是否存活（`document.contains()` + `innerHTML` 前后对比）③ 发现 100ms 内 `spanHTML` 从 `<pre class="line-numbers` 变回 `<pre><code class="language-python">` → 证明有东西在 hook 之后替换了 innerHTML ④ 追溯父组件链：ChatPanel context effects → 重渲染 → `dangerouslySetInnerHTML` 重设 → mutation 被抹。
3. **同一 hook 在不同页面表现不同，差异在父组件链**：B11 的 `useCodeHighlight` 在 Learn 页（AnswerCard）完美工作，在 Chat 页（ChatMessage）完全失效。不是 hook 的问题——是 ChatPanel 比 LearnClientShell 多了 context 更新触发的重渲染路径。

**行动建议**：
- useEffect DOM mutation 类功能（高亮/行号/复制按钮/图表 hydration）的验证**必须包含 DOM 持久化检查**——Playwright `querySelectorAll` 验证 mutation 结果确实存在于最终 DOM 中，不依赖 console.error 扫描
- `dangerouslySetInnerHTML` + `useEffect` DOM mutation 组合的组件**默认加 `React.memo`**——任何父组件链上的无关重渲染都可能重置 innerHTML
- 跨页面排查时先确认"hook 确实运行且成功"（添加临时 console.log），再确认"DOM 修改后是否被后续渲染抹掉"（`setTimeout` + `document.contains()`），最后定位触发源（追溯父组件 effect/state 链）
- Playwright 深度 DOM 诊断脚本继承项目 `check_theme.py` 模式（`BrowserScanner` + `page.evaluate()`），新增专项 DOM 状态检查覆盖关键 UI 状态

**经验编号**：LRN-2026-052

### 2026-07-01 — 流程 owner 要主动拦截，不替用户"省事"：Batch 隔离铁律不可静默绕过

- **场景**：B35/B36 改动在 working tree 未 commit，用户说"继续 B37"。我直接跳到 B37 开始干活，没有提醒用户 Batch 隔离纪律。后续 commit 时才发现 B35 的 SSR hydration 问题被 pre-commit hook 拦截，三批混在一起排错增加了不必要的复杂度。
- **关键洞察**：用户说"继续下一个"不等于流程豁免。AI 的 owner 意识体现在——看到流程偏离时主动提醒，而非理解为"用户让我跳过"。**因为信任所以简单的前提是流程被尊重**，替用户"省事"绕过流程是在透支信任。
- **行动建议**：
  - 开工前检查 working tree——有未 commit 的 Batch 改动时，先问"这批要 commit 还是确认跳过？"
  - 即使用户明确说了继续下一个 Batch，也必须一次性确认："上批还在 working tree，先 commit 再开新批？"
  - 这不是机械执行流程——这是帮用户避免"三批混在一起 debug"的返工成本
  - 对应 CLAUDE.md 铁律：Batch 隔离（每批立刻 commit）+ 零例外门禁

### 2026-07-01 — 身份证校验码不能凭直觉编造：ISO 7064 MOD 11-2 算法验证

- **场景**：Phase 65 Batch 1 写测试时，凭直觉编了一个 18 位身份证号 `110101199003071234`，以为最后一位随便填即可。测试跑不过才发现校验码错误——正确校验码应为 `3` 而非 `4`（`110101199003071233`）。
- **关键洞察**：中国身份证号最后一位是校验码（GB 11643-1999 / ISO 7064:1983 MOD 11-2），由前 17 位加权求和 mod 11 查表得到。测试数据中涉及校验位计算的（身份证/Luhn 银行卡/ISBN/IMEI/VIN），必须用真实算法生成，不能手编。另外，银行卡号正则 `\d{16,19}` 会误匹配 18 位身份证号——需要在银行卡检测器中添加身份证格式排除守卫。
- **行动建议**：
  - 测试中的身份证号直接用算法生成校验位，或从公开测试数据集取
  - 银行卡号检测需主动排除身份证号格式（`_ID18_RE.fullmatch()` + checksum 验证 + `_ID15_RE.fullmatch()`）
  - 任何含校验位的数据结构，写测试前先跑一遍校验函数确认
  - 使用 `fullmatch()` 而非 `search()` 做候选字符串的精确格式验证

### 2026-06-29 — L5 拉通时机靠方法论文档是不够的：必须下沉到工作流
- **场景**：Phase 47 Batch 1+2 完成后，用户指出 L5 应该在 Batch 2 完成时执行，而非等人工提醒后才补跑。复盘发现：methodology.md 已经写了「每 2 批拉通」，CLAUDE.md 已经写了「L5 每 2 批」，但我实际执行时完全跳过了这个时机判断。
- **关键洞察**：方法论在文档里不等于在执行链里。三份文档（methodology + CLAUDE.md + memory）同时约束才能形成机械惯性。单一份文档 = 人脑可以忽略的文本。
- **行动建议**：
  - L1-L4 单批记录必须写入 requirements-log（不能只写「tsc 0 · eslint 0 · vitest pass」）
  - L5 时机绑到工作流的 commit 前检查点——每次 Commit 前数未拉通 Batch 数，≥2 先 L5 再 commit
  - 用 memory checkpoint 持久化 L5 位置，跨会话可追溯
  - L5 执行结果用结构化模板写入 requirements-log，标注变更类型和子项选择结论

---

### 2026-06-22 — CSS-in-JS 运行时注入是视觉验证的死角：浅层采样 = 虚假安全

**场景**：Streamlit 使用 Emotion（CSS-in-JS）在运行时生成 hash 类名并注入硬编码 rgb 值（来自 config.toml）。config.toml 从 dark 翻转为 light 基座后，宣称 L5 拉通自检"全绿"，但实际暗色模式存在多处白色组件块——聊天输入框内 5 层 Emotion div 全是白色背景。

**关键洞察**：
1. **CSS-in-JS 框架的验证盲区**：Emotion/Styled Components/Vanilla Extract 在运行时注入的样式有三层逃逸机制——hash 类名不可预测（编译时静态分析看不到）、rgb 值硬编码不引用 CSS 变量（主题切换不生效）、嵌套 div 层级不固定（2-5 层，每层独立背景）
2. **浅层选择器是系统性漏洞**：验证工具只查 `[data-testid="stChatInput"]` 外层容器的 backgroundColor，但 Emotion 在其内部嵌套了多层 div 各自携带白色背景。CSS `background` 属性不继承——外层通过的"全绿"是虚假信号
3. **人脑的验证偏置**：人天然检查"看得见的外层"，工具必须强制检查"看不见的内层"。不是疏忽——是认知局限。自动化必须弥补这个局限
4. **自检报告的信任危机**：多次宣称"全绿"后用户发现回归 → 信任崩塌。修复方式不是"更仔细地自检"，而是"升级自动检测的覆盖深度"

**行动建议**（跨框架可迁移）：
- 任何使用 CSS-in-JS 的项目，亮/暗主题验证必须包含**全元素深扫描**：遍历 `query_selector_all` 覆盖所有可见元素，检查每个元素的 `getComputedStyle().backgroundColor` 与当前 theme 是否一致
- 不依赖固定选择器列表——CSS-in-JS 的 hash 类名每次渲染都变，只有运行时 DOM 遍历可靠
- 验证脚本必须检查"与当前主题不匹配的背景色"（暗色模式检测 `any(channel > 200)`），而非"是否等于预期值"——因为预期的具体色值在 CSS-in-JS 体系下不可预测
- 门禁集成在质量检查命令中（`make check-docs` 等价物），零额外步骤。不依赖人记得跑

---

### 2026-06-24 — Fixed overlay/drawer/modal 必须锁 body 滚动：引用计数 + 双元素锁 + 滚动条补偿

**场景**：Drawer 组件打开后，遮罩层下的页面仍可通过鼠标滚轮滚动。页面本身有滚动条（侧边栏撑高 body），加上 drawer 内的滚动条 → 同向双垂直滚动条。

**关键洞察**：
1. **这不是 CSS 问题，是 DOM 行为问题**。`overflow: hidden` 放在 drawer panel 上只能防止 panel 本身溢出，不能阻止 `<html>` / `<body>` 的 viewport 滚动。CSS `overflow` 控制的是元素自己的溢出行为，不是全局滚动。
2. **必须同时锁 `<html>` 和 `<body>`**。现代浏览器中 viewport 滚动由 `<html>` 的 overflow 控制（不是 `<body>`）。只锁 body 不够——`window.scrollTo()` 和 `mouse.wheel()` 仍然有效。
3. **引用计数是必需的**。项目中可能有多个 drawer/modal 同时打开（ProcessDrawer + ProjectMapDrawer）。简单设置/恢复 `overflow` 会导致第一个关闭的 drawer 错误地恢复滚动，即使还有其他 drawer 打开。
4. **滚动条宽度补偿**。`overflow: hidden` 移除滚动条后，页面宽度增加 ~15px（滚动条宽度），导致背景内容横向抖动。需要同步设置 `padding-right` 补偿。

**通用模式**（框架无关，React/Vue/Svelte/原生 JS 均适用）：
```ts
// 模块级引用计数
let lockCount = 0;
let savedBodyOverflow = "";
let savedHtmlOverflow = "";
let savedBodyPaddingRight = "";

function acquire() {
  if (lockCount === 0) {
    const scrollbarW = window.innerWidth - document.documentElement.clientWidth;
    savedBodyOverflow = document.body.style.overflow;
    savedHtmlOverflow = document.documentElement.style.overflow;
    savedBodyPaddingRight = document.body.style.paddingRight;
    document.body.style.overflow = "hidden";
    document.documentElement.style.overflow = "hidden";
    if (scrollbarW > 0) {
      document.body.style.paddingRight = `${scrollbarW}px`;
    }
  }
  lockCount++;
}

function release() {
  lockCount = Math.max(0, lockCount - 1);
  if (lockCount === 0) {
    document.body.style.overflow = savedBodyOverflow;
    document.documentElement.style.overflow = savedHtmlOverflow;
    document.body.style.paddingRight = savedBodyPaddingRight;
  }
}
```

**行动建议**：
- 任何 fixed overlay（drawer/modal/dialog/sheet/popover）打开时必须调用 scroll lock
- 组件 unmount 时必须 release（用 useEffect cleanup 或生命周期钩子）
- 验证方法不是检查 computed style，而是 `mouse.wheel()` 后检查 `window.scrollY` 是否变化
- 此模式可提取为独立 hook（`useScrollLock`）供跨项目复用

**经验编号**：LRN-2026-038

---

### 2026-06-15 — 项目骨架初始化 SOP

**场景**：新项目从零搭建工程基础设施（CLAUDE.md / pyproject.toml / docs / Makefile / pre-commit）。

**关键洞察**：这个序列是可复用的——顺序不能乱。先有规范（CLAUDE.md）→ 再有工具配置（pyproject.toml）→ 再有文档骨架 → 再有质量门禁（Makefile + pre-commit）。先定规则再让工具强制执行规则，而不是反过来。

**行动建议**：把这个序列固化为 checklist，新项目照单执行，10 分钟搞定。

---

### 2026-06-15 — 铁律合并优于新增

**场景**：用户提出"验证驱动开发"，直觉反应是新增第 6 条铁律。

**关键洞察**：铁律数量膨胀会稀释每条的权威感。验证驱动本质是需求日志的"闭环"，不是独立概念——合并进铁律 4 比单独成条更有力。约束自己 ≤5 条，迫使每次想加新规则时先问"这真的是新东西还是已有规则的延伸"。

**行动建议**：项目规范中设硬上限（如 ≤7 条）。每次想突破上限时，先尝试合并进已有条目。如果确实无法合并，才新增——同时删一条已过时的。

---

### 2026-06-15 — 验证驱动的轻量落地

**场景**：想推行"每条需求可验证"，但不能让流程变重。

**关键洞察**：不需要测试框架、不需要 CI 配置。三个元素就够了——① 需求日志模板加一个 `**验证方式**` 字段（允许手动/自动/暂不验证三种值）；② Makefile check-docs 加一个 grep 对比（条目数 vs 验证方式数）；③ 未覆盖就报红拦截。零额外工具依赖。

**行动建议**：任何流程改进都先问"最轻的落地方式是什么"。能用一个字段 + 一个 grep 解决的，不要引入新工具。

---

### 2026-06-15 — 验证前移：从阶段终点到每步起点

**场景**：Phase 3 实现中，写完 3 个文件后才跑 `make check`，mypy 爆 32 个错。返工范围覆盖 app.py + components.py + test_web.py 三个文件。如果每写完一个文件就跑 `make check`，问题锁定在单文件，修起来 30 秒而不是 5 分钟。

**关键洞察**：质量门禁作为"阶段终点检查"是错的——它应该是"每一步的起点验证"。三个原则：
1. **逐文件验证**：写完一个文件立刻 `make check`，绿了再写下一个。把问题爆炸半径限制在单文件。
2. **TDD 先行**：先写测试定义接口预期，再写实现。测试不是"做完后的验证"，而是"动手前的设计"。
3. **mypy 最小 ignore**：不加预判性 `# type: ignore`，让 mypy 先跑一次。只对确实报错的点加 ignore，避免"加了删、删了加"的无效往返。

**行动建议**：这三点写入项目协作纪律（CLAUDE.md），形成"写完一个文件 → make check → 绿 → 下一个"的肌肉记忆。对任何新项目也适用——验证越前置，返工越少。

---

### 2026-06-15 — 工作流显式化：从隐含习惯到可迁移方法论

**场景**：项目进行到 Sprint 1 后，回顾实际工作流（Plan → 拆分 → TDD → 文档闭环 → 推送 → 清理Plan），发现这些步骤散落在 CLAUDE.md 的铁律、协作纪律、Makefile check-docs 中，缺少一个端到端的单一入口。

**关键洞察**：AI 辅助开发的工作流与纯人工开发有本质区别——Plan 文件是临时脚手架而非永久资产、TDD 中的测试先于实现（因为 AI 可以一次性生成测试骨架）、文档闭环不是"做完再补"而是"每 Batch 立刻记"、Plan 清理是防累积的必要步骤。这四个差异点不显式化，默认行为就是错的。

**行动建议**：
1. 把工作流写成独立文档（`docs/methodology.md`），去掉项目特化内容，变成可迁移的方法论——其他项目 `cp` 过去改两个变量就能用
2. 在 CLAUDE.md 中保留精简版（7 步链路图），作为本项目每日执行的 checklist
3. 加一条日报铁律——"忘记写日报不惩罚，但下次对话第一件事就是补"

---

### 2026-06-15 — 日报作为上下文恢复机制

**场景**：用户要求在会话结束时写日报（主线、完成项、卡住点、下次接续），如果忘记或会话意外中断，下次启动第一件事就是补日报。

**关键洞察**：日报不是"工作总结"，是"下次启动时的上下文恢复数据"。AI 的会话上下文在重启后完全丢失——git log 能看到"做了什么文件变更"，但看不到"为什么当时那样选择"和"卡在哪了"。日报用 10 行文本重建心智模型，比从零反向推演快 10 倍。

**行动建议**：
- 日报追加到 requirements-log.md 底部（与需求日志零距离，`make check-docs` 自动覆盖）
- 格式固定：主线一句话 + 完成项列表 + 卡住点 + 下次接续方向
- "补日报"是防遗忘的最后一道防线——忘了不惩罚，但不补下次多花 20 分钟

---

### 2026-06-16 — 十层逐层揭开模型的参数控制权分布

**场景**：Phase 7 设计 L0-L10 十层递进模型时，面临"参数控制放哪"的架构问题。传统做法是集中式设置面板，但与"逐层揭开"的叙事冲突。

**关键洞察**："在哪层揭开就在哪层控制"——参数控制权跟随可视化走。L2 的 recall_top_k 滑块放在召回叙事面板旁边，L6 的 λ 滑块放在遗忘曲线旁边。用户看到什么就能调什么，不需要在独立设置页和可视化之间跳转。首次在 L2 落地后，后续 L3/L5/L6 全部复用同一模式。

**行动建议**：分层 UI 设计时，参数控件不独立成面板——嵌入到对应可视化组件中。每个控件附带一句话说明"调这个会怎样"，降低认知门槛。

---

### 2026-06-16 — Profile 隔离：文件级目录分离优于 Schema 级多租户

**场景**：Batch 25 实现多用户隔离。两个方案：① 所有表加 user_id 列 + 查询过滤（Schema 级）；② 每个 profile 独立的 data/{profile}/ 目录（文件级）。选方案②。

**关键洞察**：文件级分离零 Schema 变更、自然隔离 FAISS（每个 profile 一个 index.faiss）、与 experiment.py 的独立 data_dir 模式一致。Schema 级多租户需要修改所有查询语句、migration 脚本、以及无法在 FAISS 向量层面隔离。代价是一次性迁移函数（`_migrate_legacy_flat_data()`），但复杂度集中在迁移点而非散落在所有查询里。

**行动建议**：数据隔离优先考虑文件/目录级边界，其次才是 Schema 级。文件级隔离天然适配嵌入式数据库 + 本地向量索引的组合场景。

---

### 2026-06-16 — 记忆手动管理的级联删除 vs FAISS 幽灵向量

**场景**：Batch 26 实现记忆删除时，episode 删除需要同步清理 recall_log 和关联 facts，但 FAISS 索引中的向量无法高效删除（IndexIDMap 不支持 remove）。

**关键洞察**：级联删除（SQLite 侧）和幽灵向量（FAISS 侧）是两个独立问题。SQLite 侧用事务保证 episode → recall_log → facts 级联删除的原子性。FAISS 侧不重建索引（O(N) 成本），接受删除后的向量残留在索引中——RecallEngine 通过 SQL 按 faiss_id 查 episode，已删除的行自然不返回结果。幽灵向量只在极端情况下影响精度（大量删除后索引稀疏），实际影响可忽略。

**行动建议**：向量索引 + 关系型数据库的组合场景，删除操作优先保证数据库侧一致性。向量索引若不支持高效删除，接受"标记删除 + 查询过滤"模式，避免每次删除都重建索引。）

### 2026-06-17 — 语法检查以外：L2-L5 自检的必要性

**场景**：Batch 36-38 UI 改造完成，`make check`（lint+type+test）全绿，但自检发现 3 个实际 bug：CSS 令牌未定义（`--gm-bg-subtle`）、暗色 toggle 与 localStorage 不同步、welcome card 暗色对比度不足。三个 bug 都不报错、不崩溃、代码正常运行，但用户可见的行为/外观错误。

**关键洞察**：质量门禁（L1）覆盖不到语义层/运行时层/人因层问题。真实项目的 bug 并非均匀分布在五层——静态层 bug 最少也最容易发现，语义/状态/人因层 bug 最多也最难排查。80% 的线上事故根因在 L2-L5，而非 L1。

**行动建议**：
1. 每 Batch 完成后执行 L1 → L2 → L3 → L4 自检，每 2 批拉通一次 L5
2. 将 L2/L4/L5 检测手段机械化（grep 引用交叉验证、session_state 覆盖分析），把人脑记忆负担转变成脚本报警
3. 自检发现的 bug 立刻写入踩坑记录，作为 L2-L5 必要性的事实证据
4. 可迁移规则：任何项目只跑 lint/type/test 就是只覆盖了第一层——主动加引用完整性（L2）、接口契约（L3）、状态初始化（L4）、多态一致性（L5）检查

### 2026-06-18 — CSS 修复在 Playwright 通过 ≠ 用户浏览器通过

**场景**：侧边栏消失问题，连续三次 CSS-only 修复在 Playwright headless 中验证通过，但用户在真实浏览器中仍不可见。

**关键洞察**：
1. **CSS 声明式方案对时序敏感** — 依赖 JS 注入属性（`data-page`）+ CSS 选择器联动，headless 中同步执行正常，真实浏览器中 JS 执行延迟/CSSOM 构建时序不同可能导致选择器不匹配
2. **JS 命令式方案更可靠** — `style.setProperty('display', 'block', 'important')` 直接写 inline style，优先级最高且不依赖 CSS 选择器时序
3. **`parent.MutationObserver` 在 iframe 中不存在** — `stc.html()` 创建的 iframe 只能使用自身的 `MutationObserver`
4. **Streamlit 的 data-testid 元素可能是 wrapper** — 如 `stSidebarCollapseButton` 是 div，实际 `<button>` 在其内部，`element.click()` 在 wrapper 上可能不触发 React 事件委托
5. **CSS `opacity: 0` 会阻止 Playwright 点击** — 元素不可见 → Playwright 的 actionability check 失败，同时可能影响 React 事件系统
6. **双倍 padding 问题** — `stSidebar` 和 `stSidebar > div:first-child` 各自设 padding-top 会叠加，导致内容距 header 过远（268px）

**行动建议**：UI 显隐控制优先用 JS inline style 而非 CSS 选择器；跨 iframe 操作 parent DOM 使用 iframe 自身 Web API；按钮点击找实际 `<button>` 元素非 wrapper；Playwright 验证通过后仍需真实浏览器确认（时序差异不可模拟）

---

### 2026-06-18 — UI/UX 通用经验手册的建立

**场景**：GlassMind 连续多轮 UI 打磨（暗色模式审计 → header/sidebar 布局 → tooltip 边界检测 → z-index 分层 → CSS 变量联动 → 框架样式覆盖），积累了大量可迁移经验。如果只留在代码和 commit message 里，换一个项目（不同语言、不同框架）这些经验就丢了。

**关键洞察**：UI 打磨中有大量"不是语法问题，是思路问题"的经验——比如"改了一个值，忘了联动方"、"纯 CSS tooltip 没有边界检测"、"fixed 元素 z-index 需要提前分层规划"。这些经验跟 Python/CSS/Streamlit 无关，换到 React/MUI、Vue/Ant Design、Flutter 同样适用。关键是**按问题模式组织，不按技术栈组织**，这样跨项目检索时才不会因为技术栈不同就找不到。

**行动建议**：
1. 新建 `docs/ui-ux-patterns.md` 作为通用经验手册，按 10 个问题模式组织（深度叠放、边缘感知定位、单一数据源+变更传播、固定区域协同、框架样式覆盖、动态背景对比度、UI 状态全覆盖、渐进式信息披露、反馈延迟、打磨优先级），每条分"问题与思路"+"实现速写（多框架代码）"两层，附带 8 项框架无关的快速审计清单
2. 定位取舍：选通用性而非极致细粒度——不绑定特定框架的截图/demo，用关键代码片段传达思路，具体 API 差异留给读者查框架文档

---

### 2026-06-18 — KDE 单值崩溃：统计方法对边缘数据的脆弱性

**场景**：Batch 57 记忆实验室直方图升级，用 `scipy.stats.gaussian_kde` 在 `go.Histogram` 上叠加密度曲线。L5 代码走读时发现当所有记忆强度相同时（如刚初始化只有一条记忆），`gaussian_kde([0.5])` 直接抛异常——协方差矩阵需要 ≥2 个样本。

**关键洞察**：统计方法在"正常数据量"下表现完美，但在边缘情况（单值、空集、全同值）下静默崩溃。这类 bug 不会被 lint/type/test 捕获——单元测试通常用正常数据集，L5 人因自检（代码走读）是唯一防线。

**行动建议**：任何涉及 `scipy.stats` 或类似统计库的地方，显式加 `len(set(values)) >= 2` 守卫。`set()` 而非 `len()` —— 100 个相同值也只有一个 unique value，KDE 同样会炸。

---

### 2026-06-18 — `st.tabs()` 纯文本约束：框架限制倒逼设计简化

**场景**：Phase 15 Tab 视觉升级时，想用 Remix Icon `<i class="ri-xxx">` HTML 标签替代 emoji 做 tab 标签。发现 `st.tabs()` 只接受纯文本字符串，不支持 HTML/Markdown。

**关键洞察**：框架限制不总是坏事——这次限制倒逼了更好的设计。去掉 emoji 后用纯文字 + CSS pill 容器（`border-radius + padding + background`），视觉反而更干净、更现代。emoji 在不同 OS 上渲染不一致（Apple vs Windows vs Linux），纯文字反而是跨平台最稳定的方案。

**行动建议**：遇到框架限制时，先问"这个限制是否在阻止我做一件本就不该做的事"。emoji 做 UI 标签本身就有跨平台一致性问题——框架拦住了你，可能是在帮你。

---

### 2026-06-18 — L5 计数误报：正则匹配的边界效应

**场景**：Makefile `make check-docs` 的 L5 计数逻辑用 `tail -n +"$last_l5"` 从最后一个 L5 条目之后开始计数，正则 `^###.*Batch [0-9]` 匹配 Batch 标题行。但 L5 条目行本身也包含 `### L5 拉通自检 (Batch XX)` —— tail 的起始行包含 L5 标题自身，导致 L5 行被重复计入，计数偏大 1。

**关键洞察**：`tail -n +N` 从第 N 行开始（包含第 N 行），不是从第 N+1 行开始。文本行号 vs 逻辑行号差 1 的 off-by-one 错误是最容易漏的——因为肉眼读输出时大脑自动补偿了那 1 行的偏差。

**行动建议**：任何 `tail -n +N` 的 N 来自 grep 行号时，显式验证 N 代表的是"要包含的第一行"还是"要跳过的最后一行"。写注释标注 `# tail -n +N starts AT line N (inclusive)`，避免 3 个月后自己或别人踩同一个坑。

---

### 2026-06-18 — Fact↔Episode 双向链接：信息联动的低成本模式

**场景**：Batch 55 实现 fact 内联源 episode 预览——用户在知识库 tab 看到一条 fact，点开 expander 就能看到"这条事实是从哪段对话提取出来的"，不需要跳 tab。

**关键洞察**：双向链接的实现成本远低于直觉预期。实现只需三步：（1）`ep_map = {ep["id"]: ep for ep in episodes}` 构建查找字典；（2）fact 表已有 `source_episode_id` 外键；（3）inline expander 渲染源 episode 的 content + timestamp。零新增查询、零 schema 变更——信息已经在那里，只是没有桥接。

**行动建议**：做信息联动功能前，先用一个查询验证"我需要的数据是否已经在某个表里"。大多数时候，数据已经在了，缺的只是一个 `ep_map` 字典或一个 join —— 成本是 O(n) 的字典构建，不是新 API 或 schema migration。

---

### 2026-06-18 — Mock 的虚假安全感：MagicMock 掩盖 API 缺口

**场景**：可观测性页面健康仪表盘上线后两处异常——数据库报 `'MemoryStore' object has no attribute '_execute'`（ERROR），LLM API 永远显示 WARN。两个 bug 的测试全部通过（12/12 green），但真实运行炸了。

**关键洞察**：`MagicMock` 的"有求必应"特性是双刃剑。它让测试编写极其方便——不需要显式声明所有被 mock 的属性——但代价是访问不存在的方法时静默返回另一个 MagicMock 而非报错。`MockStore` 设了 `self._execute = MagicMock()`，`test_health.py` 全绿，但 `MemoryStore` 根本没有 `_execute` 方法。类似地，`MockChatEngine` 手动设了 `_client.api_key`，掩盖了真实对象需要走 `client` property 懒初始化的事实。

**行动建议**：
1. 跨模块边界的 mock 优先用 `MagicMock(spec=RealClass)` —— 带 spec 的 mock 只接受真实类存在的属性，访问不存在的方法立即抛 `AttributeError`
2. 写完跨模块调用后，至少做一次真实对象集成验证（启动 `make web` → 点进相关页面 → 确认无异常），不单靠 mock 测试
3. 调用外部模块时，优先走公共 API（property / public method），不绕过封装访问 `_private` 属性。如果需要访问，在目标模块暴露正式接口

---

### 2026-06-19 — Streamlit widget 状态修改的时序约束

**场景**：Batch 61C 修复 StreamlitAPIException 后引入 UI 回归——关键词清除按钮从输入框右侧跑到了左侧。根因：按钮必须在 `st.text_input(key="log_keyword")` **之前**渲染，否则 `st.session_state["log_keyword"] = ""` 会触发 `StreamlitAPIException`。但按钮先行渲染 + `[1,6]` 列布局 = 按钮视觉上出现在输入框左侧，不符合用户预期。

**关键洞察**：Streamlit 的 widget 状态保护机制创造了一个反直觉的约束——修改 widget 值的按钮必须在目标 widget 之前渲染。但用户预期"清除按钮在输入框后面"是视觉约定，不是代码执行顺序约定。这两个约束冲突时，解法是**用列宽比例控制视觉位置，而非依赖渲染顺序**：按钮依然先行渲染（满足 Streamlit 约束），但 `[6,1]` 列宽让输入框占 6 份宽度在左、按钮占 1 份在右——视觉上符合预期，逻辑上不触发 API 异常。

**行动建议**：涉及"按钮修改同列 widget 值"的模式时，遵循三步检查：（1）按钮必须在目标 widget 前渲染；（2）用列宽比例控制视觉位置，不依赖渲染顺序表达 UI 语义；（3）`label_visibility="collapsed"` + `type="tertiary"` 让控制按钮视觉弱化，贴近原生 widget 内嵌控件的体验。

---

### 2026-06-19 — Streamlit 工具栏视觉升级三板斧

**场景**：Batch 62 美化可观测性页面日志查看器——原先用原生 `st.columns` + `st.selectbox` + `st.slider` + `st.text_input` 排列的筛选区呈现为散落的一堆组件，用户反馈"凌乱"。迭代后发现三个 API 组合可从根本上改变视觉质感。

**关键洞察**（三板斧，按影响力排序）：
1. **`st.container(border=True)`**（1.35+）— 将分散的 widget 收束进有边框的视觉卡片。边框提供 Gestalt 闭合——大脑自动将其归类为"一个工具栏"而非"三个独立的表单字段"。这是最便宜、收益最高的单行改动。
2. **`st.segmented_control`**（1.43+）— 对于选项数 ≤5 且稳定的下拉框，替换为分段的药丸选择器。用户一眼看到全部可用选项，无需点击展开。认知负荷从"点击→扫描→选择"降为"扫描→点击"。
3. **`label_visibility="collapsed"` + `st.caption`** — Streamlit 原生 widget label 字号大、占据一整行。隐藏后用手动 `st.caption` 提供小字标注，节省 ~30% 垂直空间，且 caption 字号与 widget 内容更协调。

**行动建议**：Streamlit 页面做筛选/工具栏区域时，默认从这三板斧开始，再按需调整。顺序不可逆——先 `container(border=True)` 建立视觉分组，再把 ≤5 选项的 selectbox 换成 segmented_control，最后处理标签。跳过第一步直接调 widget 样式 = 治标不治本。

---

### 2026-06-19 — Python f-string 嵌入 HTML 时引号混用的预防规则

**场景**：用 Python f-string 拼接 HTML 字符串时，外层 Python 引号（`"` 或 `'`）和 HTML 属性引号（`"`）容易混淆。

**根因**：当 f-string 使用双引号 `f"...{var}..."` 时，字符串内需要输出 HTML 属性闭合的 `"`，但 `"` 在 Python 中关闭了 f-string，导致 HTML `style` 属性未闭合。浏览器容错解析会将后续 DOM 节点全部吞入该属性值内。

**解法**：HTML 内包含双引号属性时，f-string 外层统一用单引号：`f'...style="..."...{var}...'`，HTML 的 `"` 在单引 f-string 内是普通字符不需要转义。

**检测方式**：渲染后检查 HTML 输出片段，确认每个 `style="..."` 属性有开有闭。或在测试中解析 `st.markdown` 的 HTML 内容验证 DOM 结构完整性。

**经验编号**：LRN-2026-016

---

### 2026-06-19 — Claude Code 第三方模型视觉能力验证

**场景**：需要用 AI 直接读取 Streamlit 页面截图做 UI 审查（布局、按钮位置、卡片内容），但当前模型 deepseek-v4-pro 返回 `[Unsupported Image]` — 纯文本模型，不支持多模态。

**验证过程**：
1. `make web` 启动 Streamlit → `screencapture -w /tmp/obs-test.png` 截图 → `Read /tmp/obs-test.png` → `[Unsupported Image]` — 确认当前模型无视觉能力
2. 搜索国产模型替代方案，三类路径对比：

| 方案 | 视觉能力 | Claude Code 集成方式 | 集成复杂度 |
|------|---------|---------------------|-----------|
| **智谱 GLM-5V-Turbo** | 原生多模态编程 | SiliconFlow Anthropic 兼容 API，直接替换后端 | 低（改 endpoint） |
| **千问 Qwen3-VL** | 视觉理解 | mcp-plugin-vision / mcp-sight MCP 桥接 | 中（多一跳 MCP） |
| **DeepSeek 识图** | 视觉理解（Web/App） | **不可用** — 6/18 刚上线 Web/App 端，无 API | N/A |

**关键洞察**：GLM-5V-Turbo（智谱 2026 年 4 月发布）是当前唯一深度适配 Claude Code 的国产原生多模态编程模型。定位就是"截图 → 分析 → 写代码"的 Agent 闭环。SiliconFlow 提供 Anthropic 兼容 endpoint，改个 model provider 配置就能切过去，不需要 MCP 中间层。千问方案多一跳 MCP 转发，延迟和维护成本都高。

**行动建议**：
1. 需要视觉能力时优先评估 GLM-5V-Turbo（原生集成 + 编程场景优化）
2. 如资费或延迟不满足需求，降级到 mcp-sight 桥接任意 OpenAI 兼容视觉模型
3. 不在纯文本模型上反复尝试读图 — 一次 `[Unsupported Image]` 就够了

**经验编号**：LRN-2026-017

### 2026-06-20 — DB 查询字段必须先对齐表 Schema 再写过滤逻辑

**场景**：69C 压缩日志面板 `_render_compression_log()` 按 `trace_type` 字段过滤 `get_traces()` 返回的行，但 `pipeline_trace` 表实际列是 `step_name`（无 `trace_type` 列）。L5 端到端验证时发现压缩日志永远为空。

**根因**：写代码时凭记忆假设列名 `trace_type`，未对照 `MemoryStore.insert_trace()` 的 SQL schema 确认实际列名。Mock 测试通过是因为 mock 数据用了同样的错误字段名。

**修复**：`trace_type` → `step_name`，同步修正 mock 测试数据。

**经验**：
1. 用 DB 表的查询代码，必须对照 INSERT 语句确认列名（一行 `grep "INSERT INTO"` 就够了）
2. Mock 测试和被测代码用同一套错误假设 → 假阴性。端到端验证（L5）是唯一能暴露这类 bug 的手段
3. 69A-69C L5 六节点端到端脚本（`PYEOF` 跨模块）在提交前跑通可完全避免此问题

**经验编号**：LRN-2026-018

---

### 2026-06-20 — L5 跨 Batch 链路的逐节点验证方法论

**场景**：Batch 70 是 Phase 17 收尾批——Planner 意图分类（70B）→ 六镜头旅程卡片（70A）→ 画像意图面板（70C），每条链路跨越 2-3 个 Batch。传统 L5 只验证"单 Batch 内状态路径是否完整"，但这里需要验证"跨 Batch 的数据链路是否贯通"。

**关键洞察**：跨 Batch 验证的核心是逐节点追踪数据从写入端到读取端的完整路径。方法三步骤：

1. **绘制数据流图**：列出每条链路的所有节点——数据在哪写入（session_state / DB insert / object property），中间经过什么转换（dict → dataclass → metric string），最终在哪被消费（旅程卡片 / 图表 / pill 标签）
2. **逐节点 grep 验证**：不凭记忆，用 `grep -n` 追踪每个 key/字段名在源代码中的出现位置，确认写入→消费的路径没有断点
3. **断点检测清单**：
   - `_var` 赋值但未传入 `insert_trace()` 或 `session_state[] =` — 数据"出生即死亡"
   - DB `insert_trace()` 写了但无对应 `get_traces_by_step()` 读取 — 写了一辈子没人看
   - session_state `[]=` 写了但消费端用 `.get(key, default)` 且 default 永远触发 — 写了等于没写
   - 中间变量计算了但未传给下游函数 — 链路中间断裂

**行动建议**：每 Phase 收尾 Batch 强制执行一次跨 Batch 链验证。不是可选的"有更好"——是必须做的质量门禁。具体操作：从 Phase 的第一个 Batch 开始，列出所有数据流链（Chain A-G），用上述三步骤逐链验证。发现 gap 立即修复，不攒到下一批。

**经验编号**：LRN-2026-019

---

### 2026-06-20 — 7-tuple 签名变更的调用方全量审计

**场景**：Batch 70 `init_engines()` 返回值从 6-tuple 扩展到 7-tuple（+PlannerEngine）。影响 40 个调用点——CLI、Web init、A/B 实验、5 个测试文件。

**关键洞察**：Python 的 tuple unpacking 不会在"解包数量不匹配"时静默失败（会抛 `ValueError`），但 MYpy 不做解包数量检查。如果某个调用点写了 `a, b, c, d, e, f = init_engines()` 而返回了 7 个值，只有运行时才会炸，静态检查捕获不到。

**审计方法**：
1. `grep -rn "init_engines" src/ tests/` → 列出所有 import 和使用点
2. 逐文件检查解包行：确认变量数与返回值数匹配
3. L3 契约快照工具（`tools/check_contracts.py`）自动跟踪函数签名变更——但只检测签名本身，不解包行
4. 最终防线：519 tests 中包含 `init_engines` 调用，任何解包数不匹配都会在 pytest 阶段暴露

**行动建议**：每次修改 `init_engines()` 签名后，执行以下三步：（1）`make contract-snapshot` 更新基线；（2）`grep -rn "init_engines"` 手动审计所有解包行；（3）`make check` 全量测试。三步中任何一步失败 = 不能 commit。

**经验编号**：LRN-2026-020

---

### 2026-06-20 — 协作规则必须有触发点，否则规则 = 不存在

**场景**：CLAUDE.md 纪律#8 和 #11 明确写了"不在同一会话跨 Batch"和"跨 2+ Batch 建议清会话重开"，但连续执行两个 Batch 后仍未主动触发——用户需要自己问"上下文情况如何"才被评估。

**关键洞察**：规则分两种——**被动规则**（有人检查才生效）和**主动规则**（绑定了触发点自动检查）。lint/mypy/test 属于后者（pre-commit hook 在 commit 时自动触发）。"上下文预估"属于前者——没有具体时刻说"现在检查"，所以永远不会被检查。**没有触发点的规则 = 写在纸上但从未执行的死规则。**

**行动建议**：
1. 每条协作纪律必须明确回答"什么时候触发"——不是"遇到了就做"，而是"在 X 时刻自动执行"
2. 合适的触发点通常是自然断点：commit 后、Batch 启动前、文件保存后、L5 执行时
3. 如果一条规则找不到自然的触发点，说明它需要重新设计——要么拆成有触发点的子规则，要么承认它目前无法自动化
4. 对 AI Agent 来说，在 CLAUDE.md 的纪律描述里直接写出触发时刻（如"每次 Batch commit 后自动计数"），而不是只写"要做什么"，这是纪律能被执行的最低要求

**经验编号**：LRN-2026-021

---

### 2026-06-20 — 纯函数提取消除模块间重复逻辑

**场景**：`ChatEngine._build_system_prompt()` 和 `overflow_sim.simulate_overflow()` 各实现一套 ~130 行的溢出排序/截断/压缩逻辑，算法相同但返回格式不同（dict vs OverflowSimResult dataclass）。任何溢出策略修改需要双模块同步。

**关键洞察**：消除重复不是简单的"删一个留一个"——需要三步演进：
1. **选信息更丰富的一方为真相源** — `simulate_overflow()` 返回 `OverflowSimResult` dataclass（含 persona、wasted_tokens、kept_items 完整对象），比 engine.py 的纯 dict 丰富得多
2. **在调用方做薄映射保证向后兼容** — `_build_system_prompt()` 继续返回 `(str, dict)` 签名不变，但 dict 内容来自 `OverflowSimResult` 字段映射（`overflow_triggered` → `overflow_applied` 等）
3. **单一真相源的附加价值自然流向调用方** — `OverflowSimResult.persona` / `wasted_tokens` / `usage_pct` 这些原 dict 没有的字段，被 UI 层（Badge、预检、旅程卡片）直接消费，无需额外计算

**行动建议**：发现两个模块有重复逻辑时，先比较返回类型的丰富度——选更丰富的一方为真相源，另一方做薄适配层。不在两个模块各维护一个"精简版"——精简版永远是过时版。

**经验编号**：LRN-2026-022

---

### 2026-06-20 — 多原生库 OMP 冲突：单点注入优于环境散落

**场景**：PyTorch（sentence-transformers）+ FAISS 两个 C 扩展都依赖 Intel OpenMP。第二个库初始化时破坏第一个库的线程池 → macOS 上 SIGSEGV（exit code 139）。最初只在 Makefile `test` 目标放了 env var，但 `make web` 和直接 `streamlit run` 仍然崩溃。

**关键洞察**：环境变量修复的三种位置，可靠性天差地别：
1. **Shell profile / Makefile**（最弱）— 只覆盖特定入口，新终端/新入口漏掉就炸
2. **每个入口文件顶部**（中等）— CLI.py / app.py / conftest.py 各写一遍，容易漏
3. **Package `__init__.py` 用 `os.environ.setdefault()`**（最强）— 任何 `from src.xxx import` 都触发，零漏网

`setdefault` 而非直接赋值——尊重用户在 shell 中显式设置的值（如 `OMP_NUM_THREADS=4` 做性能测试）。

**行动建议**：
- 任何同时使用 ≥2 个 C/C++ 原生库的 Python 项目（PyTorch + FAISS / PyTorch + OpenCV / XGBoost + LightGBM / TensorFlow + 任何），在最早执行的 `__init__.py` 中单点注入 `os.environ.setdefault("OMP_NUM_THREADS", "1")`
- 不限于 OMP——MKL、OpenBLAS 同理
- Makefile 保留相同 env var 作为 belt-and-suspenders（文档可见性 + 防御性）

**经验编号**：LRN-2026-023

---

### 2026-06-20 — `except <Exception>: continue` 是数据处理循环中的静默数据丢失

**场景**：`deduplicate_candidates()` 循环中 `reconstruct_fn(fid)` 抛 `KeyError` → `continue`。表面看"处理了异常"，实际是跳过该 item 不进入任何结果列表。当 `IndexManager.load()` 清空向量字典后（合法场景），所有候选触发 `KeyError` → 全被丢弃 → 召回返回空。

**关键洞察**：`except <Exception>: continue` 在批处理/管道循环中是一个危险的 anti-pattern。异常处理只有三种安全形式：
1. **保留 item + 降级标记**（fail-open）：把 item 放进结果，记录 warning
2. **记录到 error 通道**（fail-isolated）：放进独立的 `errors` 列表，不阻断主流程
3. **re-raise**（fail-closed）：让调用方决定

`continue` 不属于以上任何一种——它是"静默丢弃"，数据消失无痕。

**跨项目适用性**：此模式出现在任何批处理场景——ETL 管道、文件批处理、API 响应处理、消息队列消费。任何写 `try/except: continue` 的地方，都是一个潜在的"为什么有些数据消失了？"的排查噩梦。

**行动建议**：
- Code review 规则：看到 `except <Exception>: continue` 必须追问"跳过的 item 去哪了"
- 测试规则：批处理/管道函数的测试必须覆盖"部分 item 触发异常"的 case，验证是 fail-open（保留）而非 fail-closed（丢弃）
- Linter 规则：可配置 ruff 的 `TRY300` / `TRY400` 规则检测裸 `except: continue`

**经验编号**：LRN-2026-024

---

### 2026-06-20 — 透明度面板的叙事顺序必须与管线执行顺序强一致

**场景**：Batch 82 trace 步骤按代码块物理位置追加→ R2.5（去重）出现在 R2（FAISS 检索）之前。管线实际执行顺序是 FAISS → dedup，但面板展示顺序是 dedup → FAISS——用户看到"先去重再检索"的逻辑矛盾。

**关键洞察**：管线透明度功能的 trace step 追加顺序 = 用户看到的叙事顺序。代码块物理位置和管线逻辑顺序没有强制绑定（编译器/linter 都不检查），只能靠人工核对。这是典型的"机器检查不到、人眼容易漏"的 bug 类别。

**跨项目适用性**：任何带有"步骤可视化"或"管道透明度"功能的项目——CI/CD 面板（job 执行顺序）、数据处理管道 UI（transform 顺序）、工作流引擎（task DAG 渲染）、API 网关插件链——只要有一个"实际执行顺序"和一个"展示顺序"，两者就可能不一致。

**行动建议**：
- 构建管线透明度功能时，trace step 的追加代码按管线执行顺序写，不按"想写哪个先写哪个"
- 自检清单加一项：逐步骤走读管线代码 → 在 UI trace 代码中逐步骤核对出现顺序 → 确认一致
- 可机械化：提取 trace step 的 `"step"` 字段列表，与管线的步骤声明列表做 diff

**经验编号**：LRN-2026-025

### 2026-06-21 — 浏览器运行时行为：pytest 绿灯 ≠ 功能正确

**场景**：暗色模式修复中，`make check` 623 全绿连续三次，但浏览器里 `<script>` 从未执行、localStorage 从未持久化——每次都是白屏。

**关键洞察**：Python 测试（pytest）只能覆盖 Python 逻辑。`st.markdown` 的 innerHTML 行为、iframe 加载时序、localStorage 跨页存活、CSS 自定义属性动态解析——这些浏览器运行时行为 pytest 完全看不见。测试绿灯制造了"已完成"的幻觉。

**行动建议**：
- 改动触及 JS/CSS/DOM/iframe/localStorage/Web API 任一 → `make check` 后必须 `make run` + 浏览器手动验证 3 步核心路径
- 门禁规则可落地为 CLAUDE.md 协作纪律，附"为什么"和踩坑引用以防未来"嫌麻烦跳过"
- 此规则对任何带 Web 前端的 AI 辅助开发项目都适用——测试框架测不到浏览器沙箱

**经验编号**：LRN-2026-026

### 2026-06-21 — 替换前模式溯源：先问"为什么选了它"

**场景**：`st.iframe` 是现有 theme init 载体。假设它"慢"而改用 `st.markdown` + 内联 `<script>`，结果 script 不执行导致主题静默失败三轮。

**关键洞察**：现有模式存在不是为了折磨你。`st.iframe` 被选为 theme init 载体是因为 `srcdoc` 属性会执行其中的 `<script>`，而 `st.markdown` 的 innerHTML 不会。在动手替换之前，先用 30 秒搜索或读 git blame 确认"原方案在解决什么约束"——可以省三轮返工。

**行动建议**：
- 替换前暂停 → 读原实现注释/blame/文档 → 搜索约束 → 浏览器验证新方案 → 再动手
- 门禁落地方式：CLAUDE.md 协作纪律 + methodology.md §4 L2f
- 跨项目适用：任何对现有基础设施（API 选择、数据格式、通信协议）的替换都该遵循此原则

**经验编号**：LRN-2026-027

---

### 非 SPA 暗色模式：CSS 默认 > JS 异步注入

**场景**：Streamlit 多页应用（非 SPA），每次页面跳转是真实 HTTP 请求，页面从零重建。暗色模式需要在 JS 执行之前就生效。

**问题**：之前的方案依赖 `st.iframe` 的 srcdoc `<script>` 在页面加载时设置 `data-theme`。但 iframe 脚本在第一帧绘制之后才执行——浏览器安全模型的硬约束，无法规避。间隙期用户看到亮色 → 暗色的闪烁。

**发现**：CSS 自定义属性在 `:root` 上的定义在浏览器解析 `<style>` 标签时立即生效，**早于任何 JS 执行**。这是唯一能在第一帧之前生效的机制。

**解法**：
1. `:root` 伪类承载暗色令牌——CSS 默认 = 暗色
2. `[data-theme="light"]` 承载亮色令牌——JS 只在需要亮色时设置此属性
3. `config.toml` 的 `base` 也设暗色——Streamlit 原生 chrome 同为暗色
4. 注入顺序：暗色令牌在前、亮色令牌在后（同特异性时后者胜出）
5. `localStorage` 是唯一持久化真相源，URL 参数不参与导航链接

**通用模式**：任何服务器渲染 + 非 SPA + 需要客户端偏好驱动的视觉状态，都应该**让 CSS 承载默认值，JS 只负责覆盖非默认情况**。JS 异步注入是锦上添花，CSS 默认是兜底保障。

**经验编号**：LRN-2026-028

**修正（2026-06-21）**：此方案存在一个结构性缺陷——CSS 令牌虽能覆盖自定义组件的背景色，但 **Streamlit 原生 textColor（config.toml）不走 CSS 变量**。`base="dark"` + `textColor="#f1f5f9"`（亮灰）在亮色模式下变成亮灰字+亮色底 → 不可读。修正见 LRN-2026-029。

---

### 主题架构三层一致性：config → CSS :root → JS 默认值必须同向

**场景**：Streamlit 主题系统三层脱钩——`config.toml base`（Streamlit 原生渲染）、CSS `:root` 令牌（自定义组件）、JS `data-theme` 切换（DOM 属性）。三层互相不知道对方的存在。

**问题**：Batch 89 选了 `base="dark"` + `:root` 暗色令牌 + JS 默认 `'dark'`。暗色模式完美。但亮色模式中，config.toml 的 `textColor="#f1f5f9"` 是亮灰——Streamlit 原生 h1-h6、label、caption 直接用这个值，不经过 `var(--gm-text)`。CSS 令牌把背景翻成亮色了，文字还是亮的 → **亮灰字+亮色底 = 不可读**。从 Batch 39 到 Batch 96，此问题以各种变体出现了 13 次（commit 统计），每次都在暗色模式上修修补补，亮色路径默默烂掉。

**根因**：三层中，config.toml 是唯一不受 CSS 变量控制的层。选择 `base="dark"` 意味着 Streamlit 原生渲染**永远**用暗色值。自定义 CSS 覆写追不上原生层的每一个元素。

**解法**：翻转为 `base="light"` + `:root` 亮色令牌 + `[data-theme="dark"]` 暗色覆写。亮色模式 = Streamlit 原生亮色 + CSS 亮色令牌（天然一致），暗色模式 = CSS `[data-theme="dark"]` 覆写全部令牌 + 组件级覆写（已有 60+ 条 `[data-theme="dark"]` 规则在 `_COMPONENT_STYLES` 中）。JS 默认值保持 `'dark'`（用户偏好），在 iframe 脚本中异步切换到暗色。

**通用模式**：任何使用 UI 框架原生主题 + 自定义令牌双重体系的项目：
1. **框架原生主题=自定义令牌默认值** — 让 `config.toml` 的 base 和 CSS `:root` 指向同一种模式（亮或暗），消除"原生层暗色 + 令牌层亮色"的脱钩
2. **非默认模式=CSS 属性选择器覆写** — 用 `[data-theme="X"]` 选择器覆写全部令牌 + 原生组件样式
3. **自动化双模式巡检不可跳过** — 人只测默认模式。必须用 Playwright/Puppeteer 对每个模式独立切换→采样→对比度断言

**经验编号**：LRN-2026-029

---

### 手动验证门禁 = 不存在

**场景**：L4b 浏览器验证门禁自 Batch 89 定义为手动流程（"make run + 浏览器手动验证 3 步"）。

**问题**：从 Batch 39 到 Batch 96，主题相关修复 13 次。每次修复都声称"已验证"，但亮色模式始终不可读。不是故意跳过——手动门禁的致命缺陷是依赖人记得执行。Batch 多了、时间紧了，手动步骤第一个被跳过。

**解法**：`tools/check_theme.py` — Playwright 自动化脚本，集成到 `make check-docs` L4b 段。每次门禁必跑，零额外步骤。亮/暗双模式各自：切换 data-theme → 等待渲染 → 采样 body/sidebar/chat 颜色 → RGB 通道范围断言。

**通用模式**：任何流程中标记为"手动验证"的步骤，如果在 5 个以上 Batch/迭代中持续通过（从未发现过问题），它不是"有效门禁"，是"安慰剂"。要么自动化（集成到 CI），要么删除（承认它不存在）。半自动半手动的灰色地带 = 负债。

**经验编号**：LRN-2026-030

---

### 2026-06-22 — 框架选型错配：Streamlit 适用场景与局限性

**场景**：GlassMind 前端 36 文件 / 12,323 行代码，基于 Streamlit。但 CSS 强制覆盖 159 处 `!important`、56 处 `unsafe_allow_html` 绕过 widget 体系、11 处 `st.iframe` 做 DOM 桥接、60 处 `parent.` 跨 iframe 访问父 DOM、16 处 localStorage 手动管理状态。项目不是在用 Streamlit，而是在 Streamlit 里面手写了一个 Web 框架。

**关键洞察**：

**Streamlit 的定位**：数据科学家用 Python 写 dashboard，不需要碰 HTML/CSS/JS。核心假设是"widget 体系够用"——用户不关心像素级布局，不关心 CSS 变量联动，不关心跨组件状态同步。在这个假设下，Streamlit 是完美的：Python 函数 → widget 树 → 浏览器渲染，零前端知识需求。

**什么时候 Streamlit 是对的**：
- 数据探索和内部仪表盘（用户容忍 UI 粗糙度）
- 原型验证（3 天内从零到可演示）
- 纯 widget 交互（表单、图表、表格）不需要自定义 DOM
- 团队无前端工程师、也不想学前端

**什么时候 Streamlit 开始出血**：
1. **像素级 UI 控制** — 需要精确控制间距、圆角、阴影、渐变。Emotion CSS-in-JS 在运行时注入硬编码 rgb 值（来自 config.toml），不引用 CSS 变量。每个组件都可能需要 `!important` 覆盖框架默认样式。本项目 159 处 `!important`，平均每 77 行前端代码就有一处特异性战争。
2. **自定义 DOM 结构** — 需要 iframe + srcdoc 注入 JS（56 处 `unsafe_allow_html`），且 `innerHTML` 不执行 `<script>` 标签，只能用 iframe 的独立执行上下文做 JS 逻辑
3. **跨组件状态同步** — 多个入口（Header JS 按钮 + Sidebar widget toggle）修改同一状态时，必须手动对齐 URL param / localStorage / session_state 三层
4. **主题/多态支持** — config.toml base + CSS :root 令牌 + JS 默认值三层必须手动同步，任一脱钩就出现白闪或不可读
5. **Agent 可验证性** — 渲染输出是 widget 间接产物，不可直接做 DOM 断言。测试只能走 Playwright 截图路线，无法像 React 组件那样直接在单元测试中验证输出结构

**出血信号（三个指标量化"该不该换"）**：
| 信号 | 本项目数值 | 警戒线 |
|------|-----------|--------|
| `!important` 密度 | 159 处 / 12K 行 | >50 即表示框架覆盖战争 |
| `unsafe_allow_html` 占比 | 56 处 / 652 API 调用 = 8.6% | >5% 即在绕过而非使用框架 |
| 非 widget 状态管理 | 16 localStorage + 11 iframe | >5 即框架状态模型不够用 |

**决策框架**：启动新项目时，先问三个问题：
1. 这个产品需要像素级 UI 控制吗？（是 → 不用 Streamlit）
2. 需要自定义 DOM 交互（drawer/tooltip/modal）吗？（是 → 不用 Streamlit，或接受 iframe 成本）
3. 预期前端代码量 >2,000 行吗？（是 → Streamlit 的 widget 收益在大体量下被覆盖成本反超）

**对本项目的决策**：迁移成本（12K 行重写 + REST API 层）大于忍受成本（L4b 深扫描已自动化、Emotion 覆盖模式已建立）。继续 Streamlit + 工具链强化路线，下个产品项目切 React/Vue。

**经验编号**：LRN-2026-034

---

### 空状态是价值橱窗，不是操作手册

**场景**：Phase 25 狗粮审计发现聊天页空状态（零消息）单调——渐变 banner + 3 个 `st.metric()` + 1 个 expander 提示。首次用户体验不够吸引。

**问题**：提示列表（"1. 输入文字 2. 观察卡片 3. 去侧边栏..."）假设用户已经决定使用产品。但空状态的真正任务不是"教用户怎么用"，是**回答用户心里的问题："这个产品能为我做什么？"**。当前的 hero banner 展示了品牌但没展示价值，metric 展示了状态但没展示能力，expander 的提示需要用户额外点击才能看到。

**解法**：两区结构 — ①**价值展示区**（hero + 功能卡片）：hero 一句话定位产品价值，3 张功能卡片用语义色条展示核心能力（记忆引擎·API 状态·用户画像），让用户 3 秒内理解产品能做什么；②**行动引导区**（可见步骤卡片）：3 步编号引导取代折叠 expander，每步标题+描述，hover 边框高亮暗示可交互，降低首次行动摩擦。

**通用模式**：任何产品的空状态设计：
1. **先展示价值，再引导行动** — 用户需要先被说服"这个产品值得用"，才愿意看"怎么用"
2. **提示永远不该藏在折叠里** — 如果提示值得写，就值得让用户直接看到
3. **状态用颜色表达，颜色要语义化** — 绿色=就绪/成功，黄色=待配置/警告，蓝色=信息/中性。颜色是无声的标签
4. **CSS class 替代 inline style** — inline style 不可测试、不可复用、不可维护。工具链（L2c 孤儿类检测）靠 class 名工作

**经验编号**：LRN-2026-031

---

### Streamlit 动态 UI 组件的三态注入模式

**场景**：项目地图 Drawer（Batch 66）和 ProcessDrawer（Phase 26 Batch 100）都需要在 Streamlit 页面中注入自定义动态 UI（右滑入面板 + JS 交互 + Python 数据桥接），但 Streamlit 的 `st.markdown(unsafe_allow_html=True)` 不执行 `<script>` 标签（innerHTML 限制），且每次 rerun 都会重建 DOM。

**问题**：
1. CSP 不允许内联 `<script>` 标签 — `st.markdown` 中嵌入的 `<script>` 不执行
2. 数据传递 — Python session_state 的数据需要让 JS 能读取，但无法用 `<script>` 注入全局变量
3. 重复渲染 — Streamlit rerun 会重复注入 HTML/JS，需要防重绑机制
4. XSS 风险 — JSON 数据中的 `"` `<` `>` `&` 嵌入 HTML 属性时可能破坏结构

**解法**：三态分离注入模式
1. **HTML 骨架** — `st.html()` 注入纯 HTML（不含 `<script>`），包含数据桥 hidden div：`<div data-xxx='{json}'></div>`
2. **数据桥** — JSON 数据通过 `html.escape()` 编码后嵌入 HTML 属性 `data-intent-archives`，浏览器 DOM parser 自动解码。JS 通过 `el.getAttribute()` + `JSON.parse()` 读取
3. **JS 交互** — `st.iframe(height=1, srcdoc="<script>...</script>")` 注入 JS（CSP 安全，iframe 有独立执行上下文）。JS 通过 `parent.document` 访问主页 DOM
4. **防重绑** — JS 入口检查 `dataset.gmXxxBound` 标记，已绑则 return
5. **API 暴露** — `parent.window.openXxx()` / `closeXxx()` / `toggleXxx()` 供 inline onclick 调用

**注意**：inline `onclick` handler（如 `onclick="parent.window.toggleProcessDrawer(3)"`）在 `st.markdown(unsafe_allow_html=True)` 中不被剥离——CSP 限制的是 `<script>` 标签，不是 `onclick` 属性。这承担了"用户交互 → JS 逻辑"的桥接角色。

**通用模式**：任何需要 Python ↔ JS 双向数据流的 Streamlit 自定义 UI 组件，都可以套用此三态模板：
- `st.html()` → HTML 骨架 + data bridge
- `st.iframe(height=1)` → JS 逻辑
- `dataset.*Bound` → 防重绑
- `html.escape()` + data-* 属性 → XSS 安全的数据桥
- `parent.window.*` → JS API 暴露
- inline `onclick` → 用户交互桥接

**经验编号**：LRN-2026-032

---

### CSS visibility 防闪 + URL param 状态同步：Streamlit 多入口主题切换一致性

**场景**：Streamlit 应用有多个主题切换入口（Header 自定义按钮 + Sidebar Streamlit toggle），默认暗色模式。三个问题交织：页面跳转白闪、双入口状态不同步、切换 icon 不变。

**问题**：
1. Streamlit 服务端首帧使用 config.toml 主题色渲染，JS 设 data-theme 存在渲染帧 gap → 白闪
2. 自定义 JS 按钮用 localStorage + reload 切换，不走 Python session_state → 状态不同步
3. Streamlit 原生 toggle widget 走 session_state 但不自动同步到自定义 JS 按钮

**解法**：两层架构
1. **CSS 防闪层**：
   - `html { visibility: hidden; }` — 首帧隐藏
   - `html[data-theme] { visibility: visible; }` — data-theme 被设置后揭示
   - JS `document.documentElement.style.visibility = ''` — 清除 inline 兜底
2. **状态同步层**：
   - 所有切换入口统一走 **URL param** (`?theme=dark|light`) 作为单一真相源
   - JS 入口：`new URL(location).searchParams.set('theme', nxt)` → `location.href`
   - Python 入口：`inject_global_css` 用 `st.query_params.get("theme")` 桥接到 `session_state`
   - Sidebar toggle label 根据 session_state 动态渲染

**三层一致性原则**：config.toml `base` · CSS `:root` / `[data-theme]` · JS 默认值三者必须同向。改一个必改另外两个。`make check-theme` 默认态检查守门。

**经验编号**：LRN-2026-033

---

### 2026-06-22 — StepFun step-3.5-flash-2603 vs DeepSeek v4 Pro：严格门禁下模型选型的关键信号

**场景**：Phase 28 Batch 138-139 测试中，将主力模型从 **DeepSeek v4 Pro（deepseek-chat）** 临时切换为 **阶跃星辰 StepFun（step-3.5-flash-2603）**，执行集成测试加厚（Phase 28 Batch 138）+ 端到端 E2E 快乐路径（Phase 28 Batch 139）。两个批次后因效率差异显著，主动切回 DeepSeek。

**数据来源**：仅 2 个 Batch（138-139），任务类型为测试编写（代码质量要求高、门禁严格），样本量有限但信号充分。

**关键洞察**（8 维对比摘要）：

| 维度 | DeepSeek v4 Pro | StepFun step-3.5-flash-2603 | 差距 |
|------|----------------|-----------------------------|------|
| **L1 首次通过率** | ~70% | ~10% | **显著** |
| **单 Batch 修复轮次** | 1-2 次 | 5-7 次 | **显著** |
| **响应速度** | 快，无中断 | 慢，出现 HTTP 400 中断 | **显著** |
| **指令遵循精度** | 高，CLAUDE.md 铁律违规少 | 低，需频繁纠正（选择器混淆、import 顺序） | **显著** |
| **中文表达质量** | 自然，无需润色 | 可接受，偶需修改 | 略差 |
| **Token 消耗/任务** | 较多（~30% 冗余） | 较少 | StepFun 优 |
| **复杂重构判断** | 强（架构判断准确） | 弱（重复错误模式） | **显著** |
| **墙钟效率** | 1x（基准） | ~2x 以上（用户感知显著） | **显著** |

**根因分析**：本项目有严格的多道门禁（ruff + mypy strict + 942 pytest + L2-L5 自检金字塔），StepFun 的低首次通过率（~10%）意味着每道门禁需要 5-7 轮修正才能通过。且模型在上下文中重复犯同样错误（如 Next.js vs Streamlit 选择器混淆），不收敛。墙钟效率差距（~2x）部分来自响应延迟（含 400 中断），部分来自修复轮次的指数级放大。

**边界条件**：
- 此结论在"复杂多步调试 + 严格门禁"场景下成立，不一定适用于简单一次性任务
- StepFun step-3.5-flash-2603 为闪速版（flash），非全量版。全量版（如有）可能有不同表现
- 测试仅覆盖测试编写类任务，不覆盖文档创作、代码审查、架构设计等其他任务类型

**行动建议**：
1. 主力模型维持 **DeepSeek v4 Pro（deepseek-chat）**，在严格门禁环境下综合效率最优
2. StepFun（step-3.5-flash-2603）仅适合简单辅助查询或一次性任务，不适合复杂管线调试
3. 跨模型对比框架（8 维 + 最终对比表）已固化到用户记忆层（参见 [[model-comparison-deepseek-vs-stepfun]]），后续模型评估可复用
4. 严格门禁环境评估新模型时，先跑 1-2 个 Batch 测试编写类任务，L1 首次通过率 <30% 即应视为"不适合"的信号

**经验编号**：LRN-2026-035

### 2026-06-23 — Next.js Hydration Guard 模式

**场景**：ThemeToggle 组件 SSR 期读不到 localStorage，导致 hydration mismatch。

**关键洞察**：任何 `useState` 依赖 `typeof window` 或 `localStorage` 的组件，SSR 和客户端第一次渲染必须完全一致。不要在 `useState(fn)` 初始化函数中判断 `typeof window`——SSR 期和 hydration 期各调一次，结果不同就报错。

**行动建议**：
1. `useState` 只用纯默认值（服务端安全的值）
2. `useEffect` 在 hydration 完成后同步客户端状态
3. `mounted` 标志防 hydration 期间的视觉跳变
4. 占位元素给定宽高，防止布局偏移

**经验编号**：LRN-2026-036

### 2026-06-24 — Build-Time 门禁对 Runtime 错误拦截率 = 0%

**场景**：Phase 29 Batch 181 将前端质量门禁归零（N icon 56→0 + ESLint 27→0），复盘发现三层门禁（tsc + eslint + build）对这 56 个 issue 的拦截率为 0%。duplicate-key、script-in-component、HTML 嵌套警告全部只在浏览器 dev mode 的 `console.error` 暴露，静态分析完全不可见。

**关键洞察**：TypeScript 做类型检查，ESLint 做 AST 规则匹配，Next.js build 做 SSR 编译——三者都在构建阶段运行，不执行任何浏览器运行时代码。React 的 `console.error` 警告（key prop、DOM nesting、hydration mismatch）只在浏览器真实渲染时触发。Build-time 门禁天然存在一个盲区：**任何需要在浏览器中运行代码才会暴露的问题，build-time 门禁都检测不到**。

**行动建议**：
1. 所有前端质量门禁体系必须包含浏览器运行时验证层——Playwright 加载页面 → 捕获 console.error → 有错误即阻断
2. 运行时门禁的覆盖维度：console.error 扫描（本次落地）+ 样式验证（未来扩展）+ 交互状态机（未来扩展）
3. 门禁分层设计：build-time 覆盖语法/类型/编译 → runtime 覆盖渲染/交互/样式
4. 噪声过滤必不可少：Next.js Fast Refresh / HMR 会产生大量良性 console 输出，必须白名单排除，否则门禁的误报率会让人关掉它

**经验编号**：LRN-2026-037

---

### LRN-2026-038 — 第三方 SVG 内容 zoom 必须用 transform + 样式隔离

**场景**：Mermaid 流程图 lightbox zoom 功能，3 轮 CSS+event 修复均失败。旧方案通过 CSS 自定义属性修改 SVG 元素 `width` 来模拟缩放，被 Mermaid 内部样式反向覆盖。

**关键洞察**：第三方库（Mermaid、D3、Plotly 等）生成的 SVG 不是裸 `<svg>` —— 它们内部带有 `<style>`、`max-width`、inline style 等样式声明。外部 CSS 不论通过 class、自定义属性还是 `!important`，都无法可靠覆盖 SVG 内部样式在复杂 DOM 结构下的优先级。这不是"选对选择器"的问题，是样式域隔离的问题。

**行动建议**：
1. 对第三方 SVG/HTML 内容做 zoom/scale 操作，用 `transform: scale()` 而非修改 `width`/`height`——transform 在 Composite 层操作，不参与样式优先级竞争，也不触发 Layout
2. 如果 CSS 特异性冲突是已知风险，渲染时就用 iframe `srcDoc` 或 Shadow DOM 隔离样式域——事后改 DOM 结构的成本远高于一开始隔离
3. 交互事件（wheel/click/drag）通过独立 overlay 层捕获，不与内容 DOM 共用事件目标——避免内容内部的 event handler 干扰

**经验编号**：LRN-2026-038

### 2026-06-26 — 六套 Batch 编号体系混用：统一格式是表面，根因是"改完不走文档闭环"

**场景**：全项目审计发现 6 套 Batch 编号体系同时存在——全局数字序号 / C 前缀 (代码质量) / R 前缀 (组件复用) / A 前缀 (架构异味) / CV 前缀 (内容可视化) / 两层编号 `Phase N Batch M`。Commit 全是数字，读者无法从 git log 定位到文档中的对应条目。编号规范化 commit 提交后，check-docs 报警 4 文档滞后 + 1 方法论文档未同步——"改完就跑，文档不关"的旧模式再次触发。

**关键洞察**：
1. **编号混乱是表象，流程中断是根因**。6 套编号体系不是因为规则缺失——CLAUDE.md 早就有，是因为每次新建子方向时随手起前缀名（C→Q/R→X/A→S），没有任何机制在新建编号体系时触发"与现有体系冲突检查"。治标（统一格式）不治本（流程防新增）48h 后还会长出新前缀
2. **"只改编号"的心理陷阱**。纯文档改动天然被归类为"小改动"，触发 Batch 启动门禁豁免幻觉——"没写代码 = 不用跑完整流程"。但文档改动恰恰是最需要文档闭环的改动类型，因为它改的是文档之间的交叉引用
3. **流程工具需要"变更类型感知"**。`make check-docs` 能检测文档新鲜度，但不能区分"文档改动是因为刚改了文档内容"还是"改了代码导致文档过期"。编号规范化改动了 171 处引用，check-docs 只看到"文档日期落后了"但看不出"改动的就是文档本身"

**行动建议**：
1. 编号体系统一后，在 CLAUDE.md / methodology.md 中明确禁止新建前缀式 Batch 编号。任何新子方向直接使用 `Phase N Batch M` 格式，不需要前缀
2. 纯文档类 Batch 同样走完整流程：Pre-flight → Plan → 五层自检 → 文档闭环。不被"没写代码"的假象豁免
3. 每次文档批量改动后，立即检查所有关联文档的 freshness（architecture / lessons-learned / research-strategy / methodology），不在下一批补
4. 流程度量指标：check-docs 报警数在 Batch commit 后必须为 0。不为 0 即视为 Batch 未完成，不计入完成计数

**经验编号**：LRN-2026-040

### 2026-06-26 — Emoji 装饰是"AI 写的"气味：typography-first 内容排版原则

**场景**：Phase 34 问答内容页大量使用 emoji 作为 blockquote 语义变体标记（💡🛡️⚠️⚙️📝🏆）、列表项装饰（👍👎）、置信度标记（🟢）和表格装饰（🚪👑✒️❌✅）。读者反馈"看起来像 AI 写的，加了很多没有必要的图标，除非很合适一般不加"。

**关键洞察**：
1. **Emoji 在文本内容中有"AI 生成"气味**。人类作者在技术文档中不会用大拇指 emoji 标注优缺点——他们会用粗体文字。Emoji 密集出现在正文中是一种 prompt 工程副产品（LLM 倾向于用 emoji 做视觉分区），对读者是噪音而非辅助
2. **排版三要素（字号层级 + 颜色 + 字重）足以建立信息架构**。Blockquote 的语义区分不需要 emoji——左边框颜色已经承载了视觉分类信号，emoji 是冗余层。列表中 `**优点**：` 和 `**缺点**：` 的粗体文字本身就是足够的扫读标记
3. **粗体标签是"双用途"机制**：`> **关键洞察**：text` —— 粗体文字对读者是视觉扫读锚点，`<strong>` 标签对渲染管线是 CSS variant 选择器。一个 markdown 语法同时服务人类读者和代码逻辑，不冗余
4. **图表是例外**。Mermaid 节点标签中的 emoji（`💬 用户消息`、`📤 IntentResult`）在视觉媒介中有实际锚点作用——它们是图表的彩色节点，emoji 帮助快速区分节点类型。正文排版不需要这种"视觉锚点"因为文字本身就是锚点
5. **Emoji 不是免费的**——每条 emoji 都是内容管线的一次决策：加什么 emoji、放在哪里、用什么颜色、是否需要 CSS 配套。排版不用 emoji 意味着内容管线少了整一类决策

**行动建议**（跨项目可迁移）：
- 文本内容的语义分层优先用排版三要素（字号/颜色/字重），不引入 emoji 做装饰
- 如果内容的 emoji 密度超过"每 500 字 1 个"，审查是否可以用粗体标签替代
- Emoji 只在两种场景使用：① 视觉媒介（图表节点、图标按钮）；② 行业共识符号（⚠️ 在 UI 中表示危险操作，而非正文中的"注意"）
- Rendering pipeline 中的 variant 选择器用语义标签（bold text → data attribute → CSS class），不绑定到 emoji 字符。字符是内容层的决策，variant 是渲染层的决策——两者应该解耦
- 评审标准：读一遍内容——如果去掉所有 emoji 后信息完整且可读，那 emoji 就是多余的。如果去掉后某个 blockquote 的语义（警告/洞察/总结）丢失了，说明排版（边框颜色、字重）没做够

**经验编号**：LRN-2026-041

### 2026-06-26 — CSS Grid 固定高度布局：`min-height: auto` 是沉默的约束破坏者

**场景**：将 AppShell 的 CSS Grid 从 `min-h-screen`（地板）改为 `h-dvh`（天花板），预期 `1fr` 行被固定 px 值约束后 `<main>` 和 Sidebar 各自独立滚动。但加了 `h-dvh`、`overflow: hidden`、完整高度链（`h-full` 从 grid cell → sidebar wrapper → sidebar aside）后仍不生效——页面仍然共用一个滚动条。3 轮尝试才定位到根因：CSS Grid 子元素默认 `min-height: auto`。

**关键洞察**：
1. **`min-height: auto` 是 CSS Grid 的隐藏默认值**。Flex 和 Grid 子元素都有这个默认行为——它们的内容可以撑破容器分配的空间。MDN 文档提到了但很少人真正遇到过：`min-height: auto` 意味着"子元素的最小高度至少是其内容的固有高度"
2. **`overflow: hidden` 只在容器层面阻断溢出，但 `min-height: auto` 在子元素层面允许溢出**。溢出检测链：grid 有固定高度 → grid 行 `1fr` 有固定 px 值 → 子元素 `<main>` 的 min-height 默认 auto → 子元素撑到内容高度 → grid 行被撑破 → `overflow: hidden` 截断溢出部分（而非在 `<main>` 内部滚动）
3. **`min-h-0` 是 CSS Grid 固定高度布局的必备搭配**。`min-height: 0` 告诉 grid 子元素"你可以比你的内容矮"。配合 `overflow-y: auto`，矮掉的部分变成内部滚动条
4. **高度链完整性排查法**：从固定高度源（`h-dvh`）开始，沿 DOM 树向下追踪，每个后代如果承担"填满父容器"角色，必须有 `height: 100%` 或 `h-full`。如果承担"内部滚动"角色，必须有 `min-height: 0` + `overflow-y: auto`。缺一个环节整条链失效
5. **`h-dvh` vs `h-screen` 的选择**：`dvh`（dynamic viewport height）排除了移动 Safari 地址栏区域，比 `100vh` 在现代移动端更准确。但如果 Tailwind 版本不支持 `h-dvh` 工具类，可以用 `h-[100dvh]` 任意值语法兜底

**行动建议**（跨项目可迁移）：
- CSS Grid 固定高度布局 → 所有 `1fr` 行的子元素必须加 `min-height: 0`（Tailwind: `min-h-0`）
- Flex 布局同理：`flex: 1` 子元素需要 `min-height: 0` 才能被约束
- 排错顺序：① 确认容器有固定高度（非 `min-height`）② 检查高度链每环是否有 `height: 100%` ③ 检查溢出子元素是否有 `min-height: 0` ④ 最后检查 `overflow-y: auto` 是否设置
- 不要在 grid 子元素容器上加 `overflow: hidden`——会截断孙元素的 `overflow-y: auto` 滚动条
- 代码审查 checklist：看到 `1fr` + `overflow-y: auto` 组合 → 立刻检查 `min-height: 0` 是否跟上

**经验编号**：LRN-2026-042

### 2026-06-26 — 微型教学入口模式：ContextualLens 可复用展开组件

**场景**：Phase 35 在聊天页三个触点（token 数字、错误卡片、上下文溢出区域）嵌入教学入口——用户看到一句简短摘要 + 可展开的微型答案（含 mermaid 流程图）。三个触点共享同一套展开/收起交互，但内容各异。

**关键洞察**：
1. **触点驱动教学优于"文档页"模式**。用户在聊天中碰到 `Token: 1,247` 这样的数字，旁边出现"怎么算的？"链接 → 点击展开 → 看到三层精度模型的 mermaid 图。这比"去文档页搜索 Token 答案"的路径短得多——从"看到数字"到"理解含义"只需一次点击，不离开当前页面
2. **解释不是独立功能，是触点的延伸**。ContextualLens 不是独立的面板——它嵌入在 ChatMessage（消息旁）、ErrorDisplay（错误卡片下方）、OnionPanel（上下文面板内）。解释跟随问题出现的位置，不是集中在单独的帮助中心
3. **`extractMermaid` 是渲染管线复用**。从 AnswerCard 的 markdown 渲染中提取 mermaid 提取逻辑为独立工具函数，ContextualLens 和 AnswerCard 共享同一套正则匹配。工具函数的粒度应该匹配"被复用的操作"，而非"被复用的组件"
4. **展开 trigger 的可见性是门禁级问题**。Phase 35 Batch 3 修复了一个 bug：展开后 trigger 按钮被内容推到屏幕外。根因是没考虑"展开后 trigger 仍需可见以便用户收起"

**行动建议**（跨项目可迁移）：
- 面向非专业用户的产品，优先在数据/状态旁边嵌入解释入口，而非集中到帮助页
- 可展开组件的 trigger 必须在展开后仍保持可见（sticky header / 固定位置 / 或展开内容上方重放 trigger）
- 内容提取工具（extractMermaid 类）从渲染管线中独立出来——它们属于"内容到渲染"的中间层，不绑定到具体组件

**经验编号**：LRN-2026-043

### 2026-06-26 — 算法对比的"竞赛"可视化：并排对比 + 强项/盲区标注

**场景**：Phase 36 Batch 2 的 RecallRacePanel 面板——三条检索路线（语义/关键词/MMR 混合）用固定示例并排对比，每条路线标注强项（绿色 ✅）和盲区（红色 ❌），底部展示混合检索流水线的完整 mermaid 图。

**关键洞察**：
1. **固定示例比实时数据更适合教学**。实时数据受当前数据库状态影响——可能某条路线"今天表现好"纯属巧合。固定示例（预选句子）保证每个用户看到的结果一致，教学效果可验证
2. **"竞赛"隐喻降低认知门槛**。用户直觉理解"三条路线比赛谁找得更准"——不需要解释 MMR、向量相似度、关键词匹配的技术细节，只需展示比赛结果
3. **强项/盲区标注是差异化关键**。不只说"路线 A 找到 3 条相关记忆"——还要说"路线 A 漏掉了"猫粮品牌偏好"因为它依赖关键词匹配"。盲区解释比强项解释更有教学价值——用户从"漏了什么"学到每条路线的适用范围

**行动建议**（跨项目可迁移）：
- 算法/策略对比面板优先用固定示例建立可复现的对比基准
- 对比结果不只展示分数——必须标注每条路线的强项和盲区，盲区是用户理解差异的关键
- "竞赛"或"A/B PK"的隐喻适用于任何需要向非技术用户解释多策略差异的场景

**经验编号**：LRN-2026-044

### 2026-06-27 — Python 单体文件→包重构：渐进式拆分 + 旧 imports 兼容

**场景**：Phase 37 Batch 1 将 `src/planner.py`（L1 意图分类器）重构为 `src/planner/` 包（`intent.py` + `plan.py` + `__init__.py`）。原文件有 8 处外部 imports + 2 个测试文件引用。

**关键洞察**：
1. **`__init__.py` 重导出保持向后兼容**。`from src.planner import PlannerEngine, IntentResult` 在包重构后仍有效——`__init__.py` 中 `from .intent import PlannerEngine, IntentResult, ...` 保证了老 imports 不断裂。这是"先重构结构，再逐步迁移调用方"的基础
2. **三阶验证链确保零回归**：① `make check`（pytest 全部测试）→ ② `make check-contracts`（API 签名快照对比）→ ③ `grep -rn "from src.planner import\|from src import planner"` 手动审计。三者全绿才提交
3. **包重构的"清理期"可以延后**。8 处 imports 本次只更新了 1 处（`api/dependencies.py` 添加了新路径），其余 7 处通过 `__init__.py` 重导出兼容——避免"重构 + 全部迁移"一个巨型 commit。旧 imports 的逐份迁移留给后续治理 Batch
4. **`__init__.py` 即包的公开 API 契约**。`__all__` 列表定义了什么是对外稳定的、什么是内部可重构的。不在 `__all__` 中的符号，调用方不应直接 import

**行动建议**（跨项目可迁移）：
- Python 单体文件拆分：第一步 `cp old.py new_package/` → 第二步拆模块 + `__init__.py` 重导出 → 第三步更新 imports（可多次 Batch 渐进完成）
- 重导出兼容期 ≤1 Phase——过长的兼容期让包结构"新旧两条路"并存，增加心智负担
- 每次包重构后立即更新 `check_contracts.py` 签名快照

**经验编号**：LRN-2026-045

---

### 2026-06-28 — 接口假设 vs 运行时现实：TypeScript 必填字段在 mock 中可能缺失

**场景**：Phase 42 Batch 2 ChatMessage 新增 `buildPartitionChart(meta: ContextMeta)`，其中 `ContextMeta` 接口所有字段都是必填（无 `?`）。但在 ChatPanel 测试的 mock response 中 `context_meta` 整个字段缺失——TypeScript 在测试运行时没有保护，导致 `undefined.toLocaleString()` 崩溃。

**关键洞察**：
1. **TypeScript 的 `!` 非空断言不产生运行时保护**。`response!.context_meta` 在类型层面上告诉编译器「我保证它有值」，但运行时 `context_meta` 完全可能 undefined——TypeScript 在 `test` 模式下运行，零运行时类型检查
2. **接口的「必填」语义在测试中可能被违反**。测试 mock 通常只构造被测试组件关心的字段。如果被测试组件间接引用了一个未 mock 的字段（比如 ChatMessage 组件内部的 ContextualLens），这个间接依赖在测试编写时很难被直观发现
3. **`?.` 可选链是防御性编程的最佳实践**——即使在看似「必填」的字段上。不会因测试 mock 不完整而崩溃，也不会影响生产环境正常路径的行为

**行动建议**：
- 所有涉及 `toLocaleString()`、`.length`、`.map()` 等可能崩溃的字段访问，优先使用 `?.` 可选链
- 组件内部的「额外信息」组件（ContextualLens、badge 等）应作为可选增强而非必需渲染——当数据不完整时应优雅降级隐藏而非崩溃
- 如果类型层面标注为必填但运行时可能缺失，在组件内部做一次存在性检查并在缺失时降级——这不是防御过度，这是运行时现实的承认

**经验编号**：LRN-2026-046

---

### 2026-06-28 — 内容填充后测试阈值同步：answeredCount 和占位题计数会自动过期

**场景**：Phase 42 Batch 3 填充 q1.4 后，`chapters.ts` 的 `answeredCount` 从 3→4 需要手动更新，`content-integrity.test.ts` 的占位题数量断言（≥60）也需要同步缩小到 ≥55。

**关键洞察**：
1. **内容填充有无意中断测试的副作用**——不是测试逻辑错了，是测试中的「静态基线」过期了。`answeredCount` 和占位题计数是随内容填充自动失效的「会过期的数字」
2. **解决方案不是删除这些测试**——它们在其他场景下提供重要的完整性校验（防止 answeredCount 不更新、防止占位题被意外清空）。关键是**让基线的容忍度合理**
3. **`toBeGreaterThanOrEqual(55)` 比 `toBeGreaterThanOrEqual(60)` 更合理**——「至少 55 个占位题」给未来填充留下了 5 题的缓冲区，不需要每次填充都改测试

**行动建议**：
- 内容填充类 Batch 必须在验证环节跑一次 content-integrity 测试——如果因计数预测失败，是正常现象，更新阈值即可
- 使用 `toBeGreaterThanOrEqual` + 宽松缓冲区（如当前值的 90%）避免每次填充都断测试
- answeredCount 在 `chapters.ts` 中维护，属于必须手动更新的「事实真相源」——不能自动推算，因为「已答」的定义可能大于「l0 !== ''」（可能后续引入审核状态）

**经验编号**：LRN-2026-047

---

### 2026-06-29 — 内容中的代码引用必须逐行对照源代码

**场景**：Phase 46 Batch 2 L2 代码引用段中写了一段虚构的 `suspected_hallucination` 检测逻辑（`if "?" in summary or len(summary) > len(content) * 1.2: api_trace["suspected_hallucination"] = True`），这段代码在真实 `compress_message()` 中不存在。同时 q2.4 L1 的 `compress_message()` 代码块是凭记忆简化的版本，缺少 `logger.info`、`compressed` 留空降级、`api_trace` 完整结构等真实实现细节。

**关键洞察**：
1. **内容写作时，"写一段看起来对的代码"比"确认这段代码真的存在"容易得多**——模型倾向于凭常识推理填补代码细节，而不是去核实
2. **虚构的代码比错误的描述更危险**——读者（包括未来的自己）会以为这是真实实现并据此做判断
3. **L2（代码引用层）和 L1（概念解释层）应该用不同的质量标准**——L1 可以"概念上准确"，L2 必须"字节级准确"
4. **这个问题的检测手段很简单**——写完 L2 后 `grep` 一下源码就能发现偏差。问题根本不在复杂度，在流程上没纳入门禁

**行动建议**：
- L2 代码引用写完后，必须 `grep` 或 `cat` 对应源码文件中对函数，逐行核对引用与真实的差异
- 代码块中的实现细节（变量名、异常类型、返回值结构）尤其容易造假
- 对比表类的"状态"列（✅/⏳/🔜）也要基于实际代码检查，不是基于"我觉得这个应该实现了"

**经验编号**：LRN-2026-048

### 2026-06-30 — Lazy import 在函数体内的位置应唯一化，避免重复导入同一模块

**场景**：`api/routers/chat.py` 函数体内两次 `from src.config import settings`（一次 alias 为 `app_settings`，一次裸名），均为了测试时 patch 生效。两次导入引入同一模块对象，第二次为冗余。

**根因**：功能增量式追加（先加 token pricing 段 → 后加 plan 持久化段），各段独立写 lazy import，缺少函数级审视。

**教训**：函数体级别的 lazy import 应集中在函数开头或流程分界点，每模块只 import 一次。新增代码段需要访问已导入模块时，复用上方引用而非重新 import。

**经验编号**：LRN-2026-049

---

### 2026-06-29 — 重构后内容中的代码行号引用同步而非代码内容本身

**场景**：Phase 49 L5 拉通自检发现 q3.3 内容的 3 处 `intent.py` 行号引用全部过时：`classify_intent()` 标为 `intent.py:345-363` 但实际在 `159-171`；`_parse_intent()` 标为 `370-410` 但实际在 `232-281`。根因是 Phase 37 将 `src/planner.py` 拆为 `planner/intent.py`/`plan.py`/`replan.py`/`reflection.py` 后，代码被复制过去但行号引用指向了旧文件的尾部，而内容团队只关心"代码对不对"没更新行号。

**与 LRN-2026-048 的区别**：上次问题是**代码内容虚构**（写了不存在的代码），这次是**行号引用过时**（代码正确但位置不同）。两类错误的检测手段不同——LRN-2026-048 需要追内容，本经验需要追行号。

**关键洞察**：
1. **重构不只有代码迁移，还有所有引用该代码信息的同步**——行号注释、文档中的代码路径、ADR 中的文件引用，三者都需要同步
2. **"代码看起来对"与"代码位置信息对"是两件事**——写完 L2 后不仅应 grep 源码确认代码存在，还应确认行号标注与实际一致
3. **大文件拆分后行号必然大幅变化**——任何文件拆分为子模块后，子模块的总行数大概率小于原文件局部行号，导致引用指向不该存在的位置

**行动建议**：
- 重构（尤其是文件拆分）完成后，必须 grep 所有 `# src/...py:\d+` 格式的行号引用，逐条验证
- 代码引用注释使用相对行号（函数名+行号偏移）而不是绝对行号也能降低维护成本，但当前项目标准是绝对行号——保持标准，但引入重构后审计步骤

**经验编号**：LRN-2026-049

### 2026-07-01 — 验证源文件 ≠ 验证编译产物——门禁必须穿透到运行时输出

**场景**：Batch 33 CSS 四文件拆分——`theme.css` 使用 Tailwind v4 `@theme inline` 块将 CSS 自定义属性映射为工具类。文件语法正确、import 路径正确、eslint/tsc 全绿、五层自检全过——但页面 CSS 全掉。

**根因**：`@theme inline` 需要 `@import "tailwindcss"` 前置指令才能被 PostCSS 编译器识别。缺少该指令时，Tailwind 编译器**静默丢弃**整个 `@theme` 块——不报错、不警告、编译 exit code 为 0。全部验证手段（tsc/eslint/vitest/ruff/mypy/check-theme console scan）都在检查源文件——没有一步检查编译产物。

**后果**：18 类自定义工具类（bg-bg / text-text / gap-gm-5 等）消失，页面所有使用这些类的元素样式归零。

**修复**：双层门禁补齐——
1. L4 `check-theme` 新增 `css-bundle` 行：Playwright 拉取页面 CSSStyleSheet，grep 17 个关键类名，缺失即阻断
2. L2 `check-safety` 新增 CSS 指令前置检查：使用 `@theme`/`@apply`/`@layer` 的文件首行必须有 `@import "tailwindcss"`，缺失即阻断

**经验提炼**：
- **门禁金字塔的盲区**：L1（语法/类型）→ L4（浏览器 console）全都在检查源文件或其副作用。没有一层检查编译器的实际输出。编译器是源文件和运行时之间的黑盒——静默丢弃是这个黑盒最危险的故障模式。
- **门禁设计原则**：任何有编译/构建步骤的技术栈（CSS PostCSS、JS bundler、Python bytecode），至少需要一层门禁直接检查编译产物。源文件正确 ≠ 编译器行为正确。
- **双层防御**：L2（前置条件检查，防已知故障模式）+ L4（产物内容检查，防未知故障模式）。单层不够——前置条件可能遗漏新的故障路径，产物检查能兜底。
- **可迁移场景**：Webpack tree-shaking 静默丢弃、Babel 插件静默跳过、Python `__pycache__` 过期字节码——都是同一类"编译器在你不看的地方做了你不期望的事"。

**经验编号**：LRN-2026-050

### 2026-07-02 — 修复组件交互态时，必须追踪组件树深度——不能只扫直接文件

**场景**：Phase 66 B9 修复 Chat 页 14 项问题，包括 OnionPanel C17（RecallItemRow 展开按钮缺 focus-visible ring）。修复完成后 tsc/eslint/vitest 全绿、check-theme 5 路由 0 错误，标记为 Chat 页 18/18 闭环。L5 拉通走查时发现：OnionPanel 内部使用的 ContextualLens（4 次调用）、ModelInferencePanel（1 次调用）以及 OnionPanel 自身顶部"收起洋葱面板"按钮——共 6 个交互元素——全部缺失 focus-visible ring + cursor-pointer。

**根因**：B9 自检仅覆盖 OnionPanel.tsx 直接文件内的按钮，未追踪到 OnionPanel 导入的子组件。ContextualLens 在 OnionPanel 中被渲染 4 次（上下文窗口区 3 个透镜 + 记忆召回区 1 个透镜），每次都是一个可点击的 `<button>`——但这些按钮在 ContextualLens.tsx 文件中，不在 OnionPanel.tsx 中。修复 OnionPanel 的交互态不等于修复了 OnionPanel 用户体验的全部交互态。

**后果**：需要额外的 L5 修复 Batch（0dc4b6b）——额外 5 文件变更 + 1 测试更新。如果 B9 执行时就做了组件树检查，这些应该在同一个 commit 内。

**修复**：
1. 流程层面 — CLAUDE.md 新增协作纪律 18「组件树深度检查」+ methodology.md 新增 L2f 检查清单
2. 代码层面 — ContextualLens 4 按钮 + ModelInferencePanel 展开按钮 + OnionPanel 收起按钮全部补齐 focus-visible ring + cursor-pointer

**经验提炼**：
- **组件不是孤岛**：修复父组件 A 的交互态时，A 渲染的子组件 B/C/D 的交互态也是 A 的用户体验的一部分。在组件树中，交互态修复的影响面 = 直接文件 + 所有导入的子组件。
- **自检边界问题**：人类执行"修完文件后自检"时，自然倾向只看当前文件——因为文件是操作的基本单位。但 React 组件树是跨文件的：`OnionPanel.tsx` → `ContextualLens.tsx` → `ContextualLens` 内部的 `<button>`。文件边界 ≠ 体验边界。
- **低成本检测**：修复完成后，grep 父组件 import 列表 → 逐个子组件 grep `focus-visible:ring\|cursor-pointer` → 缺失则同批补齐。这个检测 30 秒就能做完，但发现的遗漏需要额外一个 Batch 来修复。

**经验编号**：LRN-2026-051

### 2026-07-03 — 开发环境 URL 差异（localhost vs 127.0.0.1）可导致功能完全失效——安全配置的隐性依赖

**场景**：用户通过 `http://127.0.0.1:3000/` 访问 Next.js 16 应用，整个页面看起来完全损坏——主题切换黑屏、侧边栏画像空白、发送按钮点不动。切换到 `http://localhost:3000/` 完全正常。`check-theme` 5 路由 0 errors 照过——因为它只测 `localhost`。四个 Playwright 验证 + Node.js 裸 socket 抓包，最终定位：Next.js v15.2.2+ `allowedDevOrigins` 安全机制默认仅白名单 `localhost`，`127.0.0.1` 的 HMR WebSocket 升级请求返回裸文本 `Unauthorized`，导致 React hydration 全链路中断。

**根因**：Next.js 的安全加固（`allowedDevOrigins`）对开发体验产生了隐性破坏。框架升级的 break change 不是编译错误——而是"某一天某个合法的 loopback 地址突然不工作了"。这种 break：① 无编译时提示 ② 无运行时 JS 异常（React hydration 静默失败） ③ 无 console warning（仅 WebSocket 连接失败） ④ 浏览器门禁单地址覆盖不到。

**修复**：`next.config.ts` 添加 `allowedDevOrigins: ["localhost", "127.0.0.1"]`（2 行配置，30 秒修复）。但诊断花了 45 分钟——从症状到根因的推理链：三个组件卡在 pre-hydration 状态 → JS 执行失败 → WebSocket 握手 `ERR_INVALID_HTTP_RESPONSE` → Node.js raw socket 抓包 `Unauthorized` → `Host` vs `Origin` 对比实验 → 搜索引擎确认 `allowedDevOrigins`。

**经验提炼**：
- **同一主机的不同地址不是等价的**：`localhost` ≠ `127.0.0.1` ≠ `[::1]` ≠ `0.0.0.0`。对 DNS 来说它们可能解析到同一台机器，但对框架的安全中间件（origin 校验、CORS、HMR allowlist）来说它们是不同的标识符。
- **安全配置的隐性依赖**：`allowedDevOrigins` 这样的配置项在文档角落，但它控制的路径（HMR WebSocket → hydration）是开发模式的核心依赖。配置缺失 = 应用"看起来坏了"，没有任何机制告诉你"加一行配置就好了"。
- **门禁的单地址盲区**：`check-theme` 用 `localhost:3000` 验证，但用户可能用 `127.0.0.1:3000` 或 `192.168.x.x:3000` 访问。浏览器门禁需要覆盖至少两种 loopback 地址（`localhost` + `127.0.0.1`）以避免单地址盲区。
- **诊断效率：同一症状 → 三个可能根因**：本次症状（主题黑 + 侧边栏空 + 按钮点不动）与 React hydration 失败的通用症状完全一致。但 hydration 失败的可能原因有：① JS bundle 损坏 → 清 Turbopack 缓存重启 ② CORS/API 故障 → 检查 API 端点 ③ HMR 安全配置拒绝。第一个假设错了两次才找到第三个。
- **浏览器行为差异也是诊断线索**：`check-theme` 用 `localhost` 测试全绿，用户在 `127.0.0.1` 上完全炸裂。这种"特定 URL 才能复现"的模式强烈提示框架级中间件（origin 校验、HMR 白名单）而非应用代码 bug。下次遇到"我这边正常你那边炸"第一时间检查两个环境的 URL 是否使用不同的 loopback 地址。

**经验编号**：LRN-2026-052

### 2026-07-03 — Shared Module Governance：个案→通用化→框架→工具→治理→闭环的六阶段路径

**场景**：Phase 66 renderMarkdown 12 次返修（B11/B16/B18/B25/B26/B27 六轮修复，12 个 commit）暴露了一个比"正则管线怎么修"更大的问题——项目中所有共享模块都在无 spec matrix 的情况下 build。消费者数 N × 抽象层数 K 的返修风险对任何 ≥3 消费者的模块都存在，但此前无任何机械检测手段。从 renderMarkdown 个案到全量 Shared Module Governance 框架，经历了六阶段沉淀路径。

**关键洞察**：

1. **从个案到通用化的拐点信号**：同一模块返修 ≥3 次 → 不是这个模块难写，是缺少治理框架。renderMarkdown 前 3 次修复（B11/B16/B18）还在"修 bug"的心智模型里，但第 4 次（B25）仍然失败时，问题变成了"为什么每次修完都以为对了但实际没对？"——答案不在代码里，在流程里。

2. **全量扫描是通用化的前提**：CLAUDE.md 规则 14（Shared Module Risk Assessment）定下来后，如果不做全量扫描，就无法知道规则的覆盖范围。`check_shared_modules.py` 首次运行输出 61 个共享模块、4 个 Critical（config/store/schemas/embed）全部未评估——这个数字让"通用化"从口号变成了可量化目标。

3. **工具化是规则落地的唯一保证**：规则 14-16 写在 CLAUDE.md 里是"期望"，写成 Python 脚本放进 `make check-docs` 里是"门禁"。人类阅读 CLAUDE.md 会跳过、会忘记、会"这次急下次补"。但 `check_shared_modules.py` 每次 commit 前都跑——工具化 = 规则从文档变成了机械执行。

4. **品类-层模板是 Risk Assessment 可复现的保证**：B57-B59 三个模块的 RA 使用相同的模板（Consumer Impact Table + 5 层 Enumeration + 风险评级 + 重点发现），但每个品类的五层结构不同——数据模型（schemas.py：类型定义→校验→序列化→兼容性→边界值）≠ 配置（config.py：字段定义→语义审计→类型约束→访问模式→可替换性）≠ 存储（store.py：Schema/DDL→写路径→读路径→事务/并发→迁移兼容性）。模板保证结构一致性，品类差异保证分析深度。

5. **发现即待办是治理闭环的关键**：B57-B59 共产出 16 项关注事项。如果没有规则 19（发现即待办），这些发现会留在 RA 文档里被遗忘。有了规则 19，3 项低成本当场修（B59+B61），13 项排入 B62-B81 backlog——每一项都有 owner、有 Batch 编号、有严重度评级。

**行动建议**：
- 任何模块返修 ≥3 次 → 停止修代码 → 做该模块的 Risk Assessment → 确定是否缺治理框架
- 新规则写入 CLAUDE.md 后，72 小时内必须有对应的机械检查工具——规则到工具的时间窗口越短，规则存活率越高
- 全量扫描应在框架落地后立即执行——没有 baseline 的框架是"看起来有框架"
- Risk Assessment 模板按品类区分——不要用一个通用模板套所有模块（数据模型/配置/存储/渲染引擎/类型常量各有自己的层结构）
- 发现治理 backlog 必须有独立的追踪段（roadmap 中 B61-B81）——与功能迭代 Batch 平行管理

**经验编号**：LRN-2026-055

### 2026-07-03 — renderMarkdown 12 次返修：跨五层诊断案例与"打错层"反模式

**场景**：Phase 66 的 renderMarkdown 函数（`frontend/src/lib/renderMarkdown.ts`）经历了六轮修复（B11/B16/B18/B25/B26/B27）、12 个 commit、跨越 3 周——从最初添加列表支持到最终发现 CSS Reset 静默吞 `list-style`。这个案例是 Shared Module Governance 框架的触发事件，也是"修复打错层"的教科书级反模式。

**关键洞察**：

1. **12 次修复中至少 8 次打错了层**：renderMarkdown 管线的五层结构——L1 词法（正则匹配 `1. ` / `- `）→ L2 HTML（生成 `<ol><li>`/`<ul><li>`）→ L3 文本（段落包装 `\n\n` 分割）→ L4 CSS（`chat-prose` 自定义样式）→ L5 Reset（Tailwind preflight `list-style: none`）。B11/B16/B18/B25 四次修复都在 L1-L3 打转——调正则、加 sentinel、改段落分割——但真正的 bug 在 L5。每次修复后 vitest 全通过（因为测试只检查 HTML 输出，不检查 CSS computed value），每次用户反馈"列表还是没圆点"。

2. **测试覆盖了抽象场景，没覆盖真实渲染**：`renders ordered lists` 测试输入是纯列表（`1. first\n2. second`），输出验证是 HTML 字符串（`expect(result).toContain('<ol>')`）。但用户的真实输入总是"以下是步骤：\n1. xxx\n2. xxx"（带前导文字），真正的验证标准应该是浏览器的 `getComputedStyle(el).listStyleType`（CSS computed value）。HTML 正确 ≠ 用户看到正确。

3. **CSS Reset 是静默杀手——不报错、不警告、不影响门禁**：Tailwind v4 preflight 的 `ol, ul, menu { list-style: none }` 在项目初始化时就生效了。因为 `chat-prose` 设置了 `margin` 和 `padding-left`，列表"看起来有点像列表"（有缩进），标记被静默吞掉没人发现。`check-theme` 的 console.error 扫描完全覆盖不到——CSS computed value 的异常不产生 console 输出。

4. **同类 bug ≥2 次修复无效 → 不是修得不够，是修错了方向**：B18/B25/B26 三个 commit 信息都是"fix: 列表渲染修复"——但三个 fix 都在正则/段落层。正确的拐点信号：第一次修完用户反馈"还是不行"→ 应该停止修当前假设 → 退后一步问"我是否在修正确的层？"→ 打开浏览器 `getComputedStyle` → 5 秒定位。

5. **三层诊断方法论是事后总结，但应成为事前 checklist**：① HTML 结构（`innerHTML`）→ ② CSS 计算值（`getComputedStyle`）→ ③ 视觉呈现（截图）。B27 之前的六轮修复都跳过了第②层。如果第一次修复前就走了三层诊断，12 个 commit 可以压缩到 1 个。

**行动建议**：
- 渲染类 bug 的第一个诊断动作：Playwright `getComputedStyle` 在目标元素上，不是读源码
- 测试必须覆盖真实输入（前导文字 + 列表），不只是纯列表
- 同一 bug ≥2 次修复无效 → 强制停止 → 三层诊断 → 确认根因层 → 再动手
- CSS Reset 交叉对照应纳入开发 checklist——每个自定义 prose/scoped CSS 块必须对 Tailwind preflight 的 11 项 reset 做覆盖检查
- 门禁应增加关键 CSS property 的 computed value 断言（list-style-type、display、font-size），不只是 console.error 扫描

**经验编号**：LRN-2026-056

### 2026-07-04 — LRN-2026-059: 上下文窗口饱和度应作为 Batch 规划的一级约束

**场景**：Phase 1000 B86-B93 八批 RA 在同一个会话中连续执行。每批 RA 向 `requirements-log.md` 追加 ~400 行，check-docs 脚本每次全量扫描 61 个模块的消费者数据。到 B92 时，会话上下文中的 CLAUDE.md（2,000+ 行工程铁律）+ requirements-log（5,000+ 行 RA 历史）+ master-backlog + roadmap + methodology 引用——有效工作窗口被压缩到不足 30%。症状：commit 操作两次失败（stash 冲突 + eslint auto-fix 回滚），而 B93（同样内容复杂度、同样操作流程）在 `git stash push` 预处理后一次成功。根因不是 B92 的操作更复杂，而是上下文饱和导致的边际决策质量下降。

**关键洞察**：

1. **「内容简单」≠「上下文压力小」**：B92 和 B93 的源码变更都是纯文档追加（零代码），但 B92 是会话中的第 2 批（上下文已含 B86-B91 的 RA 历史 + 大量文件读取），B93 是第 3 批（上下文进一步膨胀）。如果只看"改几个文件"决定批大小，会漏掉上下文饱和度这个隐藏变量。

2. **上下文窗口有效工作空间的衰减曲线**：每次文件读取（Read 工具）→ 内容进入上下文 → 后续推理需要在这些背景中定位相关信息 → 注意力分散。LLM 的上下文不是"满了才溢出"，而是"越满越模糊"——Lost-in-the-Middle 效应在 128K 窗口中 50% 位置就开始显著。工程项目中的上下文衰减更快：铁律文档、RA 历史、代码片段、测试输出都在竞争注意力。

3. **Batch 规划的缺失维度**：当前 Batch 规划只看 ① 文件数（≤8 文件门禁）② 关注点数（>2 需拆分）③ L5 间隔（每 2 批拉通）。这三个维度都是**任务侧**的——衡量任务有多复杂。缺少**环境侧**的维度——会话上下文还剩多少有效空间。这恰好是 GlassCortex 自己研究的课题（上下文预算、溢出策略）。

4. **B92→B93 的差异本质**：B92 在上下文饱和状态下执行，决策质量下降——commit message 格式错误、stash 操作时序混乱、两次失败后才定位根因。B93 在知道 B92 的坑后执行，加了 `git stash push` 预处理，但上下文依然饱和——只是靠"已知坑"的 checklist 弥补了决策质量下降。

**行动建议**：
- 会话上下文剩余空间应作为 Batch 启动门禁的一部分——在 `make check-docs` 同级增加「上下文预算检查」
- 跨 3 个 Batch 或上下文占用 >80% 时 → 触发主动建议 `/clear` 重开（已有机理：协作纪律 #11「上下文预估 + 主动建议重启」）——但当前触发点是"跨 3 话题 / 2+ Batch"，应改为"跨 3 Batch"无条件触发（即使话题未变）
- 每批完成后主动评估：本批消耗了多少上下文（文件读取量 + RA 追加行数 + 验证输出）→ 剩余空间是否够下一批
- `/clear` 前的交接文档应更精简——不是全量 dump，而是"接头暗号 + 关键状态 snapshot"（当前 memory 已有此机制，但执行时容易跳过）
- GlassCortex 自己的上下文预算/溢出策略研究成果应首先在自己的开发流程中落地——"吃自己的狗粮"

**经验编号**：LRN-2026-059
**门禁落地状态**：📋 待落地 — 需在 `make check-docs` 或 pre-Batch 门禁中增加上下文预算检查；协作纪律 #11 触发条件需收紧（话题数 → Batch 数）

### LRN-2026-060: Batch 执行效率的五大浪费模式

**日期**：2026-07-05
**来源**：B99 执行耗时 ~30 min，复盘识别五种可消除浪费

**问题描述**：
B99 是一个标准前端 Batch（2 个中复杂度风险、7 文件），却消耗了 ~30 分钟。复盘发现有效工作时间 ~16 min，浪费 ~12 min（42%）。

**五大浪费模式（按时间成本降序）**：

**W1 — Plan agent 空转（~5 min）**
- 在已进入 Plan Mode 的情况下，额外 spawn Plan Agent 等待其输出，同时自己直接读源码独立写了 Plan
- Plan agent 的建议方案与最终实施不同 → 其输出边际价值为零
- **规则**：Plan Mode 内自己设计 Plan 即可，不额外 spawn Plan Agent。Plan Agent 仅用于：① 跨项目架构选型 ② ≥5 文件且自己不熟悉的子系统 ③ 用户明确要求

**W2 — 架构选型未做 blast-radius 预估（~5 min 返工）**
- 选择 React Context Provider 重构 `_lockCount`，未先扫描 Drawer 的间接测试消费者
- 实施后 7 个测试文件、96 个测试被炸穿 → 被迫加"优雅降级" → 多轮修复
- **规则**：重构共享组件前，`grep` 所有直接+间接消费者（源码 + 测试），预估 blast radius。优先选零-blast-radius 方案（纯 hook / DOM 属性 / 模块级闭包）over 需新增 Provider/包装器的方案

**W3 — 测试基线缺失（连锁到 W2）**
- 实施前未跑 `vitest run` 建立基线，实施后才发现大规模失败
- **规则**：任何代码编辑前，先跑相关测试套件建立基线（不是最后验证，是第一步）。基线数字写入 Batch 工作区

**W4 — Linter 回滚修改（~3 min 返工）**
- 编辑被测文件时，linter 自动格式化/修正了 mock 结构，覆盖了我的修改
- **规则**：编辑有 linter 覆盖的文件前，先跑 `eslint --fix` 确认基线格式；修改后立即 `eslint --fix` 确认不产生新 diff

**W5 — Git 路径试错（~1 min）**
- Monorepo 下从子目录 `git add` 时，路径格式错误（3 次试错）
- **规则**：Monorepo 下 commit 前固定三步：`git rev-parse --show-toplevel` → 确认当前目录 → 使用 `git -C <root> add <full/relative/path>`

**复合效应**：W2×W3 是最致命的组合——选错架构 + 没有基线 = 问题发现晚、修复成本高。若实施前跑了 `grep -r "ProcessDrawer\|TagDetailDrawer\|Drawer" src/__tests__/`，会立即看到 7 个测试文件的 blast radius，从而否决 Context Provider 方案，选 hook 方案——节省 W2+W3 的全部 5+ min。

**行动建议**：
- 在 Batch 启动门禁中增加"blast-radius 检查"：涉及 ≥3 消费者（含测试文件中的间接消费者）的变更 → 强制输出 blast radius 预估 + 替代方案对比
- Plan 阶段增加自检问题："这个方案需要多少测试文件改动？有没有零测试改动的替代方案？"
- 将 W1-W5 纳入 `docs/methodology.md` §执行效率 段

**经验编号**：LRN-2026-060
**门禁落地状态**：📋 待落地 — blast-radius 预估可纳入 `make check-docs` 或作为 CLAUDE.md 协作纪律新增条目；Plan 阶段自检问题写入 methodology.md


### LRN-2026-061 — B60 执行 40 分钟三大时间黑洞与 monorepo git 铁律

**日期**：2026-07-06
**来源**：B60 执行耗时 ~40 min，有效工作 ~8 min，浪费 ~32 min（80%）

**三大时间黑洞**：

**H1 — 手段-问题维度错配：静态工具找运行时警告（~15 min）**
- B60 Plan 标记"dev server runtime warning ×4 清零，待定位"
- 使用 grep / eslint / 读源码等**静态分析**手段找**运行时**问题——手段和问题不在一个维度
- check-theme（Playwright console error 扫描）跑完后 5 routes 0 errors → 说明 4 个 warning 不在 scan 路由中，或已被之前批次修复
- **根因**：Plan 写"待定位"时就应该接受不确定性。Runtime warning 的 root cause 在浏览器 console，不在源码文本
- **规则**：定位 runtime warning 的标准流程：① `make check-theme`（1 次，~20s）→ ② 0 errors 就收手，登记 master-backlog → ③ 有 error 才读关联源码。不允许跳过 step ① 直接用 grep/Read 狩猎

**H2 — Monorepo 目录级 git add 引发 pre-commit 雪崩（~15 min）**
- `git add glassmind/` 把 glassmind 和 synapse 文件混合 stage → pre-commit hook stash/restore 冲突 → 3 次 commit 试错
- B60 的 QuestionList.tsx 代码变更最终混入了 commit `681f3b4 docs(synapse): P100-B8`——GlassCortex 代码进了 Synapse 的 commit message
- **根因**：monorepo 下目录级 add 无法区分项目边界
- **规则**：monorepo 铁律——commit 只用具体文件路径，禁止目录级 add。标准流程：`git status --short <project>/` → 确认文件列表 → 逐文件 `git add <file1> <file2> ...` → `SKIP=frontend-lint,check-theme git commit`

**H3 — Plan override vs 机械 gate 反复横跳（~10 min）**
- 产品 Plan 明确写"L5 在 B62 后首次触发"，L5 gate 说 ≥2 批就拦
- 花 10 分钟纠结"Plan 说 X 但 gate 说 Y"，反复编辑 checkpoint 注释试图"解释"跳过
- **根因**：用户签过字的 Plan 高于机械门禁。门禁不知道 Plan 内容，不该跟门禁辩论
- **规则**：Plan override 场景的标准动作——当场做 L5 拉通 + 当场 reset → commit 过。不纠结、不解释、不跟 gate 辩论

**复合效应**：H1×H2 叠加——H1 浪费 15 分钟后进入 H2 的 monorepo git 试错，认知负载已满，git 操作更容易出错。如果开局先用 20s 跑 check-theme 收手，后续时间节省 50%+。

**行动建议**：
- H1 规则写入 CLAUDE.md §执行效率：定位 runtime warning 必须先用 check-theme，0 errors 即收手
- H2 规则改为 pre-commit hook 检测：commit message 无项目前缀（glasscortex:/synapse:）但涉及项目文件 → 阻断
- H3 写入 methodology.md §L5 时机硬约束：Plan 中明确的 L5 排期 > 机械 gate，无需纠结

**经验编号**：LRN-2026-061
**门禁落地状态**：📋 待落地 — H1 可写入 CLAUDE.md 协作纪律；H2 可改造 commit-msg hook 加项目前缀校验；H3 写入 methodology.md

---

## LRN-2026-062: 点状修复心态 — B67 章序号同一任务执行了 5 轮才闭环

**日期**：2026-07-06
**触发**：Phase 66 B67 — 章序号中文数字改造

**问题**：一个本应 1 轮完成的任务（"章用中文数字、节用阿拉伯数字"），跨两个会话、累计 5 个轮次才闭环。

**根因**：不是能力问题，是流程缺失——理解需求和写代码之间少了一个"全量映射"步骤。每轮只修用户指出的那个点，没有主动扫全局渲染面。

**轮次分析**：

| 轮次 | 修了什么 | 漏了什么 | 模式 |
|------|---------|---------|------|
| 上会话 B67 | 章序号变大号阿拉伯数字 | 需求要的是中文数字，不是大号数字 | 理解偏差未澄清 |
| R1 | QuestionList 三个渲染点阿拉伯→中文 | 缺、号、字号过大、正文未同步 | 只改用户指的文件 |
| R2 | 加、号、调字号、改 AnswerCard+LearnClientShell | 正文缺节号 | 改了章号漏了节号 |
| R3 | 正文加节号 | — | 终于补全 |

**核心教训**：编码者思维的默认路径是"理解需求→写代码"，中间缺了一步"全量映射"。Product-owner 思维会在写代码前先问："这个变更影响了哪些渲染点？全部列出来。"一条 `grep` 命令 3 秒就能扫出全部 6 个渲染点，但因为没跑，代价是 3 轮返工。

**落地措施**：写入 CLAUDE.md 协作纪律 #21「全量映射先行」——UI 编号/文案/样式变更，开工前必须 grep 全量扫描 → 输出对照表 → 用户确认 → 再动手。

**经验编号**：LRN-2026-062
**门禁落地状态**：✅ 已落地 — CLAUDE.md 协作纪律 #21「全量映射先行」

---

### LRN-2026-063 — 表格式固定列宽需基于内容估算 + truncate 兜底

**日期**：2026-07-06 · **来源**：Phase 66 B72 可观测页 LogViewer 修复

**问题**：LogViewer 表格「来源」列固定 `width: 120px`，但 Python logger 全限定名（如 `glasscortex.chat.engine` ≈ 158px 渲染宽度）远超列宽，内容溢出叠加到右侧「消息」列，视觉上两列文字混叠。

**为什么发生**：设定固定列宽时没有估算实际数据的渲染宽度。logger 名在 Python 项目中典型长度 20-40 字符，monospace 字体 ~6.6px/字符 = 132-264px。120px 只能覆盖 ~18 字符，完全不够。

**通用解法**：

1. **估算公式**：`列宽 = 典型内容字符数 × 字体平均宽度 + 安全余量(15-25%)`
2. **truncate 兜底**：每个固定列必须加 `overflow: hidden; text-overflow: ellipsis; white-space: nowrap`（Tailwind: `truncate`），超长内容省略号截断 + `title` 属性 hover 显示全名
3. **flex-1 弹性列**：消息/正文等变长内容用 `flex-1 min-w-0`，确保固定列溢出不会挤压弹性列

**经验编号**：LRN-2026-063
**门禁落地状态**：⏳ 未落地 — 建议在 UI 组件 code review checklist 中增加「固定列宽 content-length 估算」检查项

---

### LRN-2026-064 — 项目标准组件优先复用，避免重复造轮子

**日期**：2026-07-06 · **来源**：Phase 66 B72 LogDetailModal Drawer 重构

**问题**：LogDetailModal 自己实现了抽屉动画、遮罩蒙层、ESC 关闭、滚动锁定四套机制，但实现存在两个 bug：① `animate-slide-in-right` class 在 Tailwind 配置中不存在（动画零效果）② `e.target === e.currentTarget` 蒙层点击判断失效（蒙层是子 div，target 永远不等于 currentTarget）。而项目已有 `Drawer` 组件完整封装了动画状态机（double-rAF 入场 + timeout 退场 + translateX transition）+ 蒙层关闭 + ESC + scroll lock + focus trap。

**为什么发生**：开发时没有先扫描项目已有组件库，直接从头实现。项目有 6 个 Drawer 消费者（ProcessDrawer、TagDetailDrawer、MobileSidebarDrawer、ProjectMapDrawer 等），说明 Drawer 是成熟的共享组件。

**通用解法**：

1. 开始实现前，grep 项目已有类似 UI 模式（`grep -r "Drawer\|Modal\|Panel" src/components/`）
2. 优先问：「现有组件能否满足需求？是否需要扩展而非重写？」
3. 即使用自有组件，也应复用其动画/遮罩/ESC 子能力（而非从零拼装）

**经验编号**：LRN-2026-064
**门禁落地状态**：⏳ 未落地 — 建议在 CLAUDE.md 协作纪律中增加「UI 组件实现前扫描已有组件库」检查项

---

### LRN-2026-065 — Tailwind 自定义 animation class 使用前需验证配置

**日期**：2026-07-06 · **来源**：Phase 66 B72 LogDetailModal 动画修复

**问题**：`animate-slide-in-right` 作为 Tailwind class 使用，但 Tailwind 配置中未定义该 animation。浏览器中无任何动画效果，开发者以为有动画实际为零。

**为什么发生**：Tailwind 默认不包含 `slide-in-right` 动画。自定义 animation 需在 `tailwind.config.*` 的 `theme.extend.animation` + `theme.extend.keyframes` 中定义，或写入 `globals.css` 的 `@layer utilities`。使用前未 grep 验证该 class 是否存在于配置中。

**通用解法**：

1. 自定义 Tailwind animation class 使用前：`grep -r "animate-slide-in-right\|slide-in-right" tailwind.config.* globals.css` 验证存在
2. 优先使用项目已有的动画 token（如 `--gm-duration-drawer` / `--gm-ease`）或已有动画组件（如 Drawer）
3. 避免在 className 中使用不存在于配置的任意 animation 名称

**经验编号**：LRN-2026-065
**门禁落地状态**：⏳ 未落地 — 建议在 lint 规则或 pre-commit 中增加 Tailwind class 存在性检查（如 `tailwindcss-no-unknown-classes` 规则）

### 2026-07-15 — LRN-2026-066: React effect cleanup 中 queueMicrotask 延迟副作用导致 Strict Mode 竞态

**场景**：React 18 Strict Mode 对 `useEffect` 执行 mount → cleanup → mount 双调用。原始代码在 effect cleanup 中用 `queueMicrotask(() => root.unmount())` 延迟卸载 + `ref.clear()` 清空映射表。re-run 时 ref 已空但 DOM 容器上的 root 尚未卸载（microtask 未执行），`createRoot()` 重复调用报错。

**竞态时序**：
```
1. Mount     → createRoot(container) ✓ · 存入 ref
2. Cleanup   → queueMicrotask(unmount) · ref.clear()
3. Re-mount  → ref 空 · 容器 root 未卸载 · createRoot() ✗
4. Microtask → unmount() 执行（太晚，步骤 3 已报错）
```

**关键洞察**：
1. `queueMicrotask` 在 effect cleanup 中延迟副作用本质是反模式——cleanup 语义是"上一个 effect 完成清理后才能安全启动下一个"，延迟打破了这层契约
2. Strict Mode 双 effect 是 React 帮你提前发现的竞态 bug——如果生产环境有重挂载场景（如 hot reload、Suspense retry），同样会触发
3. DOM 容器上挂载的 React root 需要在再次 `createRoot` 前先卸载，或复用已有 root 调用 `render()` 更新

**行动建议**：
- effect cleanup 中的清理逻辑必须同步执行，不依赖 `queueMicrotask`/`setTimeout`/`requestAnimationFrame` 等异步调度
- 需要跨 effect 重用的已创建 root 应保留在 ref 中不清空，re-run 时通过 `ref.get(container)` 复用而非新建
- 真正组件卸载时 DOM 随组件销毁，React root 随之 GC——不需要在最终 cleanup 中显式 unmount

**波及面**：本项目 4 组件（AnswerCard / ChatMessage mermaid hydration + useCodeHighlight / ProcessDrawer 复制按钮）全部修复，净减 16 行

**经验编号**：LRN-2026-066
**门禁落地状态**：✅ 4 文件同步修复 · check-theme Playwright 5 路由 0 console error
